/* global React */
// AInoia Board — agent orchestration list panel
function AgentsPanel({ agents, selectedId, onSelect, autonomous, onToggleAutonomous }) {
  const { Card, AgentRow, Switch, IconButton, Badge } = window.CODISAIDesignSystem_b12028;
  const Ico = ({ n, s = 15 }) => <i data-lucide={n} style={{ width: s, height: s }} />;
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  return (
    <Card padding="0" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "16px 18px", borderBottom: "1px solid var(--border-subtle)" }}>
        <i data-lucide="bot" style={{ width: 17, height: 17, color: "var(--cyan)" }} />
        <span style={{ color: "var(--fg-1)", fontWeight: 600, fontSize: 15 }}>Agents</span>
        <Badge tone="neutral">{agents.length}</Badge>
        <div style={{ marginLeft: "auto" }}>
          <IconButton label="Add agent" variant="ghost" size="sm"><Ico n="plus" /></IconButton>
        </div>
      </div>

      <div style={{ padding: 8, display: "flex", flexDirection: "column", gap: 2, overflowY: "auto" }}>
        {agents.map((a) => (
          <AgentRow key={a.id} name={a.name} role={a.role} status={a.status} runs={a.runs}
            selected={a.id === selectedId} onClick={() => onSelect(a.id)} />
        ))}
      </div>

      <div style={{ marginTop: "auto", padding: "13px 18px", borderTop: "1px solid var(--border-subtle)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Switch checked={autonomous} onChange={onToggleAutonomous} label="Autonomous mode" />
        <span style={{ fontSize: 11.5, color: "var(--fg-4)", fontFamily: "var(--font-mono)" }}>{autonomous ? "human-in-loop off" : "approval required"}</span>
      </div>
    </Card>
  );
}
window.AgentsPanel = AgentsPanel;
