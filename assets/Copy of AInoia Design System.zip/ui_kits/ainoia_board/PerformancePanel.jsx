/* global React */
// AInoia Board — performance KPIs + charts
function PerformancePanel({ agent }) {
  const { StatCard, Card } = window.CODISAIDesignSystem_b12028;
  const Ico = ({ n, s = 15 }) => <i data-lucide={n} style={{ width: s, height: s }} />;
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  const bars = [44, 58, 41, 66, 52, 73, 60, 84, 70, 92, 78, 96];
  const line = [62, 60, 67, 64, 72, 70, 78, 82, 80, 88, 92, 98.6];
  const pts = line.map((v, i) => `${(i / (line.length - 1)) * 100},${100 - ((v - 55) / 50) * 100}`).join(" ");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
        <StatCard label="Success rate" value="98.6" unit="%" delta="+1.2%" icon={<Ico n="target" />} />
        <StatCard label="Executions" value="1,243" delta="+312" icon={<Ico n="activity" />} />
        <StatCard label="Avg latency" value="412" unit="ms" delta="-38ms" deltaTone="success" icon={<Ico n="gauge" />} />
        <StatCard label="Agents online" value="4" unit="/ 4" delta="100%" icon={<Ico n="bot" />} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <Card padding="var(--space-5)">
          <Header icon="line-chart" title="Success rate" right="last 12h" />
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: "100%", height: 120, marginTop: 12, overflow: "visible" }}>
            <defs>
              <linearGradient id="perf-line" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#c0a080" /><stop offset="100%" stopColor="#735a3a" />
              </linearGradient>
              <linearGradient id="perf-fill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="rgba(192,160,128,0.28)" /><stop offset="100%" stopColor="rgba(192,160,128,0)" />
              </linearGradient>
            </defs>
            <polygon points={`0,100 ${pts} 100,100`} fill="url(#perf-fill)" />
            <polyline points={pts} fill="none" stroke="url(#perf-line)" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
          </svg>
        </Card>

        <Card padding="var(--space-5)">
          <Header icon="bar-chart-3" title="Executions" right="per hour" />
          <div style={{ display: "flex", alignItems: "flex-end", gap: 5, height: 120, marginTop: 12 }}>
            {bars.map((b, i) => (
              <div key={i} style={{ flex: 1, height: `${b}%`, background: "var(--grad-cta)", borderRadius: 3, opacity: 0.4 + (i / bars.length) * 0.6 }} />
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Header({ icon, title, right }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
      <i data-lucide={icon} style={{ width: 16, height: 16, color: "var(--cyan)" }} />
      <span style={{ color: "var(--fg-1)", fontWeight: 600, fontSize: 14 }}>{title}</span>
      <span style={{ marginLeft: "auto", fontSize: 11.5, color: "var(--fg-4)", fontFamily: "var(--font-mono)" }}>{right}</span>
    </div>
  );
}
window.PerformancePanel = PerformancePanel;
