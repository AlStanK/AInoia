/* global React */
// AInoia Board — live workflow graph for the selected agent
function WorkflowCanvas({ agent, running }) {
  const { Card, Badge } = window.CODISAIDesignSystem_b12028;
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  // hub-and-spoke layout (percent coords within the canvas)
  const center = { x: 50, y: 52 };
  const nodes = [
    { id: "trigger", label: "Trigger", icon: "zap", x: 50, y: 14, tone: "var(--cyan)" },
    { id: "process", label: "Process", icon: "cpu", x: 15, y: 52, tone: "var(--blue)" },
    { id: "integration", label: "Integration", icon: "blocks", x: 85, y: 52, tone: "var(--violet)" },
    { id: "response", label: "Response", icon: "send", x: 50, y: 90, tone: "var(--cyan)" },
  ];

  return (
    <Card padding="0" style={{ display: "flex", flexDirection: "column", overflow: "hidden", minHeight: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "16px 18px", borderBottom: "1px solid var(--border-subtle)" }}>
        <i data-lucide="workflow" style={{ width: 17, height: 17, color: "var(--cyan)" }} />
        <span style={{ color: "var(--fg-1)", fontWeight: 600, fontSize: 15 }}>Workflow</span>
        <span style={{ color: "var(--fg-3)", fontSize: 13 }}>· {agent.name}</span>
        <div style={{ marginLeft: "auto" }}>
          <Badge tone={running ? "active" : "neutral"} dot>{running ? "Running" : "Idle"}</Badge>
        </div>
      </div>

      <div style={{ position: "relative", flex: 1, minHeight: 320, padding: 8 }}>
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
          <defs>
            <linearGradient id="wf-grad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#d6bd9c" />
              <stop offset="50%" stopColor="#a67c52" />
              <stop offset="100%" stopColor="#735a3a" />
            </linearGradient>
          </defs>
          {nodes.map((n) => (
            <line key={n.id} x1={center.x} y1={center.y} x2={n.x} y2={n.y}
              stroke="url(#wf-grad)" strokeWidth="0.5" strokeLinecap="round"
              opacity={running ? 0.85 : 0.4}
              strokeDasharray={running ? "2 2" : "0"}
              style={running ? { animation: "wf-dash 0.9s linear infinite" } : undefined} />
          ))}
        </svg>

        {/* center hub = the agent */}
        <Node x={center.x} y={center.y} hub label="" icon="bot" tone="url(#grad)" running={running} hubName={agent.name} />
        {nodes.map((n) => <Node key={n.id} {...n} running={running} />)}
      </div>

      <style>{`@keyframes wf-dash { to { stroke-dashoffset: -8; } }
        @keyframes wf-pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(192,160,128,0.35); } 50% { box-shadow: 0 0 0 7px rgba(192,160,128,0); } }`}</style>
    </Card>
  );
}

function Node({ x, y, label, icon, tone, hub, running, hubName }) {
  const size = hub ? 64 : 48;
  return (
    <div style={{ position: "absolute", left: `${x}%`, top: `${y}%`, transform: "translate(-50%, -50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
      <div style={{
        width: size, height: size, borderRadius: "50%",
        display: "grid", placeItems: "center",
        background: hub ? "var(--grad-balance)" : "var(--ink-600)",
        border: hub ? "2px solid var(--ink-800)" : `1.5px solid ${tone}`,
        boxShadow: hub ? "var(--glow-balance)" : "var(--shadow-sm)",
        animation: hub && running ? "wf-pulse 1.6s var(--ease-in-out) infinite" : "none",
      }}>
        <i data-lucide={icon} style={{ width: hub ? 26 : 19, height: hub ? 26 : 19, color: hub ? "var(--fg-on-accent)" : tone }} />
      </div>
      {hub ? (
        <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--fg-1)", whiteSpace: "nowrap" }}>{hubName}</span>
      ) : (
        <span style={{ fontSize: 11.5, color: "var(--fg-3)", fontFamily: "var(--font-display)", letterSpacing: "0.08em", textTransform: "uppercase" }}>{label}</span>
      )}
    </div>
  );
}
window.WorkflowCanvas = WorkflowCanvas;
