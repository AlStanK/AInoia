/* global React */
// AInoia Board — top bar with title, search, deploy action, identity
function TopBar({ title, subtitle, onDeploy, deploying }) {
  const { Button, IconButton, Avatar, Input } = window.CODISAIDesignSystem_b12028;
  const Ico = ({ n, s = 16 }) => <i data-lucide={n} style={{ width: s, height: s }} />;
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  return (
    <header style={{
      display: "flex", alignItems: "center", gap: 16,
      padding: "16px 24px", borderBottom: "1px solid var(--border-subtle)",
      background: "color-mix(in srgb, var(--ink-900) 86%, transparent)",
      backdropFilter: "var(--blur-subtle)", flex: "none",
    }}>
      <div style={{ minWidth: 0 }}>
        <div style={{ color: "var(--fg-1)", fontWeight: 600, fontSize: 19, lineHeight: 1.2 }}>{title}</div>
        {subtitle && <div style={{ color: "var(--fg-3)", fontSize: 13, marginTop: 2 }}>{subtitle}</div>}
      </div>

      <div style={{ marginLeft: "auto", width: 230 }}>
        <Input iconLeft={<Ico n="search" s={15} />} placeholder="Search agents, runs…" size="sm" />
      </div>
      <IconButton label="Notifications" variant="ghost"><Ico n="bell" /></IconButton>
      <Button variant="primary" onClick={onDeploy} iconLeft={<Ico n={deploying ? "loader" : "rocket"} s={15} />}>
        {deploying ? "Deploying…" : "Deploy agent"}
      </Button>
      <div style={{ width: 1, height: 28, background: "var(--border-default)" }} />
      <Avatar name="Maya Okonkwo" status="active" />
    </header>
  );
}
window.TopBar = TopBar;
