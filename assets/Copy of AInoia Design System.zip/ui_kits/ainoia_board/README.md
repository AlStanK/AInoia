# AInoia Board — UI Kit

An interactive, high-fidelity recreation of the **AInoia Board** — the agent
orchestration control plane shown in the brand infographic. *Orchestrate. Monitor.
Optimize.*

> Reconstructed from the supplied infographic dashboard crop (no product codebase was
> provided). Visuals follow the design-system tokens; data is illustrative.

## Run
Open `index.html`. It loads the compiled `_ds_bundle.js`, React UMD, Babel and Lucide,
then mounts `BoardApp`.

## Structure
- `index.html` — app shell, state, view routing, deploy flow + toast, Integrations view.
- `Sidebar.jsx` — left navigation rail with wordmark and infra status.
- `TopBar.jsx` — title, search, **Deploy agent** action, identity.
- `AgentsPanel.jsx` — agent orchestration list (composes `AgentRow`, `Switch`, `Badge`).
- `WorkflowCanvas.jsx` — live hub-and-spoke execution graph (Trigger · Process ·
  Integration · Response) with animated connectors when running.
- `PerformancePanel.jsx` — KPI `StatCard`s + success-rate line chart + executions bars.

## Interactions
- Click an agent → selects it; the workflow graph + status update.
- **Deploy agent** → 1.5s deploying state, then a new agent appears with a glass toast.
- Sidebar nav switches focus: Overview / Agents / Workflows / Performance / Integrations.
- Toggle **Autonomous mode**.

## Composition
The kit reuses the system primitives (`Button`, `Card`, `StatCard`, `AgentRow`, `Badge`,
`Switch`, `Avatar`, `Input`, `IconButton`) via `window.CODISAIDesignSystem_b12028`. Local
modules attach to `window` (Babel script scope) and never re-implement primitives.
