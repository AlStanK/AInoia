/* global React */
// AInoia Board — left navigation rail
function Sidebar({ active, onNavigate }) {
  const items = [
    { id: "overview", icon: "layout-dashboard", label: "Overview" },
    { id: "agents", icon: "bot", label: "Agents" },
    { id: "workflows", icon: "workflow", label: "Workflows" },
    { id: "performance", icon: "line-chart", label: "Performance" },
    { id: "integrations", icon: "blocks", label: "Integrations" },
  ];
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  return (
    <aside style={{
      width: 232, flex: "none", height: "100%",
      background: "var(--ink-800)",
      borderRight: "1px solid var(--border-subtle)",
      display: "flex", flexDirection: "column", padding: "20px 14px",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "4px 10px 22px" }}>
        <div style={{
          width: 30, height: 30, borderRadius: 9, background: "var(--grad-cta)",
          display: "grid", placeItems: "center", boxShadow: "var(--glow-cyan-sm)",
        }}>
          <i data-lucide="orbit" style={{ width: 17, height: 17, color: "var(--fg-on-accent)" }} />
        </div>
        <div className="ainoia-wordmark" style={{ fontSize: 17, letterSpacing: "0.22em" }}>
          <span className="ai">AI</span>noia
        </div>
      </div>

      <div style={{ fontSize: 10, letterSpacing: "0.16em", color: "var(--fg-4)", textTransform: "uppercase", padding: "0 10px 10px", fontFamily: "var(--font-display)" }}>Control plane</div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 3 }}>
        {items.map((it) => {
          const on = it.id === active;
          return (
            <button key={it.id} onClick={() => onNavigate(it.id)} style={{
              display: "flex", alignItems: "center", gap: 11,
              padding: "10px 11px", borderRadius: "var(--radius-md)",
              border: `1px solid ${on ? "var(--border-glow)" : "transparent"}`,
              background: on ? "rgba(192,160,128,0.09)" : "transparent",
              color: on ? "var(--fg-1)" : "var(--fg-3)",
              fontFamily: "var(--font-body)", fontSize: 14, fontWeight: on ? 600 : 500,
              cursor: "pointer", textAlign: "left", transition: "all var(--dur-base) var(--ease-out)",
            }}
              onMouseEnter={(e) => { if (!on) { e.currentTarget.style.background = "var(--ink-600)"; e.currentTarget.style.color = "var(--fg-2)"; } }}
              onMouseLeave={(e) => { if (!on) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--fg-3)"; } }}
            >
              <i data-lucide={it.icon} style={{ width: 17, height: 17, color: on ? "var(--cyan)" : "currentColor" }} />
              {it.label}
            </button>
          );
        })}
      </nav>

      <div style={{ marginTop: "auto" }}>
        <div style={{
          background: "var(--ink-700)", border: "1px solid var(--border-subtle)",
          borderRadius: "var(--radius-lg)", padding: 14,
        }}>
          <div style={{ fontSize: 12, color: "var(--fg-2)", fontWeight: 600, marginBottom: 4 }}>Deployed in your infra</div>
          <div style={{ fontSize: 11.5, color: "var(--fg-4)", lineHeight: 1.5 }}>eu-central · 4 nodes · healthy</div>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginTop: 9 }}>
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--success)", boxShadow: "0 0 6px var(--success)" }} />
            <span style={{ fontSize: 11.5, color: "var(--success)", fontFamily: "var(--font-mono)" }}>all systems nominal</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
window.Sidebar = Sidebar;
