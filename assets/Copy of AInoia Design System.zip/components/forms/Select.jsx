import React from "react";
import { radius as rad, dataAttr, controlH } from "../core/theme.jsx";

/**
 * AInoia — Select / SelectItem (HeroUI-aligned)
 * Custom trigger + listbox popover. Single or multiple selection.
 * items: [{ key, label, description?, startContent?, isDisabled? }] or <SelectItem key=… > children.
 * selectedKeys / defaultSelectedKeys (Set|array) + onSelectionChange(Set). Keyboard: ↑↓ Home End Enter Space Esc, type-ahead.
 */
export function SelectItem() { return null; }
SelectItem.__ainoiaSelectItem = true;

export function Select({
  label, description, errorMessage, placeholder = "Select an option",
  items, children, selectedKeys, defaultSelectedKeys = [], onSelectionChange, selectionMode = "single", disallowEmptySelection = false,
  variant = "faded", size = "md", radius = "md", labelPlacement = "outside", fullWidth = true,
  isInvalid = false, isDisabled = false, isRequired = false, isLoading = false, isClearable = false, disabledKeys = [],
  startContent, endContent, selectorIcon, renderValue, onClear, name, isOpen: isOpenProp, defaultOpen = false, onOpenChange,
  style = {}, className, ...rest
}) {
  const list = items || React.Children.toArray(children).filter((c) => c && c.type && c.type.__ainoiaSelectItem).map((c) => { const { children: lbl, value, ...p } = c.props; return { ...p, key: c.key != null ? String(c.key).replace(/^\.\$/, "") : value, label: lbl }; });
  const toSet = (v) => new Set(v instanceof Set ? v : Array.isArray(v) ? v : v == null ? [] : [v]);
  const [inner, setInner] = React.useState(() => toSet(defaultSelectedKeys));
  const sel = selectedKeys !== undefined ? toSet(selectedKeys) : inner;
  const [openInner, setOpenInner] = React.useState(defaultOpen);
  const open = isOpenProp ?? openInner;
  const setOpen = (o) => { if (isDisabled) return; if (isOpenProp === undefined) setOpenInner(o); onOpenChange && onOpenChange(o); };
  const [hover, setHover] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const [active, setActive] = React.useState(-1);
  const uid = React.useId();
  const base = `sel-${uid}`;
  const rootRef = React.useRef(null), listRef = React.useRef(null), trigRef = React.useRef(null);
  const disabled = new Set(disabledKeys);
  const enabled = list.filter((it) => !it.isDisabled && !disabled.has(it.key));
  const invalid = isInvalid;

  const commit = (s) => { if (selectedKeys === undefined) setInner(s); onSelectionChange && onSelectionChange(s); };
  const pick = (key) => {
    const s = new Set(sel);
    if (selectionMode === "multiple") { if (s.has(key)) { if (!(disallowEmptySelection && s.size === 1)) s.delete(key); } else s.add(key); commit(s); }
    else { if (s.has(key) && !disallowEmptySelection) commit(new Set()); else commit(new Set([key])); setOpen(false); trigRef.current && trigRef.current.focus(); }
  };
  const clear = () => { commit(new Set()); onClear && onClear(); trigRef.current && trigRef.current.focus(); };

  React.useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc); return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);
  React.useEffect(() => {
    if (!open) return;
    const first = enabled.findIndex((it) => sel.has(it.key));
    setActive(first >= 0 ? first : 0);
    requestAnimationFrame(() => listRef.current && listRef.current.focus());
  }, [open]);

  const typeRef = React.useRef({ s: "", t: 0 });
  const onListKey = (e) => {
    const n = enabled.length; if (!n) return;
    if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => (a + 1) % n); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => (a - 1 + n) % n); }
    else if (e.key === "Home") { e.preventDefault(); setActive(0); }
    else if (e.key === "End") { e.preventDefault(); setActive(n - 1); }
    else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); enabled[active] && pick(enabled[active].key); }
    else if (e.key === "Escape" || e.key === "Tab") { setOpen(false); trigRef.current && trigRef.current.focus(); if (e.key === "Escape") e.preventDefault(); }
    else if (e.key.length === 1) {
      const now = Date.now(); const t = typeRef.current; t.s = now - t.t < 600 ? t.s + e.key : e.key; t.t = now;
      const i = enabled.findIndex((it) => String(it.label).toLowerCase().startsWith(t.s.toLowerCase())); if (i >= 0) setActive(i);
    }
  };
  const onTrigKey = (e) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp" || e.key === "Enter" || e.key === " ") { e.preventDefault(); setOpen(true); }
  };

  const chosen = list.filter((it) => sel.has(it.key));
  const valueNode = renderValue ? renderValue(chosen) : chosen.length ? chosen.map((it, i) => <React.Fragment key={it.key}>{i > 0 && ", "}{it.label}</React.Fragment>) : null;
  const border = invalid ? "var(--danger)" : open || focusVisible ? "var(--cyan)" : hover ? "var(--border-strong)" : "var(--border-default)";
  const shells = {
    faded: { background: "var(--ink-800)", border: `1px solid ${border}`, borderRadius: rad(radius) },
    flat: { background: hover || open ? "var(--ink-500)" : "var(--ink-600)", border: `1px solid ${invalid ? "var(--danger)" : "transparent"}`, borderRadius: rad(radius) },
    bordered: { background: "transparent", border: `1px solid ${border}`, borderRadius: rad(radius) },
    underlined: { background: "transparent", border: "none", borderBottom: `1px solid ${border}`, borderRadius: 0 },
  };
  const side = labelPlacement === "outside-left";
  const descId = description ? `${base}-desc` : undefined, errId = invalid && errorMessage ? `${base}-err` : undefined;
  const chevron = selectorIcon || <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6l4 4 4-4" /></svg>;

  return (
    <div ref={rootRef} className={className} data-slot="base" data-open={dataAttr(open)} data-invalid={dataAttr(invalid)} data-disabled={dataAttr(isDisabled)} data-has-value={dataAttr(chosen.length > 0)}
      style={{ position: "relative", display: "flex", flexDirection: side ? "row" : "column", alignItems: side ? "center" : "stretch", gap: side ? 12 : 7, width: fullWidth ? "100%" : "auto", opacity: isDisabled ? 0.5 : 1, fontFamily: "var(--font-body)", ...style }} {...rest}>
      {label && <span id={`${base}-label`} style={{ fontSize: "var(--text-sm)", color: invalid ? "var(--danger)" : "var(--fg-2)", fontWeight: 500, whiteSpace: side ? "nowrap" : undefined }}>{label}{isRequired && <span aria-hidden="true" style={{ color: "var(--danger)", marginLeft: 3 }}>*</span>}</span>}
      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 6, flex: 1, minWidth: 0 }}>
        <button ref={trigRef} type="button" data-slot="trigger" role="combobox" aria-haspopup="listbox" aria-expanded={open} aria-controls={open ? `${base}-list` : undefined}
          aria-labelledby={label ? `${base}-label ${base}-value` : undefined} aria-label={!label ? placeholder : undefined} aria-invalid={invalid || undefined} aria-required={isRequired || undefined}
          aria-describedby={[descId, errId].filter(Boolean).join(" ") || undefined} disabled={isDisabled}
          data-hover={dataAttr(hover)} data-focus-visible={dataAttr(focusVisible)} data-open={dataAttr(open)}
          onClick={() => setOpen(!open)} onKeyDown={onTrigKey}
          onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
          onFocus={(e) => { try { setFocusVisible(e.target.matches(":focus-visible")); } catch (_) { setFocusVisible(true); } }} onBlur={() => setFocusVisible(false)}
          style={{ display: "flex", alignItems: "center", gap: 9, boxSizing: "border-box", width: "100%", height: controlH[size] || controlH.md, padding: variant === "underlined" ? "0 2px" : "0 13px",
            textAlign: "left", cursor: isDisabled ? "not-allowed" : "pointer", color: "var(--fg-1)", fontFamily: "inherit", fontSize: size === "sm" ? "var(--text-sm)" : "var(--text-base)",
            boxShadow: (open || focusVisible) && !invalid && variant !== "underlined" ? "var(--glow-cyan-sm)" : "none",
            transition: "border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)", ...(shells[variant] || shells.faded) }}>
          {startContent && <span aria-hidden="true" style={{ color: "var(--fg-3)", display: "inline-flex", flex: "none" }}>{startContent}</span>}
          <span id={`${base}-value`} data-slot="value" style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: chosen.length ? "var(--fg-1)" : "var(--fg-4)" }}>{valueNode ?? placeholder}</span>
          {isClearable && chosen.length > 0 && !isDisabled && <span role="button" tabIndex={-1} aria-label="clear selection" onClick={(e) => { e.stopPropagation(); clear(); }} style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 18, height: 18, borderRadius: "50%", background: "var(--ink-500)", color: "var(--fg-2)", fontSize: 13, lineHeight: 1, flex: "none" }}>×</span>}
          {endContent}
          <span aria-hidden="true" data-slot="selectorIcon" style={{ display: "inline-flex", flex: "none", color: "var(--fg-3)", transform: open ? "rotate(180deg)" : "none", transition: "transform var(--dur-base) var(--ease-out)" }}>
            {isLoading ? <span style={{ width: 14, height: 14, borderRadius: "50%", border: "2px solid", borderColor: "currentColor transparent currentColor transparent", animation: "ainoia-spin 0.8s linear infinite" }} /> : chevron}
          </span>
        </button>
        {open && (
          <ul ref={listRef} id={`${base}-list`} role="listbox" tabIndex={-1} aria-multiselectable={selectionMode === "multiple" || undefined} aria-labelledby={label ? `${base}-label` : undefined}
            aria-activedescendant={enabled[active] ? `${base}-opt-${enabled[active].key}` : undefined} onKeyDown={onListKey} data-slot="listbox"
            style={{ position: "absolute", top: "calc(100% + 5px)", left: 0, right: 0, zIndex: 40, margin: 0, padding: 6, listStyle: "none", maxHeight: 256, overflowY: "auto", boxSizing: "border-box", outline: "none",
              background: "var(--ink-700)", border: "1px solid var(--border-strong)", borderRadius: rad(radius === "none" ? "none" : "lg"), boxShadow: "var(--shadow-lg)", backdropFilter: "var(--blur-subtle)" }}>
            {list.length === 0 && <li style={{ padding: "10px 12px", fontSize: "var(--text-sm)", color: "var(--fg-4)" }}>No items.</li>}
            {list.map((it) => {
              const off = it.isDisabled || disabled.has(it.key); const isSel = sel.has(it.key); const idx = enabled.indexOf(it); const isAct = idx === active;
              return (
                <li key={it.key} id={`${base}-opt-${it.key}`} role="option" aria-selected={isSel} aria-disabled={off || undefined} data-selected={dataAttr(isSel)} data-hover={dataAttr(isAct)} data-disabled={dataAttr(off)}
                  onMouseMove={() => !off && idx !== active && setActive(idx)} onClick={() => !off && pick(it.key)}
                  style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", minHeight: 36, boxSizing: "border-box", borderRadius: "var(--radius-sm)", cursor: off ? "not-allowed" : "pointer", opacity: off ? 0.4 : 1,
                    background: isAct && !off ? "var(--ink-500)" : "transparent", color: isSel ? "var(--fg-1)" : "var(--fg-2)", fontSize: "var(--text-sm)", transition: "background var(--dur-fast)" }}>
                  {it.startContent && <span aria-hidden="true" style={{ display: "inline-flex", flex: "none", color: "var(--fg-3)" }}>{it.startContent}</span>}
                  <span style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 1 }}>
                    <span data-label="true" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontWeight: isSel ? 600 : 400 }}>{it.label}</span>
                    {it.description && <span style={{ fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{it.description}</span>}
                  </span>
                  <svg aria-hidden="true" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="var(--cyan)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flex: "none", opacity: isSel ? 1 : 0 }}><path d="M3 8.5l3.2 3L13 4.5" /></svg>
                </li>
              );
            })}
          </ul>
        )}
        {name && <select name={name} multiple={selectionMode === "multiple"} value={selectionMode === "multiple" ? [...sel] : [...sel][0] ?? ""} onChange={() => {}} tabIndex={-1} aria-hidden="true" style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }}>{[...sel].map((k) => <option key={k} value={k}>{k}</option>)}<option value="" /></select>}
        {(description || (invalid && errorMessage)) && (
          <div data-slot="helper-wrapper" style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {description && <span id={descId} style={{ fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{description}</span>}
            {invalid && errorMessage && <span id={errId} role="alert" style={{ fontSize: "var(--text-xs)", color: "var(--danger)" }}>{errorMessage}</span>}
          </div>
        )}
      </div>
    </div>
  );
}
