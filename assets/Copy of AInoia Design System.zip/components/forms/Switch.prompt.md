Toggle with the gradient track when on. 44px hit target; global focus ring.

```jsx
<Switch isSelected={auto} onValueChange={setAuto}>Autonomous mode</Switch>
<Switch defaultSelected size="sm" color="success">Notifications</Switch>
<Switch isDisabled>Sandbox (locked)</Switch>
```

Props: `isSelected` / `defaultSelected` / `onValueChange`, `isDisabled`, `isReadOnly`, `size sm|md|lg`, `color`, `thumbIcon`, `startContent`, `endContent`, `name`, `value`. Legacy `checked` / `onChange(bool)` / `label` still map.
