Dropdown selection with keyboard navigation and type-ahead.

```jsx
<Select label="Region" items={regions} defaultSelectedKeys={["eu"]} onSelectionChange={(s) => setRegion([...s][0])} />
<Select label="Tags" selectionMode="multiple" isClearable>
  <SelectItem key="a">Finance</SelectItem><SelectItem key="b">Ops</SelectItem>
</Select>
```

Props: `items | <SelectItem>`, `selectedKeys/defaultSelectedKeys/onSelectionChange(Set)`, `selectionMode`, `disabledKeys`, `isLoading`, `renderValue`, `variant`, `name` (hidden native select). Item fields: `key, label, description, startContent, isDisabled`.