import React from "react";
import { color as pal, radius as rad, dataAttr } from "../core/theme.jsx";

/**
 * AInoia — Checkbox / CheckboxGroup (HeroUI-aligned)
 * Native <input type="checkbox"> inside a <label>; the visible box is aria-hidden.
 * Controlled: isSelected + onValueChange. Uncontrolled: defaultSelected.
 * Group: value / defaultValue (string[]) + onValueChange(string[]).
 */
const GroupCtx = React.createContext(null);

const DIM = { sm: 16, md: 20, lg: 24 };
const FS = { sm: "var(--text-sm)", md: "var(--text-base)", lg: "var(--text-md)" };

export function Checkbox({
  isSelected, defaultSelected = false, onValueChange, value = "",
  isDisabled, isReadOnly = false, isRequired = false, isInvalid, isIndeterminate = false,
  size, color, radius = "sm", lineThrough = false, icon, name,
  children, style = {}, ...rest
}) {
  const g = React.useContext(GroupCtx);
  size = size || g?.size || "md"; color = color || g?.color || "primary";
  isDisabled = isDisabled ?? g?.isDisabled ?? false; isInvalid = isInvalid ?? g?.isInvalid ?? false;
  const inGroup = !!g;
  const [inner, setInner] = React.useState(defaultSelected);
  const on = inGroup ? g.value.includes(value) : isSelected !== undefined ? isSelected : inner;
  const [hover, setHover] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => { if (ref.current) ref.current.indeterminate = isIndeterminate; }, [isIndeterminate]);
  const uid = React.useId();
  const k = pal(isInvalid ? "danger" : color);
  const d = DIM[size] || DIM.md;
  const fill = on || isIndeterminate;

  const handle = (e) => {
    if (isDisabled || isReadOnly) { e.preventDefault(); return; }
    const next = e.target.checked;
    if (inGroup) g.toggle(value, next);
    else { if (isSelected === undefined) setInner(next); onValueChange && onValueChange(next); }
  };
  const bg = fill ? (color === "primary" && !isInvalid ? "var(--grad-cta)" : k.solidBg) : hover && !isDisabled ? "var(--ink-500)" : "transparent";
  const mark = isIndeterminate
    ? <span style={{ width: d * 0.5, height: 2, background: k.solidFg, borderRadius: 1 }} />
    : <svg viewBox="0 0 16 16" width={d * 0.65} height={d * 0.65} fill="none" stroke={k.solidFg} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: on ? "scale(1)" : "scale(0.6)", opacity: on ? 1 : 0, transition: "transform var(--dur-fast) var(--ease-spark), opacity var(--dur-fast)" }}><path d="M3 8.5l3.2 3L13 4.5" /></svg>;

  return (
    <label
      data-selected={dataAttr(fill)} data-disabled={dataAttr(isDisabled)} data-invalid={dataAttr(isInvalid)}
      data-hover={dataAttr(hover)} data-focus-visible={dataAttr(focusVisible)} data-indeterminate={dataAttr(isIndeterminate)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: "10px", minHeight: 44, cursor: isDisabled ? "not-allowed" : "pointer", opacity: isDisabled ? 0.5 : 1, fontFamily: "var(--font-body)", WebkitTapHighlightColor: "transparent", ...style }}
      {...rest}
    >
      <input
        ref={ref} type="checkbox" name={name || g?.name} value={value} checked={on} disabled={isDisabled}
        required={isRequired} aria-invalid={isInvalid || undefined} aria-readonly={isReadOnly || undefined}
        aria-labelledby={children ? `cb-${uid}` : undefined} aria-label={!children ? rest["aria-label"] : undefined}
        onChange={handle}
        onFocus={(e) => { try { setFocusVisible(e.target.matches(":focus-visible")); } catch (_) { setFocusVisible(true); } }}
        onBlur={() => setFocusVisible(false)}
        style={{ position: "absolute", width: 44, height: 44, opacity: 0, margin: 0, cursor: "inherit", left: d / 2 - 22, top: "50%", transform: "translateY(-50%)" }}
      />
      <span aria-hidden="true" style={{
        width: d, height: d, flex: "none", boxSizing: "border-box", display: "flex", alignItems: "center", justifyContent: "center",
        borderRadius: rad(radius, "sm"), background: bg,
        border: `1.5px solid ${fill ? "transparent" : isInvalid ? "var(--danger)" : hover ? "var(--border-strong)" : "var(--border-default)"}`,
        boxShadow: fill && color === "primary" && !isInvalid ? k.glow : "none",
        outline: focusVisible ? "2px solid var(--focus-ring)" : "none", outlineOffset: 2,
        transition: "background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)",
      }}>{icon ? (typeof icon === "function" ? icon({ isSelected: on, isIndeterminate }) : on ? icon : null) : mark}</span>
      {children && <span id={`cb-${uid}`} style={{ fontSize: FS[size] || FS.md, color: isInvalid ? "var(--danger)" : "var(--fg-2)", textDecoration: lineThrough && on ? "line-through" : "none", opacity: lineThrough && on ? 0.6 : 1, transition: "opacity var(--dur-base)" }}>{children}</span>}
    </label>
  );
}

export function CheckboxGroup({
  label, description, errorMessage, value, defaultValue = [], onValueChange,
  orientation = "vertical", size = "md", color = "primary", isDisabled = false, isInvalid = false, isRequired = false, name,
  children, style = {}, ...rest
}) {
  const [inner, setInner] = React.useState(defaultValue);
  const val = value !== undefined ? value : inner;
  const toggle = (v, next) => {
    const set = next ? [...new Set([...val, v])] : val.filter((x) => x !== v);
    if (value === undefined) setInner(set); onValueChange && onValueChange(set);
  };
  const uid = React.useId();
  return (
    <div role="group" aria-labelledby={label ? `cbg-${uid}` : undefined} aria-describedby={description ? `cbg-${uid}-d` : undefined} aria-invalid={isInvalid || undefined} aria-required={isRequired || undefined}
      data-orientation={orientation} data-invalid={dataAttr(isInvalid)} data-disabled={dataAttr(isDisabled)}
      style={{ display: "flex", flexDirection: "column", gap: 6, fontFamily: "var(--font-body)", ...style }} {...rest}>
      {label && <span id={`cbg-${uid}`} style={{ fontSize: "var(--text-sm)", fontWeight: 500, color: isInvalid ? "var(--danger)" : "var(--fg-2)" }}>{label}{isRequired && <span aria-hidden="true" style={{ color: "var(--danger)", marginLeft: 3 }}>*</span>}</span>}
      <GroupCtx.Provider value={{ value: val, toggle, size, color, isDisabled, isInvalid, name }}>
        <div style={{ display: "flex", flexDirection: orientation === "horizontal" ? "row" : "column", flexWrap: "wrap", gap: orientation === "horizontal" ? "4px 20px" : 0 }}>{children}</div>
      </GroupCtx.Provider>
      {description && !isInvalid && <span id={`cbg-${uid}-d`} style={{ fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{description}</span>}
      {isInvalid && errorMessage && <span role="alert" style={{ fontSize: "var(--text-xs)", color: "var(--danger)" }}>{errorMessage}</span>}
    </div>
  );
}
