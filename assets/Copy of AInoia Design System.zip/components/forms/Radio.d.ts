import * as React from "react";
import type { Color, Size } from "../core/Button";

export interface RadioGroupProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "color" | "onChange"> {
  label?: React.ReactNode;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  value?: string | null;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  name?: string;
  orientation?: "horizontal" | "vertical";
  size?: Size;
  color?: Color;
  isDisabled?: boolean;
  isInvalid?: boolean;
  isRequired?: boolean;
  isReadOnly?: boolean;
  children?: React.ReactNode;
}
export interface RadioProps extends Omit<React.LabelHTMLAttributes<HTMLLabelElement>, "color"> {
  value: string;
  description?: React.ReactNode;
  isDisabled?: boolean;
  size?: Size;
  color?: Color;
  children?: React.ReactNode;
}
/** role="radiogroup"; owns the selected value. */
export function RadioGroup(props: RadioGroupProps): JSX.Element;
/** Must be a child of RadioGroup. */
export function Radio(props: RadioProps): JSX.Element;
