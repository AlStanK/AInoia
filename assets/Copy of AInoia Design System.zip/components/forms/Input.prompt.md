Text field on the dark canvas. Focus lights the hairline tan with a soft glow; invalid turns it terracotta.

```jsx
<Input label="Agent name" defaultValue="Incident Resolver" />
<Input label="Search" startContent={<Icon name="search" />} placeholder="Filter…" isClearable />
<Input label="Endpoint" description="Region-local routing applies." />
<Input label="API token" isRequired isInvalid errorMessage="This field is required." />
<Input label="Name" labelPlacement="outside-left" variant="bordered" />
```

Variants `faded (default) | flat | bordered | underlined`; sizes `sm | md | lg`; radius. Props: `isInvalid`, `isDisabled`, `isRequired`, `isReadOnly`, `isClearable`, `startContent`, `endContent`, `value` / `onValueChange`. Legacy `hint`, `error`, `iconLeft` still map.
