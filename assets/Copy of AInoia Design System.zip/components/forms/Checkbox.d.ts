import * as React from "react";
import type { Color, Radius, Size } from "../core/Button";

export interface CheckboxProps extends Omit<React.LabelHTMLAttributes<HTMLLabelElement>, "onChange" | "color"> {
  isSelected?: boolean;
  defaultSelected?: boolean;
  onValueChange?: (isSelected: boolean) => void;
  /** Value reported to a CheckboxGroup. */
  value?: string;
  isDisabled?: boolean;
  isReadOnly?: boolean;
  isRequired?: boolean;
  isInvalid?: boolean;
  isIndeterminate?: boolean;
  size?: Size;
  color?: Color;
  radius?: Radius;
  /** Strikes the label when selected. */
  lineThrough?: boolean;
  icon?: React.ReactNode | ((p: { isSelected: boolean; isIndeterminate: boolean }) => React.ReactNode);
  name?: string;
  children?: React.ReactNode;
}
export interface CheckboxGroupProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "color"> {
  label?: React.ReactNode;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  value?: string[];
  defaultValue?: string[];
  onValueChange?: (value: string[]) => void;
  orientation?: "horizontal" | "vertical";
  size?: Size;
  color?: Color;
  isDisabled?: boolean;
  isInvalid?: boolean;
  isRequired?: boolean;
  name?: string;
  children?: React.ReactNode;
}
/** Native checkbox in a label; emits data-selected / data-indeterminate / data-invalid / data-focus-visible. */
export function Checkbox(props: CheckboxProps): JSX.Element;
/** role="group" wrapper that owns the value array. */
export function CheckboxGroup(props: CheckboxGroupProps): JSX.Element;
