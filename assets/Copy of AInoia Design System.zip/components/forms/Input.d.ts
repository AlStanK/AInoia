import * as React from "react";
import type { Radius, Size } from "../core/Button";

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size" | "color" | "value" | "defaultValue"> {
  label?: React.ReactNode;
  /** Helper text under the field. */
  description?: React.ReactNode;
  /** Shown (role="alert") when isInvalid or when set. */
  errorMessage?: React.ReactNode;
  /** `faded` is the AInoia default (raised surface + hairline). */
  variant?: "faded" | "flat" | "bordered" | "underlined";
  size?: Size;
  radius?: Radius;
  labelPlacement?: "outside" | "outside-left";
  fullWidth?: boolean;
  isInvalid?: boolean;
  isDisabled?: boolean;
  isRequired?: boolean;
  isReadOnly?: boolean;
  /** Shows a clear button when filled; Esc also clears. */
  isClearable?: boolean;
  startContent?: React.ReactNode;
  endContent?: React.ReactNode;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  onClear?: () => void;
  /** @deprecated use description */
  hint?: React.ReactNode;
  /** @deprecated use errorMessage */
  error?: React.ReactNode;
  /** @deprecated use startContent */
  iconLeft?: React.ReactNode;
}

/** Text field. Emits data-focus / data-hover / data-invalid / data-disabled / data-filled on the base slot. */
export function Input(props: InputProps): JSX.Element;
