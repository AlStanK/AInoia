Single choice. Radios always sit inside a RadioGroup.

```jsx
<RadioGroup label="Approval" defaultValue="auto" onValueChange={setMode}>
  <Radio value="auto" description="No human in the loop">Autonomous</Radio>
  <Radio value="review">Require review</Radio>
</RadioGroup>
```

Group props: `value/defaultValue/onValueChange`, `orientation`, `isInvalid + errorMessage`, `size`, `color`. Radio: `value`, `description`, `isDisabled`.