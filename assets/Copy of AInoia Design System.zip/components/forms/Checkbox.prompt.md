Checkbox, standalone or inside a CheckboxGroup.

```jsx
<Checkbox defaultSelected>Notify on failure</Checkbox>
<CheckboxGroup label="Channels" orientation="horizontal" defaultValue={["email"]}>
  <Checkbox value="email">Email</Checkbox><Checkbox value="slack">Slack</Checkbox>
</CheckboxGroup>
```

Props: `isSelected/defaultSelected/onValueChange`, `value` (in group), `isIndeterminate`, `isInvalid`, `lineThrough`, `size`, `color`, `radius`. Group owns `value: string[]`.