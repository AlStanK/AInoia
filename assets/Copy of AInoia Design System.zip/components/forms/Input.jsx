import React from "react";
import { radius as rad, dataAttr, controlH } from "../core/theme.jsx";

/**
 * AInoia — Input (HeroUI-aligned)
 * variant: faded (default) | flat | bordered | underlined    labelPlacement: outside | outside-left
 * Controlled via value/onValueChange or native onChange; uncontrolled via defaultValue.
 * Legacy: hint → description, error → errorMessage (+ isInvalid), iconLeft → startContent.
 */
export function Input({
  label, description, errorMessage, placeholder,
  variant = "faded", color = "default", size = "md", radius = "md", labelPlacement = "outside", fullWidth = true,
  isInvalid = false, isDisabled = false, isRequired = false, isReadOnly = false, isClearable = false,
  startContent = null, endContent = null,
  value, defaultValue, onValueChange, onClear, onChange,
  hint, error, iconLeft, disabled, readOnly, required,
  style = {}, id, className, ...rest
}) {
  description = description ?? hint;
  errorMessage = errorMessage ?? error;
  startContent = startContent || iconLeft;
  const invalid = isInvalid || !!errorMessage;
  const off = isDisabled || disabled;
  const ro = isReadOnly || readOnly;
  const req = isRequired || required;

  const [focus, setFocus] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const [inner, setInner] = React.useState(defaultValue ?? "");
  const controlled = value !== undefined;
  const val = controlled ? value : inner;
  const ref = React.useRef(null);

  const uid = React.useId();
  const inputId = id || `in-${uid}`;
  const descId = description ? `${inputId}-desc` : undefined;
  const errId = invalid && errorMessage ? `${inputId}-err` : undefined;
  const describedBy = [descId, errId].filter(Boolean).join(" ") || undefined;

  const set = (v) => { if (!controlled) setInner(v); onValueChange && onValueChange(v); };
  const clear = () => { set(""); onClear && onClear(); ref.current && ref.current.focus(); };

  const accent = invalid ? "var(--danger)" : "var(--cyan)";
  const border = invalid ? "var(--danger)" : focus ? "var(--cyan)" : hover ? "var(--border-strong)" : "var(--border-default)";
  const shells = {
    faded:      { background: "var(--ink-800)", border: `1px solid ${border}`, borderRadius: rad(radius) },
    flat:       { background: hover || focus ? "var(--ink-500)" : "var(--ink-600)", border: `1px solid ${invalid ? "var(--danger)" : "transparent"}`, borderRadius: rad(radius) },
    bordered:   { background: "transparent", border: `1px solid ${border}`, borderRadius: rad(radius) },
    underlined: { background: "transparent", border: "none", borderBottom: `1px solid ${border}`, borderRadius: 0 },
  };
  const shell = shells[variant] || shells.faded;
  const side = labelPlacement === "outside-left";

  const labelEl = label && (
    <label htmlFor={inputId} style={{ fontSize: "var(--text-sm)", color: invalid ? "var(--danger)" : "var(--fg-2)", fontWeight: 500, whiteSpace: side ? "nowrap" : undefined }}>
      {label}{req && <span aria-hidden="true" style={{ color: "var(--danger)", marginLeft: 3 }}>*</span>}
    </label>
  );

  return (
    <div
      className={className}
      data-slot="base"
      data-focus={dataAttr(focus)} data-hover={dataAttr(hover)} data-invalid={dataAttr(invalid)}
      data-disabled={dataAttr(off)} data-readonly={dataAttr(ro)} data-required={dataAttr(req)} data-filled={dataAttr(!!val)}
      style={{ display: "flex", flexDirection: side ? "row" : "column", alignItems: side ? "center" : "stretch", gap: side ? "12px" : "7px", width: fullWidth ? "100%" : "auto", opacity: off ? 0.5 : 1, ...style }}
    >
      {labelEl}
      <div style={{ display: "flex", flexDirection: "column", gap: "6px", flex: 1, minWidth: 0 }}>
        <div
          data-slot="input-wrapper"
          onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
          onClick={(e) => { if (e.target === e.currentTarget && ref.current) ref.current.focus(); }}
          style={{
            display: "flex", alignItems: "center", gap: "9px", boxSizing: "border-box",
            height: controlH[size] || controlH.md, padding: variant === "underlined" ? "0 2px" : "0 13px",
            boxShadow: focus && !invalid && variant !== "underlined" ? "var(--glow-cyan-sm)" : "none",
            cursor: off ? "not-allowed" : "text",
            transition: "border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)",
            ...shell,
          }}
        >
          {startContent && <span aria-hidden="true" style={{ color: focus ? accent : "var(--fg-3)", display: "inline-flex", flex: "none" }}>{startContent}</span>}
          <input
            {...rest}
            ref={ref}
            id={inputId}
            value={val}
            placeholder={placeholder}
            disabled={off}
            readOnly={ro}
            required={req}
            aria-invalid={invalid || undefined}
            aria-required={req || undefined}
            aria-describedby={describedBy}
            onChange={(e) => { set(e.target.value); onChange && onChange(e); }}
            onFocus={(e) => { setFocus(true); rest.onFocus && rest.onFocus(e); }}
            onBlur={(e) => { setFocus(false); rest.onBlur && rest.onBlur(e); }}
            onKeyDown={(e) => { if (e.key === "Escape" && isClearable && val && !ro) clear(); rest.onKeyDown && rest.onKeyDown(e); }}
            style={{
              flex: 1, minWidth: 0, background: "transparent", border: "none", outline: "none", padding: 0,
              color: "var(--fg-1)", fontFamily: "var(--font-body)", fontSize: size === "sm" ? "var(--text-sm)" : "var(--text-base)",
              cursor: off ? "not-allowed" : "text",
            }}
          />
          {isClearable && val && !off && !ro && (
            <button type="button" tabIndex={-1} aria-label="clear input" onClick={clear}
              style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 18, height: 18, padding: 0, border: "none", borderRadius: "50%", background: "var(--ink-500)", color: "var(--fg-2)", cursor: "pointer", fontSize: 13, lineHeight: 1, flex: "none" }}>×</button>
          )}
          {endContent && <span style={{ color: "var(--fg-3)", display: "inline-flex", flex: "none" }}>{endContent}</span>}
        </div>
        {(description || (invalid && errorMessage)) && (
          <div data-slot="helper-wrapper" style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {description && <span id={descId} style={{ fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{description}</span>}
            {invalid && errorMessage && <span id={errId} role="alert" style={{ fontSize: "var(--text-xs)", color: "var(--danger)" }}>{errorMessage}</span>}
          </div>
        )}
      </div>
    </div>
  );
}
