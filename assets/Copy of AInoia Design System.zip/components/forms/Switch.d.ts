import * as React from "react";
import type { Color, Size } from "../core/Button";

export interface SwitchProps extends Omit<React.LabelHTMLAttributes<HTMLLabelElement>, "onChange" | "color"> {
  /** Controlled state. */
  isSelected?: boolean;
  defaultSelected?: boolean;
  onValueChange?: (isSelected: boolean) => void;
  isDisabled?: boolean;
  isReadOnly?: boolean;
  size?: Size;
  /** `primary` renders the balance gradient track. */
  color?: Color;
  thumbIcon?: React.ReactNode | ((p: { isSelected: boolean; width: string; height: string }) => React.ReactNode);
  /** Icon inside the track when on / off. */
  startContent?: React.ReactNode;
  endContent?: React.ReactNode;
  name?: string;
  value?: string;
  /** Label text. */
  children?: React.ReactNode;
  /** @deprecated use isSelected */
  checked?: boolean;
  /** @deprecated use onValueChange */
  onChange?: (next: boolean) => void;
  /** @deprecated use disabled → isDisabled */
  disabled?: boolean;
  /** @deprecated pass label as children */
  label?: React.ReactNode;
}

/** Toggle. Native checkbox with role="switch"; emits data-selected / data-focus-visible / data-hover / data-disabled. */
export function Switch(props: SwitchProps): JSX.Element;
