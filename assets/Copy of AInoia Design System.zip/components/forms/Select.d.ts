import * as React from "react";
import type { Radius, Size } from "../core/Button";

export type SelectionKeys = Set<string> | string[] | string;
export interface SelectItemData { key: string; label: React.ReactNode; description?: React.ReactNode; startContent?: React.ReactNode; isDisabled?: boolean; }
export interface SelectProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  label?: React.ReactNode;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  placeholder?: string;
  /** Data-driven items, or pass <SelectItem> children. */
  items?: SelectItemData[];
  selectedKeys?: SelectionKeys;
  defaultSelectedKeys?: SelectionKeys;
  onSelectionChange?: (keys: Set<string>) => void;
  selectionMode?: "single" | "multiple";
  disallowEmptySelection?: boolean;
  disabledKeys?: string[];
  variant?: "faded" | "flat" | "bordered" | "underlined";
  size?: Size;
  radius?: Radius;
  labelPlacement?: "outside" | "outside-left";
  fullWidth?: boolean;
  isInvalid?: boolean;
  isDisabled?: boolean;
  isRequired?: boolean;
  isLoading?: boolean;
  isClearable?: boolean;
  startContent?: React.ReactNode;
  endContent?: React.ReactNode;
  selectorIcon?: React.ReactNode;
  renderValue?: (items: SelectItemData[]) => React.ReactNode;
  onClear?: () => void;
  /** Adds a hidden native <select> for forms. */
  name?: string;
  isOpen?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (isOpen: boolean) => void;
  children?: React.ReactNode;
}
export interface SelectItemProps { key?: string; value?: string; description?: React.ReactNode; startContent?: React.ReactNode; isDisabled?: boolean; children?: React.ReactNode; }
/** Combobox trigger + listbox popover. Arrow/Home/End/type-ahead; Esc closes. */
export function Select(props: SelectProps): JSX.Element;
export function SelectItem(props: SelectItemProps): JSX.Element;
