import React from "react";
import { color as pal, dataAttr } from "../core/theme.jsx";

/**
 * AInoia — Switch (HeroUI-aligned)
 * Hidden native checkbox (role="switch") inside a label; the visible track is aria-hidden.
 * Controlled: isSelected + onValueChange. Uncontrolled: defaultSelected. Legacy: checked/onChange/label.
 * size: sm | md | lg   color: primary (gradient) | secondary | success | warning | danger | default
 */
export function Switch({
  isSelected, defaultSelected = false, onValueChange, onChange,
  isDisabled = false, isReadOnly = false, size = "md", color = "primary",
  thumbIcon, startContent, endContent, name, value = "on",
  checked, disabled, label,
  children, style = {}, ...rest
}) {
  const controlled = (isSelected ?? checked) !== undefined;
  const [inner, setInner] = React.useState(defaultSelected);
  const on = controlled ? !!(isSelected ?? checked) : inner;
  const off = isDisabled || disabled;
  const [focusVisible, setFocusVisible] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const k = pal(color);
  const dims = { sm: { w: 32, h: 18, t: 12 }, md: { w: 40, h: 22, t: 16 }, lg: { w: 48, h: 26, t: 20 } }[size] || { w: 40, h: 22, t: 16 };
  const uid = React.useId();
  const labelId = `sw-${uid}-label`;
  const lbl = children ?? label;

  const handle = (e) => {
    if (off || isReadOnly) { e.preventDefault(); return; }
    const next = e.target.checked;
    if (!controlled) setInner(next);
    onValueChange && onValueChange(next);
    onChange && onChange(next);
  };
  const onBg = color === "primary" ? "var(--grad-cta)" : k.solidBg;

  return (
    <label
      data-selected={dataAttr(on)} data-disabled={dataAttr(off)} data-readonly={dataAttr(isReadOnly)}
      data-hover={dataAttr(hover)} data-focus-visible={dataAttr(focusVisible)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: "10px", minHeight: "44px", cursor: off ? "not-allowed" : "pointer", opacity: off ? 0.5 : 1, WebkitTapHighlightColor: "transparent", ...style }}
      {...rest}
    >
      <input
        type="checkbox" role="switch" name={name} value={value}
        checked={on} disabled={off} aria-readonly={isReadOnly || undefined}
        aria-checked={on} aria-labelledby={lbl ? labelId : undefined} aria-label={!lbl ? rest["aria-label"] : undefined}
        onChange={handle}
        onFocus={(e) => { try { setFocusVisible(e.target.matches(":focus-visible")); } catch (_) { setFocusVisible(true); } }}
        onBlur={() => setFocusVisible(false)}
        style={{ position: "absolute", width: 44, height: 44, opacity: 0, margin: 0, cursor: "inherit", left: dims.w / 2 - 22, top: "50%", transform: "translateY(-50%)" }}
      />
      <span
        aria-hidden="true"
        style={{
          position: "relative", width: dims.w, height: dims.h, flex: "none", boxSizing: "border-box",
          display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 5px",
          borderRadius: "var(--radius-pill)",
          background: on ? onBg : hover && !off ? "var(--ink-400)" : "var(--ink-500)",
          border: `1px solid ${on ? k.border : "var(--border-default)"}`,
          boxShadow: on ? k.glow : "none",
          outline: focusVisible ? "2px solid var(--focus-ring)" : "none", outlineOffset: 2,
          transition: "background var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)",
        }}
      >
        <span style={{ display: "inline-flex", fontSize: dims.t * 0.7, color: k.solidFg, opacity: on ? 1 : 0, transition: "opacity var(--dur-base)" }}>{startContent}</span>
        <span style={{ display: "inline-flex", fontSize: dims.t * 0.7, color: "var(--fg-2)", opacity: on ? 0 : 1, transition: "opacity var(--dur-base)" }}>{endContent}</span>
        <span style={{
          position: "absolute", top: 2, left: on ? dims.w - dims.t - 4 : 2,
          width: dims.t, height: dims.t, borderRadius: "50%",
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: dims.t * 0.65,
          background: on ? k.solidFg : "var(--fg-2)", color: on ? onBg : "var(--ink-800)",
          transition: "left var(--dur-base) var(--ease-spark)",
        }}>
          {typeof thumbIcon === "function" ? thumbIcon({ isSelected: on, width: "1em", height: "1em" }) : thumbIcon}
        </span>
      </span>
      {lbl && <span id={labelId} style={{ fontSize: "var(--text-base)", color: "var(--fg-2)" }}>{lbl}</span>}
    </label>
  );
}
