import React from "react";
import { radius as rad, dataAttr } from "../core/theme.jsx";

/**
 * AInoia — Textarea (HeroUI-aligned)
 * Multi-line Input. Same shell variants (faded | flat | bordered | underlined), auto-grows between minRows and maxRows.
 */
export function Textarea({
  label, description, errorMessage, placeholder,
  variant = "faded", size = "md", radius = "md", labelPlacement = "outside", fullWidth = true,
  isInvalid = false, isDisabled = false, isRequired = false, isReadOnly = false, isClearable = false,
  minRows = 3, maxRows = 8, disableAutosize = false, startContent, endContent,
  value, defaultValue, onValueChange, onClear, onChange,
  style = {}, id, className, ...rest
}) {
  const invalid = isInvalid || !!errorMessage && isInvalid;
  const [focus, setFocus] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const [inner, setInner] = React.useState(defaultValue ?? "");
  const controlled = value !== undefined;
  const val = controlled ? value : inner;
  const ref = React.useRef(null);
  const uid = React.useId();
  const taId = id || `ta-${uid}`;
  const descId = description ? `${taId}-desc` : undefined;
  const errId = invalid && errorMessage ? `${taId}-err` : undefined;
  const lh = 22;

  React.useEffect(() => {
    const el = ref.current; if (!el || disableAutosize) return;
    el.style.height = "auto";
    const h = Math.min(Math.max(el.scrollHeight, minRows * lh), maxRows * lh);
    el.style.height = h + "px"; el.style.overflowY = el.scrollHeight > h ? "auto" : "hidden";
  }, [val, minRows, maxRows, disableAutosize]);

  const set = (v) => { if (!controlled) setInner(v); onValueChange && onValueChange(v); };
  const clear = () => { set(""); onClear && onClear(); ref.current && ref.current.focus(); };
  const border = invalid ? "var(--danger)" : focus ? "var(--cyan)" : hover ? "var(--border-strong)" : "var(--border-default)";
  const shells = {
    faded: { background: "var(--ink-800)", border: `1px solid ${border}`, borderRadius: rad(radius) },
    flat: { background: hover || focus ? "var(--ink-500)" : "var(--ink-600)", border: `1px solid ${invalid ? "var(--danger)" : "transparent"}`, borderRadius: rad(radius) },
    bordered: { background: "transparent", border: `1px solid ${border}`, borderRadius: rad(radius) },
    underlined: { background: "transparent", border: "none", borderBottom: `1px solid ${border}`, borderRadius: 0 },
  };
  const side = labelPlacement === "outside-left";

  return (
    <div className={className} data-slot="base" data-focus={dataAttr(focus)} data-hover={dataAttr(hover)} data-invalid={dataAttr(invalid)} data-disabled={dataAttr(isDisabled)} data-filled={dataAttr(!!val)}
      style={{ display: "flex", flexDirection: side ? "row" : "column", alignItems: side ? "flex-start" : "stretch", gap: side ? 12 : 7, width: fullWidth ? "100%" : "auto", opacity: isDisabled ? 0.5 : 1, fontFamily: "var(--font-body)", ...style }}>
      {label && <label htmlFor={taId} style={{ fontSize: "var(--text-sm)", color: invalid ? "var(--danger)" : "var(--fg-2)", fontWeight: 500, whiteSpace: side ? "nowrap" : undefined, paddingTop: side ? 10 : 0 }}>{label}{isRequired && <span aria-hidden="true" style={{ color: "var(--danger)", marginLeft: 3 }}>*</span>}</label>}
      <div style={{ display: "flex", flexDirection: "column", gap: 6, flex: 1, minWidth: 0 }}>
        <div data-slot="input-wrapper" onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
          style={{ display: "flex", alignItems: "flex-start", gap: 9, boxSizing: "border-box", padding: variant === "underlined" ? "8px 2px" : "9px 13px",
            boxShadow: focus && !invalid && variant !== "underlined" ? "var(--glow-cyan-sm)" : "none", cursor: isDisabled ? "not-allowed" : "text",
            transition: "border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)", ...(shells[variant] || shells.faded) }}>
          {startContent && <span aria-hidden="true" style={{ color: "var(--fg-3)", display: "inline-flex", flex: "none", paddingTop: 2 }}>{startContent}</span>}
          <textarea {...rest} ref={ref} id={taId} value={val} placeholder={placeholder} disabled={isDisabled} readOnly={isReadOnly} required={isRequired} rows={minRows}
            aria-invalid={invalid || undefined} aria-required={isRequired || undefined} aria-describedby={[descId, errId].filter(Boolean).join(" ") || undefined}
            onChange={(e) => { set(e.target.value); onChange && onChange(e); }}
            onFocus={(e) => { setFocus(true); rest.onFocus && rest.onFocus(e); }} onBlur={(e) => { setFocus(false); rest.onBlur && rest.onBlur(e); }}
            style={{ flex: 1, minWidth: 0, resize: disableAutosize ? "vertical" : "none", background: "transparent", border: "none", outline: "none", padding: 0, margin: 0, lineHeight: lh + "px",
              color: "var(--fg-1)", fontFamily: "var(--font-body)", fontSize: size === "sm" ? "var(--text-sm)" : "var(--text-base)", cursor: isDisabled ? "not-allowed" : "text" }} />
          {isClearable && val && !isDisabled && !isReadOnly && <button type="button" tabIndex={-1} aria-label="clear input" onClick={clear} style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 18, height: 18, padding: 0, border: "none", borderRadius: "50%", background: "var(--ink-500)", color: "var(--fg-2)", cursor: "pointer", fontSize: 13, lineHeight: 1, flex: "none" }}>×</button>}
          {endContent && <span style={{ color: "var(--fg-3)", display: "inline-flex", flex: "none" }}>{endContent}</span>}
        </div>
        {(description || (invalid && errorMessage)) && (
          <div data-slot="helper-wrapper" style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {description && <span id={descId} style={{ fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{description}</span>}
            {invalid && errorMessage && <span id={errId} role="alert" style={{ fontSize: "var(--text-xs)", color: "var(--danger)" }}>{errorMessage}</span>}
          </div>
        )}
      </div>
    </div>
  );
}
