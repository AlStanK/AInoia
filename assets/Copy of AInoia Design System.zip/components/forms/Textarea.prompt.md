Multi-line text. Same shell variants as Input; auto-grows between `minRows` and `maxRows`.

```jsx
<Textarea label="System prompt" placeholder="You are…" minRows={3} maxRows={8} />
<Textarea label="Notes" variant="bordered" isInvalid errorMessage="Required" />
```

Props: `value/defaultValue/onValueChange`, `variant faded|flat|bordered|underlined`, `description`, `errorMessage`, `isClearable`, `disableAutosize`.