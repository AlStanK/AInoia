import * as React from "react";
import type { Radius, Size } from "../core/Button";

export interface TextareaProps extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "size" | "value" | "defaultValue" | "onChange"> {
  label?: React.ReactNode;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  variant?: "faded" | "flat" | "bordered" | "underlined";
  size?: Size;
  radius?: Radius;
  labelPlacement?: "outside" | "outside-left";
  fullWidth?: boolean;
  isInvalid?: boolean;
  isDisabled?: boolean;
  isRequired?: boolean;
  isReadOnly?: boolean;
  isClearable?: boolean;
  /** Auto-grow bounds (rows). */
  minRows?: number;
  maxRows?: number;
  disableAutosize?: boolean;
  startContent?: React.ReactNode;
  endContent?: React.ReactNode;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  onClear?: () => void;
  onChange?: React.ChangeEventHandler<HTMLTextAreaElement>;
}
/** Multi-line Input with the same shell variants. */
export function Textarea(props: TextareaProps): JSX.Element;
