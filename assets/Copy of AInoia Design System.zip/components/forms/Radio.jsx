import React from "react";
import { color as pal, dataAttr } from "../core/theme.jsx";

/**
 * AInoia — RadioGroup / Radio (HeroUI-aligned)
 * Radios must live inside a RadioGroup. Controlled: value + onValueChange; uncontrolled: defaultValue.
 * Native <input type="radio"> handles roving focus and arrow keys.
 */
const Ctx = React.createContext(null);
const DIM = { sm: 16, md: 20, lg: 24 };
const FS = { sm: "var(--text-sm)", md: "var(--text-base)", lg: "var(--text-md)" };

export function RadioGroup({
  label, description, errorMessage, value, defaultValue, onValueChange, name,
  orientation = "vertical", size = "md", color = "primary", isDisabled = false, isInvalid = false, isRequired = false, isReadOnly = false,
  children, style = {}, ...rest
}) {
  const [inner, setInner] = React.useState(defaultValue ?? null);
  const val = value !== undefined ? value : inner;
  const uid = React.useId();
  const select = (v) => { if (isReadOnly) return; if (value === undefined) setInner(v); onValueChange && onValueChange(v); };
  return (
    <div role="radiogroup" aria-labelledby={label ? `rg-${uid}` : undefined} aria-describedby={description ? `rg-${uid}-d` : undefined}
      aria-invalid={isInvalid || undefined} aria-required={isRequired || undefined} aria-orientation={orientation}
      data-orientation={orientation} data-invalid={dataAttr(isInvalid)} data-disabled={dataAttr(isDisabled)}
      style={{ display: "flex", flexDirection: "column", gap: 6, fontFamily: "var(--font-body)", ...style }} {...rest}>
      {label && <span id={`rg-${uid}`} style={{ fontSize: "var(--text-sm)", fontWeight: 500, color: isInvalid ? "var(--danger)" : "var(--fg-2)" }}>{label}{isRequired && <span aria-hidden="true" style={{ color: "var(--danger)", marginLeft: 3 }}>*</span>}</span>}
      <Ctx.Provider value={{ val, select, name: name || `rg-${uid}`, size, color, isDisabled, isInvalid, isReadOnly }}>
        <div style={{ display: "flex", flexDirection: orientation === "horizontal" ? "row" : "column", flexWrap: "wrap", gap: orientation === "horizontal" ? "4px 20px" : 0 }}>{children}</div>
      </Ctx.Provider>
      {description && !isInvalid && <span id={`rg-${uid}-d`} style={{ fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{description}</span>}
      {isInvalid && errorMessage && <span role="alert" style={{ fontSize: "var(--text-xs)", color: "var(--danger)" }}>{errorMessage}</span>}
    </div>
  );
}

export function Radio({ value, description, isDisabled, size, color, children, style = {}, ...rest }) {
  const g = React.useContext(Ctx) || { val: null, select: () => {}, name: undefined };
  size = size || g.size || "md"; color = color || g.color || "primary";
  const off = isDisabled ?? g.isDisabled ?? false;
  const invalid = g.isInvalid;
  const on = g.val === value;
  const [hover, setHover] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const uid = React.useId();
  const k = pal(invalid ? "danger" : color);
  const d = DIM[size] || DIM.md;
  const ring = on ? (invalid ? "var(--danger)" : k.dot) : invalid ? "var(--danger)" : hover ? "var(--border-strong)" : "var(--border-default)";

  return (
    <label
      data-selected={dataAttr(on)} data-disabled={dataAttr(off)} data-invalid={dataAttr(invalid)} data-hover={dataAttr(hover)} data-focus-visible={dataAttr(focusVisible)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ position: "relative", display: "inline-flex", alignItems: description ? "flex-start" : "center", gap: "10px", minHeight: 44, padding: description ? "8px 0" : 0, cursor: off ? "not-allowed" : "pointer", opacity: off ? 0.5 : 1, fontFamily: "var(--font-body)", WebkitTapHighlightColor: "transparent", ...style }}
      {...rest}
    >
      <input type="radio" name={g.name} value={value} checked={on} disabled={off} aria-invalid={invalid || undefined}
        aria-labelledby={children ? `r-${uid}` : undefined} aria-describedby={description ? `r-${uid}-d` : undefined}
        onChange={() => !off && g.select(value)}
        onFocus={(e) => { try { setFocusVisible(e.target.matches(":focus-visible")); } catch (_) { setFocusVisible(true); } }}
        onBlur={() => setFocusVisible(false)}
        style={{ position: "absolute", width: 44, height: 44, opacity: 0, margin: 0, cursor: "inherit", left: d / 2 - 22, top: description ? 0 : "50%", transform: description ? "none" : "translateY(-50%)" }} />
      <span aria-hidden="true" style={{
        width: d, height: d, flex: "none", boxSizing: "border-box", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
        marginTop: description ? 2 : 0, border: `1.5px solid ${ring}`, background: hover && !on && !off ? "var(--ink-500)" : "transparent",
        boxShadow: on && color === "primary" && !invalid ? k.glow : "none",
        outline: focusVisible ? "2px solid var(--focus-ring)" : "none", outlineOffset: 2,
        transition: "border-color var(--dur-fast) var(--ease-out), background var(--dur-fast)",
      }}>
        <span style={{ width: d * 0.45, height: d * 0.45, borderRadius: "50%", background: invalid ? "var(--danger)" : color === "primary" ? "var(--grad-cta)" : k.dot, transform: on ? "scale(1)" : "scale(0)", transition: "transform var(--dur-fast) var(--ease-spark)" }} />
      </span>
      {(children || description) && (
        <span style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {children && <span id={`r-${uid}`} style={{ fontSize: FS[size] || FS.md, color: invalid ? "var(--danger)" : "var(--fg-2)" }}>{children}</span>}
          {description && <span id={`r-${uid}-d`} style={{ fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{description}</span>}
        </span>
      )}
    </label>
  );
}
