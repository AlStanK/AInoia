Dialog over the page.

```jsx
<Modal isOpen={open} onOpenChange={setOpen} size="md" backdrop="blur">
  <ModalContent>{(onClose) => (<>
    <ModalHeader>Stop agent?</ModalHeader>
    <ModalBody>Running executions will finish; new ones are refused.</ModalBody>
    <ModalFooter><Button variant="light" color="default" onPress={onClose}>Cancel</Button><Button color="danger" onPress={stop}>Stop</Button></ModalFooter>
  </>)}</ModalContent>
</Modal>
```

Props: `isOpen/defaultOpen/onOpenChange`, `size xs…3xl|full`, `placement`, `backdrop opaque|blur|transparent`, `isDismissable`, `hideCloseButton`, `scrollBehavior`.