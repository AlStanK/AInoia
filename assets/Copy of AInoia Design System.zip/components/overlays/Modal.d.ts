import * as React from "react";
import type { Radius } from "../core/Button";
export interface ModalProps extends Omit<React.HTMLAttributes<HTMLElement>, "title"> {
  isOpen?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (isOpen: boolean) => void;
  onClose?: () => void;
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "full";
  placement?: "auto" | "center" | "top" | "bottom";
  radius?: Radius;
  backdrop?: "opaque" | "blur" | "transparent";
  isDismissable?: boolean;
  isKeyboardDismissDisabled?: boolean;
  hideCloseButton?: boolean;
  closeButton?: React.ReactNode;
  scrollBehavior?: "inside" | "outside";
  shouldBlockScroll?: boolean;
  portalContainer?: Element;
  disableAnimation?: boolean;
  children?: React.ReactNode;
}
export interface ModalContentProps { children?: React.ReactNode | ((onClose: () => void) => React.ReactNode); }
export interface ModalPartProps extends React.HTMLAttributes<HTMLElement> { children?: React.ReactNode; }
/** role="dialog" aria-modal; traps + restores focus, blocks body scroll, Esc/backdrop dismiss. */
export function Modal(props: ModalProps): JSX.Element;
export function ModalContent(props: ModalContentProps): JSX.Element;
export function ModalHeader(props: ModalPartProps): JSX.Element;
export function ModalBody(props: ModalPartProps): JSX.Element;
export function ModalFooter(props: ModalPartProps): JSX.Element;
