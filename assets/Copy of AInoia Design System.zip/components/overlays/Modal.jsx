import React from "react";
import { radius as rad } from "../core/theme.jsx";

/**
 * AInoia — Modal (HeroUI-aligned)
 * <Modal isOpen onOpenChange><ModalContent>{(onClose) => <>…</>}</ModalContent></Modal>
 * size: xs | sm | md | lg | xl | 2xl | full   placement: auto | center | top | bottom
 * backdrop: opaque | blur | transparent   isDismissable, isKeyboardDismissDisabled, hideCloseButton, scrollBehavior: inside | outside
 * Focus is trapped and restored; body scroll is blocked while open. Portal to document.body.
 */
const Ctx = React.createContext({ onClose: () => {}, ids: {} });
const W = { xs: 320, sm: 400, md: 480, lg: 560, xl: 640, "2xl": 720, "3xl": 800, full: "100%" };

export function Modal({ isOpen: isOpenProp, defaultOpen = false, onOpenChange, onClose, size = "md", placement = "auto", radius = "lg", backdrop = "opaque", isDismissable = true, isKeyboardDismissDisabled = false, hideCloseButton = false, closeButton, scrollBehavior = "inside", shouldBlockScroll = true, portalContainer, disableAnimation = false, children, style = {}, ...rest }) {
  const [inner, setInner] = React.useState(defaultOpen);
  const open = isOpenProp ?? inner;
  const [shown, setShown] = React.useState(open);
  const close = React.useCallback(() => { if (isOpenProp === undefined) setInner(false); onOpenChange && onOpenChange(false); onClose && onClose(); }, [isOpenProp, onOpenChange, onClose]);
  const ref = React.useRef(null), prev = React.useRef(null);
  const uid = React.useId();
  const ids = { header: `md-${uid}-h`, body: `md-${uid}-b` };

  React.useEffect(() => {
    if (open) { setShown(true); return; }
    if (disableAnimation) { setShown(false); return; }
    const t = setTimeout(() => setShown(false), 200); return () => clearTimeout(t);
  }, [open, disableAnimation]);

  React.useEffect(() => {
    if (!open) return;
    prev.current = document.activeElement;
    const el = ref.current;
    const focusables = () => el ? [...el.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter((n) => !n.disabled) : [];
    requestAnimationFrame(() => { const f = focusables(); (f[0] || el) && (f[0] || el).focus(); });
    const onKey = (e) => {
      if (e.key === "Escape" && !isKeyboardDismissDisabled) { e.stopPropagation(); close(); }
      if (e.key === "Tab") { const f = focusables(); if (!f.length) { e.preventDefault(); return; } const i = f.indexOf(document.activeElement); if (e.shiftKey && (i <= 0)) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); } }
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    if (shouldBlockScroll) document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = prevOverflow; prev.current && prev.current.focus && prev.current.focus(); };
  }, [open]);

  if (!shown) return null;
  const isFull = size === "full";
  const place = placement === "auto" ? "center" : placement;
  const anim = !disableAnimation;
  const node = (
    <div data-slot="wrapper" data-placement={place} style={{ position: "fixed", inset: 0, zIndex: 100, display: "flex", alignItems: isFull ? "stretch" : place === "top" ? "flex-start" : place === "bottom" ? "flex-end" : "center", justifyContent: "center", padding: isFull ? 0 : 16, boxSizing: "border-box", overflowY: scrollBehavior === "outside" ? "auto" : "hidden" }}>
      <div data-slot="backdrop" onClick={isDismissable ? close : undefined} aria-hidden="true"
        style={{ position: "fixed", inset: 0, background: backdrop === "transparent" ? "transparent" : "var(--surface-overlay)", backdropFilter: backdrop === "blur" ? "var(--blur-overlay)" : undefined,
          opacity: open ? 1 : 0, transition: anim ? "opacity var(--dur-base) var(--ease-out)" : "none" }} />
      <section ref={ref} role="dialog" aria-modal="true" aria-labelledby={ids.header} aria-describedby={ids.body} tabIndex={-1} data-open={open ? "true" : undefined}
        style={{ position: "relative", display: "flex", flexDirection: "column", width: isFull ? "100%" : "100%", maxWidth: isFull ? "none" : W[size] || W.md, maxHeight: isFull ? "none" : scrollBehavior === "inside" ? "calc(100vh - 32px)" : undefined, height: isFull ? "100%" : undefined, boxSizing: "border-box", outline: "none",
          background: "var(--ink-700)", border: isFull ? "none" : "1px solid var(--border-strong)", borderRadius: isFull ? 0 : rad(radius, "lg"), boxShadow: "var(--shadow-xl)", color: "var(--fg-1)", fontFamily: "var(--font-body)",
          opacity: open ? 1 : 0, transform: open ? "none" : place === "bottom" ? "translateY(16px)" : "translateY(-8px) scale(0.98)",
          transition: anim ? "opacity var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out)" : "none", ...style }} {...rest}>
        <Ctx.Provider value={{ onClose: close, ids, scrollBehavior }}>
          {children}
          {!hideCloseButton && (closeButton || (
            <button type="button" aria-label="Close" onClick={close}
              style={{ position: "absolute", top: 10, right: 10, display: "inline-flex", alignItems: "center", justifyContent: "center", width: 32, height: 32, padding: 0, border: "none", borderRadius: "var(--radius-sm)", background: "transparent", color: "var(--fg-3)", cursor: "pointer" }}>
              <svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M4 4l8 8M12 4l-8 8" /></svg>
            </button>
          ))}
        </Ctx.Provider>
      </section>
    </div>
  );
  const ReactDOM = window.ReactDOM;
  const target = portalContainer || (typeof document !== "undefined" ? document.body : null);
  return ReactDOM && ReactDOM.createPortal && target ? ReactDOM.createPortal(node, target) : node;
}

export function ModalContent({ children }) {
  const { onClose } = React.useContext(Ctx);
  return <>{typeof children === "function" ? children(onClose) : children}</>;
}
export function ModalHeader({ children, style = {}, ...rest }) {
  const { ids } = React.useContext(Ctx);
  return <header id={ids.header} data-slot="header" style={{ display: "flex", flexDirection: "column", gap: 2, padding: "18px 52px 12px 22px", fontSize: "var(--text-md)", fontWeight: 600, color: "var(--fg-1)", flex: "none", ...style }} {...rest}>{children}</header>;
}
export function ModalBody({ children, style = {}, ...rest }) {
  const { ids, scrollBehavior } = React.useContext(Ctx);
  return <div id={ids.body} data-slot="body" style={{ display: "flex", flexDirection: "column", gap: 12, padding: "4px 22px 16px", fontSize: "var(--text-base)", color: "var(--fg-2)", lineHeight: 1.55, flex: 1, minHeight: 0, overflowY: scrollBehavior === "inside" ? "auto" : "visible", ...style }} {...rest}>{children}</div>;
}
export function ModalFooter({ children, style = {}, ...rest }) {
  return <footer data-slot="footer" style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 8, padding: "12px 22px 18px", flex: "none", ...style }} {...rest}>{children}</footer>;
}
