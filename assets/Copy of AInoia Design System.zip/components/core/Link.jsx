import React from "react";
import { color as pal, dataAttr } from "./theme.jsx";

/**
 * AInoia — Link (HeroUI-aligned)
 * Inline anchor. color: primary (default) | foreground | secondary | success | warning | danger
 * underline: none | hover (default) | always | active   size: sm | md | lg   isExternal adds target=_blank + rel + icon (showAnchorIcon).
 */
export function Link({ color = "primary", underline = "hover", size = "md", isExternal = false, showAnchorIcon = false, anchorIcon, isBlock = false, isDisabled = false, href, children, style = {}, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const fg = color === "foreground" ? "var(--fg-1)" : pal(color).fg;
  const fs = { sm: "var(--text-sm)", md: "var(--text-base)", lg: "var(--text-md)" }[size] || "var(--text-base)";
  const deco = underline === "always" || (underline === "hover" && hover) || (underline === "active" && hover);
  const icon = anchorIcon || <svg viewBox="0 0 16 16" width="0.9em" height="0.9em" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h7v7M13 3L4 12" /></svg>;
  return (
    <a href={isDisabled ? undefined : href} aria-disabled={isDisabled || undefined} tabIndex={isDisabled ? -1 : undefined}
      target={isExternal ? "_blank" : undefined} rel={isExternal ? "noopener noreferrer" : undefined}
      data-hover={dataAttr(hover)} data-disabled={dataAttr(isDisabled)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ display: "inline-flex", alignItems: "center", gap: 4, color: fg, fontFamily: "var(--font-body)", fontSize: fs, fontWeight: 500, lineHeight: 1.4,
        textDecoration: deco ? "underline" : "none", textUnderlineOffset: 3, textDecorationThickness: 1,
        padding: isBlock ? "4px 8px" : 0, borderRadius: isBlock ? "var(--radius-sm)" : 0, background: isBlock && hover ? pal(color === "foreground" ? "default" : color).tint : "transparent",
        opacity: isDisabled ? 0.5 : hover && !isBlock ? 0.85 : 1, pointerEvents: isDisabled ? "none" : "auto", cursor: isDisabled ? "default" : "pointer",
        transition: "opacity var(--dur-fast), background var(--dur-fast)", ...style }} {...rest}>
      {children}{(showAnchorIcon || (isExternal && showAnchorIcon !== false && anchorIcon)) && <span aria-hidden="true" style={{ display: "inline-flex" }}>{icon}</span>}
    </a>
  );
}
