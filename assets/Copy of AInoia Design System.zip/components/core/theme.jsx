import React from "react";

/**
 * AInoia — shared variant vocabulary (HeroUI-aligned).
 * color: default | primary | secondary | success | warning | danger
 * radius: none | sm | md | lg | full
 * size: sm | md | lg
 */
export const palette = {
  default:   { fg: "var(--fg-1)",            solidBg: "var(--ink-500)",  solidFg: "var(--fg-1)",          tint: "var(--ink-600)",        tintStrong: "var(--ink-500)",           border: "var(--border-strong)",  glow: "none",                 glowHover: "none",             dot: "var(--fg-3)" },
  primary:   { fg: "var(--cyan)",            solidBg: "var(--grad-cta)", solidFg: "var(--fg-on-accent)",  tint: "var(--accent-tint)",    tintStrong: "var(--accent-tint-strong)", border: "var(--border-glow)",    glow: "var(--glow-cyan-sm)",  glowHover: "var(--glow-cyan)", dot: "var(--cyan)" },
  secondary: { fg: "var(--violet-bright)",   solidBg: "var(--violet)",   solidFg: "var(--fg-on-accent)",  tint: "var(--clay-tint)",      tintStrong: "var(--clay-tint)",          border: "var(--clay-border)",    glow: "none",                 glowHover: "none",             dot: "var(--violet)" },
  success:   { fg: "var(--success)",         solidBg: "var(--success)",  solidFg: "var(--fg-on-accent)",  tint: "var(--success-tint)",   tintStrong: "var(--success-tint)",       border: "var(--success-border)", glow: "none",                 glowHover: "none",             dot: "var(--success)" },
  warning:   { fg: "var(--warning)",         solidBg: "var(--warning)",  solidFg: "var(--fg-on-accent)",  tint: "var(--warning-tint)",   tintStrong: "var(--warning-tint)",       border: "var(--warning-border)", glow: "none",                 glowHover: "none",             dot: "var(--warning)" },
  danger:    { fg: "var(--danger)",          solidBg: "var(--danger)",   solidFg: "var(--fg-on-accent)",  tint: "var(--danger-tint)",    tintStrong: "var(--danger-tint)",        border: "var(--danger-border)",  glow: "none",                 glowHover: "none",             dot: "var(--danger)" },
};
export const color = (c) => palette[c] || palette.default;

export const radii = { none: "0", sm: "var(--radius-sm)", md: "var(--radius-md)", lg: "var(--radius-lg)", full: "var(--radius-pill)" };
export const radius = (r, fallback = "md") => radii[r] || radii[fallback];

export const controlH = { sm: "var(--control-h-sm)", md: "var(--control-h-md)", lg: "var(--control-h-lg)" };
export const controlFont = { sm: "var(--text-sm)", md: "var(--text-base)", lg: "var(--text-md)" };

/** true → "true", false → undefined (HeroUI data-attr convention). */
export const dataAttr = (v) => (v ? "true" : undefined);

/** Fill-style for a (variant, color) pair. Shared by Button, Chip, Badge, Tabs. */
export function fill(variant, c, { hover = false } = {}) {
  const k = color(c);
  const isDefault = !c || c === "default";
  switch (variant) {
    case "solid":  return { background: k.solidBg, color: k.solidFg, borderColor: "transparent", boxShadow: k.glow, opacity: hover ? 0.92 : 1 };
    case "shadow": return { background: k.solidBg, color: k.solidFg, borderColor: "transparent", boxShadow: c === "primary" ? (hover ? k.glowHover : k.glow) : "var(--shadow-md)", opacity: hover ? 0.92 : 1 };
    case "bordered": return { background: hover ? k.tint : "transparent", color: k.fg, borderColor: k.border, boxShadow: "none" };
    case "ghost":  return hover ? { background: k.solidBg, color: k.solidFg, borderColor: "transparent", boxShadow: "none" } : { background: "transparent", color: k.fg, borderColor: k.border, boxShadow: "none" };
    case "flat":   return { background: hover ? k.tintStrong : k.tint, color: k.fg, borderColor: "transparent", boxShadow: "none" };
    case "faded":  return { background: hover ? "var(--ink-500)" : "var(--ink-600)", color: k.fg, borderColor: "var(--border-default)", boxShadow: "none" };
    case "light":  return { background: hover ? (isDefault ? "var(--ink-600)" : k.tint) : "transparent", color: isDefault ? (hover ? "var(--fg-1)" : "var(--fg-2)") : k.fg, borderColor: "transparent", boxShadow: "none" };
    default:       return fill("solid", c, { hover });
  }
}

/** Hover / press / focus-visible tracking with HeroUI-style data attributes. */
export function useInteraction({ isDisabled = false, onPress, onClick } = {}) {
  const [hover, setHover] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const props = {
    onMouseEnter: () => !isDisabled && setHover(true),
    onMouseLeave: () => { setHover(false); setPressed(false); },
    onMouseDown: () => !isDisabled && setPressed(true),
    onMouseUp: () => setPressed(false),
    onFocus: (e) => { try { setFocusVisible(e.target.matches(":focus-visible")); } catch (_) { setFocusVisible(true); } },
    onBlur: () => setFocusVisible(false),
    onClick: (e) => { if (isDisabled) { e.preventDefault(); return; } onClick && onClick(e); onPress && onPress(e); },
    "data-hover": dataAttr(hover),
    "data-pressed": dataAttr(pressed),
    "data-focus-visible": dataAttr(focusVisible),
    "data-disabled": dataAttr(isDisabled),
  };
  return { hover, pressed, focusVisible, props };
}
