import React from "react";
import { color } from "./theme.jsx";

/**
 * AInoia — Spinner
 * Circular loading indicator. Sizes sm | md | lg; colors follow the shared palette.
 */
export function Spinner({ size = "md", color: c = "current", label, style = {}, ...rest }) {
  const d = { sm: 16, md: 24, lg: 32 }[size] || 24;
  const stroke = size === "sm" ? 2 : 3;
  const col = c === "current" ? "currentColor" : color(c).fg;
  return (
    <span role="status" aria-label={label || "Loading"} style={{ display: "inline-flex", alignItems: "center", gap: "8px", ...style }} {...rest}>
      <span aria-hidden="true" style={{
        width: d, height: d, flex: "none", borderRadius: "50%", boxSizing: "border-box",
        border: `${stroke}px solid`, borderColor: `${col} transparent ${col} transparent`, opacity: 0.9,
        animation: "ainoia-spin 0.8s linear infinite",
      }} />
      {label && <span style={{ fontSize: "var(--text-sm)", color: "var(--fg-2)" }}>{label}</span>}
    </span>
  );
}
