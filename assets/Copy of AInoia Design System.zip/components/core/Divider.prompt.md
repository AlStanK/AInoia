Hairline separator.

```jsx
<Divider />
<Divider orientation="vertical" />  // inside a flex row
```