import * as React from "react";
import type { ChipProps } from "./Chip";

export interface TagProps extends ChipProps {
  /** @deprecated use isSelected */
  selected?: boolean;
  /** @deprecated use onClose */
  onRemove?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}

/** Legacy alias of Chip (faded variant). */
export function Tag(props: TagProps): JSX.Element;
