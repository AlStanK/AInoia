Filter or metadata chip — squarer than Badge, supports selection and removal.

```jsx
<Tag selected>Incident</Tag>
<Tag onRemove={() => {}}>finance</Tag>
```

`selected` gives the cyan active look; pass `onRemove` to show a × button. Use Tag for user-controlled filters; use Badge for read-only status.
