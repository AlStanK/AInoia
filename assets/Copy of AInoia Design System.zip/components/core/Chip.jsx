import React from "react";
import { fill, color as pal, radius, dataAttr } from "./theme.jsx";

/**
 * AInoia — Chip
 * Compact label for filters, metadata and status.
 * variant: solid | bordered | light | flat | faded | shadow | dot
 * color:   default | primary | secondary | success | warning | danger
 */
export function Chip({
  variant = "flat", color = "default", size = "md", radius: r = "sm",
  isSelected = false, isDisabled = false,
  startContent = null, endContent = null, avatar = null,
  onClose, children, style = {}, ...rest
}) {
  const sel = isSelected ? { variant: "flat", color: color === "default" ? "primary" : color } : { variant, color };
  const k = pal(sel.color);
  const dims = { sm: { h: 22, px: 8, fs: "var(--text-xs)" }, md: { h: 26, px: 12, fs: "var(--text-sm)" }, lg: { h: 32, px: 14, fs: "var(--text-base)" } }[size] || { h: 26, px: 12, fs: "var(--text-sm)" };
  const isDot = variant === "dot";
  const look = isDot
    ? { background: "transparent", color: "var(--fg-2)", borderColor: "var(--border-default)", boxShadow: "none" }
    : fill(sel.variant, sel.color);
  const lead = avatar || startContent;

  return (
    <span
      data-selected={dataAttr(isSelected)}
      data-disabled={dataAttr(isDisabled)}
      aria-disabled={isDisabled || undefined}
      style={{
        display: "inline-flex", alignItems: "center", gap: "7px", boxSizing: "border-box",
        height: dims.h, padding: `0 ${onClose ? dims.px - 3 : dims.px}px 0 ${lead ? dims.px - 4 : dims.px}px`,
        fontFamily: "var(--font-body)", fontSize: dims.fs, fontWeight: "var(--weight-medium)", whiteSpace: "nowrap",
        border: "1px solid transparent", borderRadius: radius(r, "sm"),
        opacity: isDisabled ? 0.5 : 1, cursor: "default",
        transition: "all var(--dur-base) var(--ease-out)",
        ...look, ...style,
      }}
      {...rest}
    >
      {isDot && <span aria-hidden="true" style={{ width: 6, height: 6, borderRadius: "50%", background: k.dot, flex: "none" }} />}
      {lead}
      {children}
      {endContent}
      {onClose && (
        <button
          type="button"
          aria-label="close chip"
          disabled={isDisabled}
          onClick={onClose}
          style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 16, height: 16, padding: 0, border: "none", cursor: isDisabled ? "not-allowed" : "pointer",
            borderRadius: "50%", background: "transparent", color: "inherit", opacity: 0.7,
            fontFamily: "var(--font-body)", fontSize: 14, lineHeight: 1,
          }}
        >×</button>
      )}
    </span>
  );
}
