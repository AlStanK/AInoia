import * as React from "react";
export type KbdKey = "command" | "shift" | "ctrl" | "option" | "enter" | "delete" | "escape" | "tab" | "capslock" | "up" | "right" | "down" | "left" | "pageup" | "pagedown" | "home" | "end" | "help" | "space";
export interface KbdProps extends React.HTMLAttributes<HTMLElement> { keys?: KbdKey | KbdKey[]; children?: React.ReactNode; }
/** Keyboard shortcut chip. */
export function Kbd(props: KbdProps): JSX.Element;
