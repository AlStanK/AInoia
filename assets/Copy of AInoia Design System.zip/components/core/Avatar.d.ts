import * as React from "react";
import type { Color, Radius } from "./Button";

export interface AvatarProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "color"> {
  /** Used for initials and as img alt. */
  name?: string;
  src?: string;
  alt?: string;
  /** Fallback icon when no image / initials. */
  icon?: React.ReactNode;
  /** Custom fallback node. */
  fallback?: React.ReactNode;
  size?: "xs" | "sm" | "md" | "lg";
  radius?: Radius;
  color?: Color;
  /** Gradient ring (agents). */
  isBordered?: boolean;
  isDisabled?: boolean;
  isFocusable?: boolean;
  showFallback?: boolean;
  getInitials?: (name: string) => string;
  imgProps?: React.ImgHTMLAttributes<HTMLImageElement>;
  onError?: (e: React.SyntheticEvent<HTMLImageElement>) => void;
  /** Presence dot. */
  status?: "active" | "idle" | "offline";
  /** @deprecated use isBordered */
  agent?: boolean;
}

/** Identity token for users and agents. */
export function Avatar(props: AvatarProps): JSX.Element;
