import * as React from "react";
import type { ButtonProps } from "./Button";

export interface IconButtonProps extends Omit<ButtonProps, "variant" | "isIconOnly"> {
  /** Legacy `ghost|solid|glow` are mapped to light/faded/flat. */
  variant?: ButtonProps["variant"] | "glow";
  /** Accessible name (aria-label + title). */
  label?: string;
  /** @deprecated use radius="full" */
  round?: boolean;
}

/** Icon-only Button with a required accessible label. */
export function IconButton(props: IconButtonProps): JSX.Element;
