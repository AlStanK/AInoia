import React from "react";
import { color as pal, radius as rad, dataAttr } from "./theme.jsx";

/**
 * AInoia — Avatar
 * Identity token for users and agents. `isBordered` (legacy `agent`) adds the gradient ring.
 * size: xs | sm | md | lg   radius: none | sm | md | lg | full   color: default | primary | …
 */
const defaultInitials = (name = "") => name.split(" ").map((w) => w[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();

export function Avatar({
  name = "", src, alt, icon, fallback,
  size = "md", radius = "full", color = "default",
  isBordered = false, isDisabled = false, isFocusable = false, showFallback = true,
  getInitials = defaultInitials, imgProps = {}, onError,
  status, agent = false,
  style = {}, ...rest
}) {
  const [failed, setFailed] = React.useState(false);
  React.useEffect(() => setFailed(false), [src]);
  const d = { xs: 24, sm: 32, md: 40, lg: 56 }[size] || 40;
  const bordered = isBordered || agent;
  const k = pal(color);
  const r = rad(radius, "md");
  const statusColors = { active: "var(--success)", idle: "var(--warning)", offline: "var(--fg-4)" };
  const showImg = src && !failed;
  const inner = showImg
    ? <img src={src} alt={alt ?? (name || "avatar")} onError={(e) => { setFailed(true); onError && onError(e); }} {...imgProps} style={{ width: "100%", height: "100%", objectFit: "cover", ...(imgProps.style || {}) }} />
    : showFallback ? (fallback || icon || getInitials(name) || "·") : null;

  return (
    <span
      tabIndex={isFocusable ? 0 : undefined}
      data-disabled={dataAttr(isDisabled)}
      aria-label={!showImg && name ? name : undefined}
      role={!showImg && name ? "img" : undefined}
      style={{
        position: "relative", display: "inline-flex", flex: "none", borderRadius: r,
        padding: bordered ? 2 : 0,
        background: bordered ? (color === "default" || color === "primary" ? "var(--grad-cta)" : k.solidBg) : "transparent",
        opacity: isDisabled ? 0.5 : 1, filter: isDisabled ? "grayscale(1)" : "none",
        ...style,
      }}
      {...rest}
    >
      <span style={{
        display: "flex", alignItems: "center", justifyContent: "center",
        width: d, height: d, borderRadius: r, overflow: "hidden", boxSizing: "border-box",
        background: showImg ? "var(--ink-600)" : color === "default" ? "var(--ink-500)" : k.tint,
        border: bordered ? "2px solid var(--ink-800)" : `1px solid ${color === "default" ? "var(--border-default)" : k.border}`,
        color: color === "default" ? "var(--fg-1)" : k.fg, fontFamily: "var(--font-body)",
        fontSize: d * 0.36, fontWeight: "var(--weight-semibold)", letterSpacing: "0.02em",
      }}>
        {inner}
      </span>
      {status && (
        <span aria-hidden="true" style={{
          position: "absolute", right: -1, bottom: -1,
          width: Math.max(8, d * 0.26), height: Math.max(8, d * 0.26),
          borderRadius: "50%", background: statusColors[status] || "var(--fg-4)",
          border: "2px solid var(--ink-800)",
        }} />
      )}
    </span>
  );
}
