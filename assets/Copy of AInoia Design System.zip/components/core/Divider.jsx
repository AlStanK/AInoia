import React from "react";

/**
 * AInoia — Divider
 * Hairline separator. orientation: horizontal (default) | vertical. Renders role="separator".
 */
export function Divider({ orientation = "horizontal", style = {}, ...rest }) {
  const v = orientation === "vertical";
  return (
    <hr role="separator" aria-orientation={orientation} data-orientation={orientation}
      style={{ flex: "none", border: "none", margin: 0, background: "var(--border-default)", width: v ? 1 : "100%", height: v ? "auto" : 1, alignSelf: v ? "stretch" : undefined, ...style }} {...rest} />
  );
}
