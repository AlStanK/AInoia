import * as React from "react";

export interface SpinnerProps extends React.HTMLAttributes<HTMLSpanElement> {
  size?: "sm" | "md" | "lg";
  /** `current` inherits the parent text color. */
  color?: "current" | "default" | "primary" | "secondary" | "success" | "warning" | "danger";
  /** Visible label beside the ring; also used as the accessible name. */
  label?: string;
}

/** Circular loading indicator. */
export function Spinner(props: SpinnerProps): JSX.Element;
