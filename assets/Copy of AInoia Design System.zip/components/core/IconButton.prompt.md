Compact control holding one line icon — toolbars, panel headers, close/dismiss.

```jsx
<IconButton label="Close" variant="ghost"><Icon name="x" /></IconButton>
<IconButton label="Settings" variant="glow" round><Icon name="settings" /></IconButton>
```

Variants: `ghost` (default, fills on hover), `solid`, `glow` (cyan). `round` for circular. Sizes `sm|md|lg` map to 32/40/48px hit targets. Always pass `label` for accessibility.
