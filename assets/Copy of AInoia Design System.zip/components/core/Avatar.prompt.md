Identity token. Agents get the gradient ring (`isBordered`); people stay plain.

```jsx
<Avatar name="Maya Okonkwo" status="active" />
<Avatar name="Incident Resolver" isBordered status="idle" size="lg" />
<Avatar src="/me.jpg" name="Maya" radius="md" />
```

Sizes `xs | sm | md | lg`; radius `none | sm | md | lg | full`; color tints the fallback. Props: `isBordered`, `isDisabled`, `isFocusable`, `showFallback`, `fallback`, `icon`, `getInitials`, `status`. Legacy `agent` maps to `isBordered`.
