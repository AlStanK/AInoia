import React from "react";
import { fill, color as pal, dataAttr } from "./theme.jsx";

/**
 * AInoia — Badge
 * Standalone: small status pill (`<Badge color="success">98%</Badge>`).
 * Overlay (HeroUI): wrap children and pass `content` — the badge anchors to a corner.
 * variant: flat | solid | faded | shadow | dot   color: default | primary | secondary | success | warning | danger
 * Legacy: tone="neutral|active|violet|…" → color, `dot` → variant="dot".
 */
const TONE = { neutral: "default", active: "primary", violet: "secondary", success: "success", warning: "warning", danger: "danger" };

export function Badge({
  variant = "flat", color = "default", size = "md", shape = "rectangle",
  content, placement = "top-right", isInvisible = false, isOneChar, showOutline = true, disableOutline,
  tone, dot = false,
  children, style = {}, ...rest
}) {
  if (tone) color = TONE[tone] || "default";
  if (dot) variant = "dot";
  const k = pal(color);
  const isDot = variant === "dot";
  const look = isDot
    ? { background: k.tint, color: k.fg, borderColor: k.border, boxShadow: "none" }
    : fill(variant === "flat" ? "flat" : variant, color);
  if (variant === "flat" || isDot) look.borderColor = k.border;
  const overlay = content !== undefined;
  const oneChar = isOneChar ?? (overlay && String(content).length === 1);
  const empty = overlay && String(content).length === 0;

  const h = overlay ? { sm: 16, md: 20, lg: 24 }[size] : 22;
  const pill = (
    <span
      data-invisible={dataAttr(isInvisible)}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "6px", boxSizing: "border-box",
        height: empty ? h * 0.6 : h, minWidth: empty ? h * 0.6 : oneChar ? h : undefined,
        padding: empty || oneChar ? 0 : "0 10px",
        fontFamily: "var(--font-body)", fontSize: overlay && size === "sm" ? "10px" : "var(--text-xs)", fontWeight: "var(--weight-semibold)", letterSpacing: "0.02em",
        border: `1px solid ${overlay && showOutline && !disableOutline ? "var(--ink-800)" : "transparent"}`,
        borderRadius: "var(--radius-pill)", whiteSpace: "nowrap",
        ...look,
        ...(overlay ? {
          position: "absolute", zIndex: 1,
          top: placement.startsWith("top") ? 0 : "auto", bottom: placement.startsWith("bottom") ? 0 : "auto",
          right: placement.endsWith("right") ? 0 : "auto", left: placement.endsWith("left") ? 0 : "auto",
          transform: `translate(${placement.endsWith("right") ? "40%" : "-40%"}, ${placement.startsWith("top") ? "-40%" : "40%"})`,
          transition: "opacity var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out)",
          opacity: isInvisible ? 0 : 1, pointerEvents: isInvisible ? "none" : "auto",
          ...(shape === "circle" ? {} : {}),
        } : {}),
        ...style,
      }}
      {...(overlay ? {} : rest)}
    >
      {isDot && (
        <span aria-hidden="true" style={{
          width: 6, height: 6, borderRadius: "50%", background: k.dot, flex: "none",
          boxShadow: color === "primary" || color === "success" ? `0 0 6px ${k.dot}` : "none",
        }} />
      )}
      {overlay ? content : children}
    </span>
  );

  if (!overlay) return pill;
  return (
    <span style={{ position: "relative", display: "inline-flex", flex: "none" }} {...rest}>
      {children}
      {pill}
    </span>
  );
}
