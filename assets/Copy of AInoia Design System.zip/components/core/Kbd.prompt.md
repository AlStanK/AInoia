Keyboard shortcut chip.

```jsx
<Kbd keys={["command"]}>K</Kbd>
<Kbd keys={["shift", "enter"]} />
```