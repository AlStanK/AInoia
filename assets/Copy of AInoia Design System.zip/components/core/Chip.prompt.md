Compact label for filters, metadata and status.

```jsx
<Chip>finance</Chip>
<Chip isSelected>Incident</Chip>
<Chip color="success" variant="dot">Healthy</Chip>
<Chip onClose={() => remove(id)}>region:eu</Chip>
```

Variants `solid | bordered | light | flat | faded | shadow | dot`; colors `default | primary | secondary | success | warning | danger`; sizes `sm | md | lg`. Props: `isSelected`, `isDisabled`, `startContent`, `endContent`, `avatar`, `onClose`. `Tag` is a legacy alias (`selected`, `onRemove`).
