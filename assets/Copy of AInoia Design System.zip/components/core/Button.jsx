import React from "react";
import { fill, radius, dataAttr, useInteraction, controlH, controlFont } from "./theme.jsx";
import { Spinner } from "./Spinner.jsx";

/**
 * AInoia — Button (HeroUI-aligned API)
 * variant: solid | bordered | light | flat | faded | ghost | shadow
 * color:   default | primary | secondary | success | warning | danger
 * Legacy aliases still accepted: variant="primary|secondary|outline|ghost|danger",
 * disabled, iconLeft/iconRight, onClick.
 */
const LEGACY = {
  primary: ["solid", "primary"], secondary: ["solid", "default"], outline: ["bordered", "primary"],
  ghost: ["light", "default"], danger: ["solid", "danger"],
};

export function Button({
  variant = "solid",
  color = "primary",
  size = "md",
  radius: r = "md",
  fullWidth = false,
  isDisabled = false,
  isLoading = false,
  isIconOnly = false,
  disableAnimation = false,
  startContent = null,
  endContent = null,
  spinner,
  spinnerPlacement = "start",
  onPress,
  // legacy
  disabled = false, iconLeft = null, iconRight = null,
  children, style = {}, ...rest
}) {
  if (LEGACY[variant]) { const [v, c] = LEGACY[variant]; variant = v; if (color === "primary") color = c; }
  startContent = startContent || iconLeft;
  endContent = endContent || iconRight;
  const off = isDisabled || disabled || isLoading;
  const { hover, pressed, props } = useInteraction({ isDisabled: off, onPress, onClick: rest.onClick });
  const h = controlH[size] || controlH.md;
  const pads = isIconOnly ? "0" : { sm: "0 14px", md: "0 20px", lg: "0 28px" }[size];
  const spin = spinner || <Spinner size={size === "lg" ? "md" : "sm"} />;
  const iconClone = (n) => (React.isValidElement(n) ? React.cloneElement(n, { "aria-hidden": true, focusable: false }) : n);

  return (
    <button
      type="button"
      disabled={off}
      aria-busy={isLoading || undefined}
      data-loading={dataAttr(isLoading)}
      {...rest}
      {...props}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center", gap: size === "lg" ? "12px" : "8px",
        height: h, minWidth: isIconOnly ? h : undefined, width: fullWidth ? "100%" : isIconOnly ? h : "auto",
        padding: pads, boxSizing: "border-box",
        fontFamily: "var(--font-body)", fontSize: controlFont[size], fontWeight: "var(--weight-semibold)", letterSpacing: "0.01em",
        borderRadius: radius(r), border: "1px solid transparent",
        cursor: off ? "not-allowed" : "pointer", opacity: off ? 0.45 : 1,
        whiteSpace: "nowrap", userSelect: "none",
        transform: pressed && !disableAnimation ? "scale(0.97)" : "none",
        transition: disableAnimation ? "none" : "transform var(--dur-fast) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)",
        ...fill(variant, color, { hover }),
        ...style,
      }}
    >
      {isLoading && spinnerPlacement === "start" ? spin : iconClone(startContent)}
      {children}
      {isLoading && spinnerPlacement === "end" ? spin : iconClone(endContent)}
    </button>
  );
}
