Loading ring. Use inside `Button isLoading`, or standalone while a panel fetches.

```jsx
<Spinner size="sm" />
<Spinner color="primary" label="Syncing agents…" />
```

Props: `size sm|md|lg`, `color current|default|primary|…|danger`, `label`. Renders `role="status"`.
