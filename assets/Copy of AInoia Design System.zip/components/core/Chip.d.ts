import * as React from "react";
import type { Color, Radius, Size } from "./Button";

export interface ChipProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "color"> {
  /** `dot` renders a leading colored dot on a neutral outline. */
  variant?: "solid" | "bordered" | "light" | "flat" | "faded" | "shadow" | "dot";
  color?: Color;
  size?: Size;
  radius?: Radius;
  /** Selected filter state (flat primary tint). */
  isSelected?: boolean;
  isDisabled?: boolean;
  startContent?: React.ReactNode;
  endContent?: React.ReactNode;
  /** Leading avatar; overrides startContent. */
  avatar?: React.ReactNode;
  /** Shows a close button when provided. */
  onClose?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  children?: React.ReactNode;
}

/** Compact label for filters, metadata and status. */
export function Chip(props: ChipProps): JSX.Element;
