Status pill, or a count anchored to a corner of another element.

```jsx
<Badge color="primary" variant="dot">Active</Badge>
<Badge color="success">98.6% success</Badge>
<Badge content="5" color="danger"><IconButton label="Alerts"><Icon name="bell" /></IconButton></Badge>
<Badge content="" color="success" placement="bottom-right"><Avatar name="Maya" /></Badge>
```

Variants `flat | solid | faded | shadow | dot`; colors `default | primary | secondary | success | warning | danger`. Overlay props: `content`, `placement`, `size`, `isInvisible`, `showOutline`. Legacy `tone` + `dot` still map. Use `primary` only for the currently-running / live state.
