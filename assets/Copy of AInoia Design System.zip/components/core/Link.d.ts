import * as React from "react";
import type { Color, Size } from "./Button";
export interface LinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "color"> {
  color?: Color | "foreground";
  underline?: "none" | "hover" | "always" | "active";
  size?: Size;
  /** target=_blank + rel=noopener. */
  isExternal?: boolean;
  showAnchorIcon?: boolean;
  anchorIcon?: React.ReactNode;
  /** Padded, tinted hover block. */
  isBlock?: boolean;
  isDisabled?: boolean;
  children?: React.ReactNode;
}
export function Link(props: LinkProps): JSX.Element;
