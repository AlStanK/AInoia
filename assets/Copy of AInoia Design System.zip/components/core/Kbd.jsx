import React from "react";

/**
 * AInoia — Kbd
 * Keyboard shortcut chip. keys: array of modifier names (command|shift|ctrl|option|enter|delete|escape|tab|capslock|up|right|down|left|pageup|pagedown|home|end|help|space).
 */
const SYM = { command: "⌘", shift: "⇧", ctrl: "⌃", option: "⌥", enter: "↵", delete: "⌫", escape: "⎋", tab: "⇥", capslock: "⇪", up: "↑", right: "→", down: "↓", left: "←", pageup: "⇞", pagedown: "⇟", home: "↖", end: "↘", help: "?", space: "␣" };

export function Kbd({ keys = [], children, style = {}, ...rest }) {
  const list = Array.isArray(keys) ? keys : [keys];
  return (
    <kbd style={{ display: "inline-flex", alignItems: "center", gap: 4, height: 22, padding: "0 6px", boxSizing: "border-box",
      fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--fg-2)", background: "var(--ink-600)", border: "1px solid var(--border-default)", borderBottomWidth: 2,
      borderRadius: "var(--radius-xs)", lineHeight: 1, whiteSpace: "nowrap", ...style }} {...rest}>
      {list.map((k) => <abbr key={k} title={k} style={{ textDecoration: "none" }}>{SYM[k] || k}</abbr>)}
      {children && <span>{children}</span>}
    </kbd>
  );
}
