import React from "react";
import { Button } from "./Button.jsx";

/**
 * AInoia — IconButton
 * `Button isIconOnly` with a required accessible label. Quiet (`light`) by default.
 * Legacy variants: ghost → light/default, solid → faded/default, glow → flat/primary; `round` → radius="full".
 */
const LEGACY = { ghost: ["light", "default"], solid: ["faded", "default"], glow: ["flat", "primary"] };

export function IconButton({ variant = "light", color = "default", round = false, radius, label, children, ...rest }) {
  if (LEGACY[variant]) { const [v, c] = LEGACY[variant]; variant = v; if (color === "default") color = c; }
  return (
    <Button
      isIconOnly
      variant={variant}
      color={color}
      radius={radius || (round ? "full" : "md")}
      aria-label={rest["aria-label"] || label}
      title={rest.title || label}
      {...rest}
    >
      {children}
    </Button>
  );
}
