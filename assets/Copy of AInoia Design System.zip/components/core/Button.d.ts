import * as React from "react";

export type Color = "default" | "primary" | "secondary" | "success" | "warning" | "danger";
export type Radius = "none" | "sm" | "md" | "lg" | "full";
export type Size = "sm" | "md" | "lg";

export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "color"> {
  /** Fill style. Legacy `primary|secondary|outline|ghost|danger` are still mapped. */
  variant?: "solid" | "bordered" | "light" | "flat" | "faded" | "ghost" | "shadow" | "primary" | "secondary" | "outline" | "danger";
  /** Semantic color. `primary` carries the balance gradient when solid. */
  color?: Color;
  size?: Size;
  radius?: Radius;
  fullWidth?: boolean;
  isDisabled?: boolean;
  /** Shows a spinner and disables the button. */
  isLoading?: boolean;
  /** Square button holding a single icon; provide aria-label. */
  isIconOnly?: boolean;
  disableAnimation?: boolean;
  startContent?: React.ReactNode;
  endContent?: React.ReactNode;
  spinner?: React.ReactNode;
  spinnerPlacement?: "start" | "end";
  onPress?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  /** @deprecated use isDisabled */
  disabled?: boolean;
  /** @deprecated use startContent */
  iconLeft?: React.ReactNode;
  /** @deprecated use endContent */
  iconRight?: React.ReactNode;
  children?: React.ReactNode;
}

/** Action button. Emits data-hover / data-pressed / data-focus-visible / data-disabled / data-loading. */
export function Button(props: ButtonProps): JSX.Element;
