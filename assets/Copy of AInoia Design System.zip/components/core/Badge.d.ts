import * as React from "react";
import type { Color, Size } from "./Button";

export interface BadgeProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "color" | "content"> {
  /** `dot` adds a leading status dot. */
  variant?: "flat" | "solid" | "faded" | "shadow" | "dot";
  color?: Color;
  /** Overlay badge size (standalone pill is fixed at 22px). */
  size?: Size;
  shape?: "rectangle" | "circle";
  /** Overlay mode: badge content anchored to a corner of `children`. Empty string renders a dot. */
  content?: string | number | React.ReactNode;
  placement?: "top-right" | "top-left" | "bottom-right" | "bottom-left";
  isInvisible?: boolean;
  isOneChar?: boolean;
  /** Outline that separates the overlay badge from its anchor. */
  showOutline?: boolean;
  /** @deprecated use showOutline={false} */
  disableOutline?: boolean;
  /** @deprecated use color (neutral→default, active→primary, violet→secondary) */
  tone?: "neutral" | "active" | "success" | "warning" | "danger" | "violet";
  /** @deprecated use variant="dot" */
  dot?: boolean;
  children?: React.ReactNode;
}

/** Status pill, or corner-anchored overlay badge when `content` is given. */
export function Badge(props: BadgeProps): JSX.Element;
