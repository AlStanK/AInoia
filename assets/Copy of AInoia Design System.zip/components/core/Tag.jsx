import React from "react";
import { Chip } from "./Chip.jsx";

/**
 * AInoia — Tag (legacy alias of Chip)
 * `selected` → isSelected, `onRemove` → onClose. Prefer Chip in new code.
 */
export function Tag({ selected, onRemove, ...rest }) {
  return <Chip variant="faded" isSelected={!!selected} onClose={onRemove} {...rest} />;
}
