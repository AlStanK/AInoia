import * as React from "react";
export interface DividerProps extends React.HTMLAttributes<HTMLHRElement> { orientation?: "horizontal" | "vertical"; }
/** Hairline separator, role="separator". */
export function Divider(props: DividerProps): JSX.Element;
