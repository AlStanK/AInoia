Inline anchor.

```jsx
<Link href="/docs">Documentation</Link>
<Link href="https://ainoia.ai" isExternal showAnchorIcon color="foreground">ainoia.ai</Link>
```

Props: `color primary|foreground|…`, `underline none|hover|always`, `size`, `isExternal`, `showAnchorIcon`, `isBlock`, `isDisabled`.