Action button. The default `solid` + `primary` carries the tan→bronze balance gradient — reserve it for one action per view.

```jsx
<Button>Deploy agent</Button>
<Button variant="bordered" startContent={<Icon name="plus" />}>New workflow</Button>
<Button variant="light" color="default">Cancel</Button>
<Button color="danger" isLoading>Stopping…</Button>
<Button isIconOnly variant="light" aria-label="Settings"><Icon name="settings" /></Button>
```

Variants: `solid | bordered | light | flat | faded | ghost | shadow`. Colors: `default | primary | secondary | success | warning | danger`. Sizes `sm | md | lg`; radius `none | sm | md | lg | full`. Props: `isDisabled`, `isLoading` (spinner + disabled), `isIconOnly`, `fullWidth`, `startContent`, `endContent`, `onPress`. Legacy `variant="primary|secondary|outline|ghost|danger"`, `disabled`, `iconLeft/iconRight` still work.
