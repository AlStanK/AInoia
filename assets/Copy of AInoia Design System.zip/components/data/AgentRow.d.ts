import * as React from "react";

export interface AgentRowProps extends React.HTMLAttributes<HTMLDivElement> {
  name: string;
  role?: string;
  status?: "active" | "idle" | "error" | "paused";
  runs?: number;
  isSelected?: boolean;
  isDisabled?: boolean;
  /** Makes the row pressable (role="button", Enter/Space). */
  onPress?: (e: React.SyntheticEvent) => void;
  /** Trailing slot (actions, metrics). */
  endContent?: React.ReactNode;
  /** @deprecated use isSelected */
  selected?: boolean;
  /** @deprecated use endContent */
  trailing?: React.ReactNode;
}

/** One agent line: identity, role, status, runs. */
export function AgentRow(props: AgentRowProps): JSX.Element;
