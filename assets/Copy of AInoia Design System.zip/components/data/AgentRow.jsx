import React from "react";
import { Avatar } from "../core/Avatar.jsx";
import { Badge } from "../core/Badge.jsx";
import { dataAttr, useInteraction } from "../core/theme.jsx";

/**
 * AInoia — AgentRow
 * A single agent line: identity, role, status, runs and a trailing slot.
 * Pressable when onPress/onClick is given (role="button", Enter/Space). Legacy: selected → isSelected.
 */
export function AgentRow({ name, role, status = "active", runs, isSelected, isDisabled = false, onPress, onClick, trailing, endContent, selected = false, style = {}, ...rest }) {
  const sel = isSelected ?? selected;
  const pressable = !!(onPress || onClick);
  const { hover, props } = useInteraction({ isDisabled, onPress, onClick });
  const statusColor = { active: "primary", idle: "warning", error: "danger", paused: "default" }[status] || "default";
  const statusLabel = { active: "Active", idle: "Idle", error: "Error", paused: "Paused" }[status] || status;

  return (
    <div
      role={pressable ? "button" : undefined}
      tabIndex={pressable && !isDisabled ? 0 : undefined}
      aria-pressed={pressable ? sel : undefined}
      aria-disabled={isDisabled || undefined}
      data-selected={dataAttr(sel)}
      onKeyDown={pressable ? (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); props.onClick(e); } } : undefined}
      {...rest}
      {...(pressable ? props : { "data-disabled": dataAttr(isDisabled) })}
      style={{
        display: "flex", alignItems: "center", gap: "12px",
        padding: "12px 14px",
        borderRadius: "var(--radius-md)",
        background: sel ? "var(--accent-tint)" : hover && pressable ? "var(--ink-600)" : "transparent",
        border: `1px solid ${sel ? "var(--border-glow)" : "transparent"}`,
        cursor: isDisabled ? "not-allowed" : pressable ? "pointer" : "default",
        opacity: isDisabled ? 0.5 : 1,
        transition: "background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out)",
        ...style,
      }}
    >
      <Avatar name={name} isBordered status={status === "active" ? "active" : status === "idle" ? "idle" : "offline"} />
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ color: "var(--fg-1)", fontWeight: 600, fontSize: "var(--text-base)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</div>
        <div style={{ color: "var(--fg-3)", fontSize: "var(--text-sm)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {role}{runs != null && <span style={{ fontFamily: "var(--font-mono)", color: "var(--fg-4)" }}> · {runs} runs</span>}
        </div>
      </div>
      <Badge color={statusColor} variant="dot">{statusLabel}</Badge>
      {endContent || trailing}
    </div>
  );
}
