One agent per line inside an agents list.

```jsx
<AgentRow name="Incident Resolver" role="SRE · L2" status="active" runs={1284}
  isSelected={id === sel} onPress={() => setSel(id)} />
<AgentRow name="Request Handler" role="Support" status="idle" endContent={<IconButton label="More" size="sm"><Icon name="more-horizontal" /></IconButton>} />
```

Props: `status active|idle|error|paused`, `runs`, `isSelected`, `isDisabled`, `onPress`, `endContent`. Pressable rows get role="button" + keyboard support. Legacy `selected`, `onClick`, `trailing` still map.
