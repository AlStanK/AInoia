The base surface. Compose with `CardHeader` / `CardBody` / `CardFooter`, or pass `padding` for one padded area.

```jsx
<Card>
  <CardHeader><Icon name="bot" /> <strong>Agents</strong></CardHeader>
  <CardBody>…rows…</CardBody>
  <CardFooter><Switch>Autonomous mode</Switch></CardFooter>
</Card>
<Card isPressable onPress={open} padding="var(--space-5)">…</Card>
<Card isBlurred shadow="lg" glow>…</Card>
```

Props: `isPressable` (renders a button), `isHoverable`, `isDisabled`, `isBlurred`, `shadow none|sm|md|lg`, `radius`, `glow`, `fullWidth`, `onPress`. Legacy `interactive` = pressable + hoverable.
