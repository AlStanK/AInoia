import React from "react";
import { Card } from "./Card.jsx";

/**
 * AInoia — StatCard
 * Metric panel: label, big mono value, optional delta + sparkline area.
 */
export function StatCard({ label, value, unit, delta, deltaTone = "success", icon, children, style = {} }) {
  const deltaColors = { success: "var(--success)", danger: "var(--danger)", neutral: "var(--fg-3)" };
  return (
    <Card padding="var(--space-5)" style={{ minWidth: 0, ...style }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
        <span style={{ fontSize: "var(--text-xs)", letterSpacing: "0.04em", color: "var(--fg-3)", textTransform: "uppercase", fontFamily: "var(--font-display)", fontWeight: 500 }}>{label}</span>
        {icon && <span style={{ color: "var(--fg-3)", display: "inline-flex" }}>{icon}</span>}
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
        <span style={{ fontFamily: "var(--font-mono)", fontWeight: 500, fontSize: "var(--text-3xl)", color: "var(--fg-1)", lineHeight: 1 }}>{value}</span>
        {unit && <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-md)", color: "var(--cyan)" }}>{unit}</span>}
        {delta && (
          <span style={{ marginLeft: "auto", fontSize: "var(--text-sm)", fontWeight: 600, color: deltaColors[deltaTone], fontFamily: "var(--font-mono)" }}>{delta}</span>
        )}
      </div>
      {children && <div style={{ marginTop: "14px" }}>{children}</div>}
    </Card>
  );
}
