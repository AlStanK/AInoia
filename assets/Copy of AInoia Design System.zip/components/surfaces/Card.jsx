import React from "react";
import { radius as rad, dataAttr, useInteraction } from "../core/theme.jsx";

/**
 * AInoia — Card (HeroUI-aligned)
 * Matte dark panel with hairline border. Compose with CardHeader / CardBody / CardFooter,
 * or pass `padding` for a single padded area (legacy).
 * isPressable → renders <button role>, isHoverable → lift on hover. Legacy: interactive → isPressable + isHoverable.
 */
const SHADOWS = { none: "none", sm: "var(--shadow-sm)", md: "var(--shadow-md)", lg: "var(--shadow-lg)" };

export function Card({
  isPressable = false, isHoverable = false, isDisabled = false, isBlurred = false, fullWidth = false,
  shadow = "md", radius = "lg", glow = false, padding, onPress,
  interactive = false, disableAnimation = false,
  children, style = {}, ...rest
}) {
  const pressable = isPressable || interactive;
  const hoverable = isHoverable || interactive || pressable;
  const { hover, pressed, props } = useInteraction({ isDisabled, onPress, onClick: rest.onClick });
  const Comp = pressable ? "button" : "div";
  const lift = hoverable && hover && !isDisabled;
  const hasParts = React.Children.toArray(children).some((c) => c && c.type && c.type.__ainoiaCardPart);
  const pad = padding ?? (hasParts ? 0 : "var(--space-6)");

  return (
    <Comp
      type={pressable ? "button" : undefined}
      disabled={pressable && isDisabled ? true : undefined}
      aria-disabled={!pressable && isDisabled ? true : undefined}
      data-pressable={dataAttr(pressable)} data-hoverable={dataAttr(hoverable)}
      {...rest}
      {...(hoverable || pressable ? props : { "data-disabled": dataAttr(isDisabled) })}
      style={{
        display: "flex", flexDirection: "column", boxSizing: "border-box", textAlign: "left",
        width: fullWidth ? "100%" : undefined, position: "relative", overflow: "hidden",
        background: lift ? "var(--surface-card-hover)" : isBlurred ? "rgba(58, 50, 44, 0.72)" : "var(--surface-card)",
        backdropFilter: isBlurred ? "blur(14px) saturate(1.2)" : undefined,
        border: `1px solid ${glow ? "var(--border-glow)" : lift ? "var(--border-strong)" : "var(--border-default)"}`,
        borderRadius: rad(radius, "lg"), padding: pad, margin: 0,
        boxShadow: glow ? "var(--glow-cyan-sm)" : SHADOWS[shadow] || SHADOWS.md,
        color: "var(--fg-1)", fontFamily: "var(--font-body)", fontSize: "var(--text-base)",
        transform: pressed && pressable && !disableAnimation ? "scale(0.985)" : lift && !disableAnimation ? "translateY(-2px)" : "none",
        transition: disableAnimation ? "none" : "background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)",
        cursor: isDisabled ? "not-allowed" : pressable ? "pointer" : "default",
        opacity: isDisabled ? 0.5 : 1,
        ...style,
      }}
    >
      {children}
    </Comp>
  );
}

const part = (name, base) => {
  const P = ({ children, style = {}, ...rest }) => (
    <div data-slot={name} style={{ ...base, ...style }} {...rest}>{children}</div>
  );
  P.__ainoiaCardPart = true;
  P.displayName = "Card" + name[0].toUpperCase() + name.slice(1);
  return P;
};

export const CardHeader = part("header", { display: "flex", alignItems: "center", gap: "10px", padding: "16px 18px", borderBottom: "1px solid var(--border-subtle)", flex: "none" });
export const CardBody = part("body", { display: "flex", flexDirection: "column", gap: "10px", padding: "18px", flex: 1, minHeight: 0, overflow: "auto" });
export const CardFooter = part("footer", { display: "flex", alignItems: "center", gap: "10px", padding: "13px 18px", borderTop: "1px solid var(--border-subtle)", flex: "none" });
