import * as React from "react";

export interface StatCardProps {
  /** Uppercase metric label. */
  label: string;
  /** Primary value (mono). */
  value: React.ReactNode;
  /** Unit suffix, accented cyan (e.g. "%"). */
  unit?: string;
  /** Delta string e.g. "+4.2%". */
  delta?: string;
  deltaTone?: "success" | "danger" | "neutral";
  /** Leading line icon. */
  icon?: React.ReactNode;
  /** Optional content (sparkline, bars) rendered below. */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/** KPI / metric panel built on Card. */
export function StatCard(props: StatCardProps): JSX.Element;
