import * as React from "react";
import type { Radius } from "../core/Button";

export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  /** Renders as a <button role> with press feedback. */
  isPressable?: boolean;
  /** Surface lift + border strengthen on hover. */
  isHoverable?: boolean;
  isDisabled?: boolean;
  /** Translucent backdrop-blurred surface. */
  isBlurred?: boolean;
  fullWidth?: boolean;
  shadow?: "none" | "sm" | "md" | "lg";
  radius?: Radius;
  /** Accent hairline + glow. */
  glow?: boolean;
  /** Inner padding when not composed from CardHeader/Body/Footer. */
  padding?: string | number;
  disableAnimation?: boolean;
  onPress?: (e: React.MouseEvent<HTMLElement>) => void;
  /** @deprecated use isPressable / isHoverable */
  interactive?: boolean;
  children?: React.ReactNode;
}

/** Matte dark panel with hairline border. */
export function Card(props: CardProps): JSX.Element;
export function CardHeader(props: React.HTMLAttributes<HTMLDivElement>): JSX.Element;
export function CardBody(props: React.HTMLAttributes<HTMLDivElement>): JSX.Element;
export function CardFooter(props: React.HTMLAttributes<HTMLDivElement>): JSX.Element;
