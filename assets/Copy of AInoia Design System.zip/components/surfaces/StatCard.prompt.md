KPI / metric panel built on Card — used across the AInoia Board.

```jsx
<StatCard label="Success rate" value="98.6" unit="%" delta="+1.2%" />
<StatCard label="Executions" value="1,243" delta="+312" icon={<Icon name="activity" />}>
  {/* sparkline / bars */}
</StatCard>
```

Value renders in mono. `unit` is accented cyan. `delta` colors by `deltaTone` (success/danger/neutral). Drop a sparkline or bar row in as children.
