import React from "react";
import { color as pal, radius as rad, dataAttr } from "../core/theme.jsx";

/**
 * AInoia — Tabs (HeroUI-aligned)
 * items: [{ key, title, icon?, count?, content?, isDisabled? }]   (legacy: tabs=[{ id, label }])
 * selectedKey / defaultSelectedKey / onSelectionChange              (legacy: value / onChange)
 * variant: underlined (default) | solid | bordered | light    placement: top | bottom | start | end
 * WAI-ARIA Tabs: roving tabindex, Arrow/Home/End keys, aria-controls ↔ tabpanel.
 */
export function Tabs({
  items, selectedKey, defaultSelectedKey, onSelectionChange,
  variant = "underlined", color = "primary", size = "md", radius = "md",
  placement = "top", isVertical = false, isDisabled = false, disabledKeys = [], fullWidth = false,
  destroyInactiveTabPanel = true, disableAnimation = false,
  tabs, value, onChange, idBase, style = {}, ...rest
}) {
  const list = (items || tabs || []).map((t) => ({ key: t.key ?? t.id, title: t.title ?? t.label, ...t }));
  const keys = list.map((t) => t.key);
  const [inner, setInner] = React.useState(defaultSelectedKey ?? value ?? keys[0]);
  const ctrl = selectedKey ?? value;
  const active = ctrl !== undefined ? ctrl : inner;
  const uid = React.useId();
  const base = idBase || `tabs-${uid}`;
  const refs = React.useRef({});
  const k = pal(color);
  const vertical = isVertical || placement === "start" || placement === "end";
  const disabledSet = new Set(disabledKeys);
  const isOff = (t) => isDisabled || t.isDisabled || disabledSet.has(t.key);

  const select = (key) => { if (ctrl === undefined) setInner(key); onSelectionChange && onSelectionChange(key); onChange && onChange(key); };

  const onKeyDown = (e) => {
    const enabled = list.filter((t) => !isOff(t)).map((t) => t.key);
    const i = enabled.indexOf(active);
    if (i < 0) return;
    const fwd = vertical ? "ArrowDown" : "ArrowRight", back = vertical ? "ArrowUp" : "ArrowLeft";
    let next = null;
    if (e.key === fwd) next = enabled[(i + 1) % enabled.length];
    else if (e.key === back) next = enabled[(i - 1 + enabled.length) % enabled.length];
    else if (e.key === "Home") next = enabled[0];
    else if (e.key === "End") next = enabled[enabled.length - 1];
    if (next == null) return;
    e.preventDefault(); select(next);
    const el = refs.current[next]; el && el.focus && el.focus();
  };

  const fs = { sm: "var(--text-sm)", md: "var(--text-base)", lg: "var(--text-md)" }[size];
  const padY = { sm: "7px", md: "10px", lg: "12px" }[size];
  const boxed = variant === "solid" || variant === "bordered" || variant === "light";
  const listStyle = {
    underlined: { borderBottom: vertical ? "none" : "1px solid var(--border-default)", borderLeft: vertical ? "1px solid var(--border-default)" : "none", gap: "4px" },
    solid: { background: "var(--ink-600)", padding: 4, borderRadius: rad(radius), gap: 2 },
    bordered: { border: "1px solid var(--border-strong)", padding: 4, borderRadius: rad(radius), gap: 2 },
    light: { gap: 2 },
  }[variant] || {};

  const tabLook = (isActive, hover, off) => {
    if (variant === "underlined") return { background: "transparent", color: isActive ? "var(--fg-1)" : hover ? "var(--fg-2)" : "var(--fg-3)" };
    if (isActive) return { background: color === "default" ? "var(--ink-400)" : k.solidBg, color: color === "default" ? "var(--fg-1)" : k.solidFg, boxShadow: color === "primary" ? k.glow : "var(--shadow-sm)" };
    return { background: hover && !off ? "var(--ink-500)" : "transparent", color: hover ? "var(--fg-1)" : "var(--fg-2)" };
  };

  const hasPanels = list.some((t) => t.content !== undefined);
  const tablist = (
    <div
      role="tablist"
      aria-orientation={vertical ? "vertical" : "horizontal"}
      onKeyDown={onKeyDown}
      data-slot="tabList"
      style={{ display: vertical ? "inline-flex" : "flex", flexDirection: vertical ? "column" : "row", width: fullWidth ? "100%" : undefined, alignItems: "stretch", ...listStyle }}
    >
      {list.map((t) => <Tab key={t.key} t={t} ctx={{ active, isOff, select, refs, base, variant, color, k, size, radius, fullWidth, boxed, padY, fs, vertical, disableAnimation, tabLook }} />)}
    </div>
  );

  if (!hasPanels) return <div data-slot="base" style={style} {...rest}>{tablist}</div>;
  const before = placement === "top" || placement === "start";
  const panels = list.map((t) => {
    const isActive = t.key === active;
    if (!isActive && destroyInactiveTabPanel) return null;
    return (
      <div key={t.key} role="tabpanel" id={`${base}-panel-${t.key}`} aria-labelledby={`${base}-tab-${t.key}`} hidden={!isActive} tabIndex={0}
        data-slot="panel" style={{ padding: "16px 4px", color: "var(--fg-2)", fontFamily: "var(--font-body)", fontSize: "var(--text-base)", flex: 1, minWidth: 0 }}>
        {t.content}
      </div>
    );
  });
  return (
    <div data-slot="base" style={{ display: "flex", flexDirection: vertical ? "row" : "column", gap: vertical ? 16 : 0, ...style }} {...rest}>
      {before && tablist}{panels}{!before && tablist}
    </div>
  );
}

function Tab({ t, ctx }) {
const { active, isOff, select, refs, base, variant, color, k, size, radius, fullWidth, boxed, padY, fs, vertical, disableAnimation, tabLook } = ctx;
  const [hover, setHover] = React.useState(false);
  const isActive = t.key === active, off = isOff(t);
  return (
    <button
      ref={(el) => { refs.current[t.key] = el; }}
      type="button" role="tab"
      id={`${base}-tab-${t.key}`} aria-selected={isActive} aria-controls={`${base}-panel-${t.key}`}
      aria-disabled={off || undefined} tabIndex={isActive && !off ? 0 : -1} disabled={off}
      data-selected={dataAttr(isActive)} data-disabled={dataAttr(off)} data-hover={dataAttr(hover)}
      onClick={() => !off && select(t.key)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        position: "relative", flex: fullWidth ? 1 : "none",
        display: "inline-flex", alignItems: "center", justifyContent: boxed ? "center" : "flex-start", gap: "7px",
        minHeight: boxed ? undefined : "44px", height: boxed ? { sm: 28, md: 32, lg: 40 }[size] : undefined,
        padding: boxed ? `0 ${size === "sm" ? 10 : 14}px` : `${padY} 14px 13px`,
        border: "none", borderRadius: boxed ? rad(radius === "full" ? "full" : "sm") : 0, cursor: off ? "not-allowed" : "pointer",
        opacity: off ? 0.4 : 1,
        fontFamily: "var(--font-body)", fontSize: fs, fontWeight: isActive ? 600 : 500, whiteSpace: "nowrap",
        transition: disableAnimation ? "none" : "color var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)",
        ...tabLook(isActive, hover, off),
      }}
    >
      {t.icon}
      {t.title}
      {t.count != null && (
        <span style={{ fontFamily: "var(--font-mono)", fontSize: "11px", color: isActive ? (variant === "underlined" ? k.fg : "inherit") : "var(--fg-4)", opacity: isActive ? 0.9 : 1 }}>{t.count}</span>
      )}
      {isActive && variant === "underlined" && (
        <span aria-hidden="true" style={{
          position: "absolute",
          ...(vertical ? { top: 8, bottom: 8, left: -1, width: 2 } : { left: 8, right: 8, bottom: -1, height: 2 }),
          background: color === "default" ? "var(--fg-1)" : color === "primary" ? "var(--grad-cta)" : k.solidBg,
          borderRadius: 2, boxShadow: k.glow,
        }} />
      )}
    </button>
  );
}
