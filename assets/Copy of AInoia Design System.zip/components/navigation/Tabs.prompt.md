Section switcher. Underlined with a gradient indicator by default; `solid` gives a segmented pill.

```jsx
<Tabs
  selectedKey={tab}
  onSelectionChange={setTab}
  items={[
    { key: "agents", title: "Agents", count: 4, content: <AgentsPanel /> },
    { key: "workflows", title: "Workflows", count: 7, content: <Workflows /> },
    { key: "logs", title: "Logs", isDisabled: true },
  ]}
/>
<Tabs variant="solid" size="sm" items={[{ key: "12h", title: "12h" }, { key: "7d", title: "7d" }]} />
```

Variants `underlined | solid | bordered | light`; colors; sizes; `placement top|bottom|start|end`; `isVertical`, `fullWidth`, `disabledKeys`, `destroyInactiveTabPanel`. Keyboard: Arrow / Home / End. Legacy `tabs=[{id,label}]`, `value`, `onChange` still map.
