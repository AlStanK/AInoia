import * as React from "react";
import type { Color, Radius, Size } from "../core/Button";

export interface TabItem {
  key: string;
  title: React.ReactNode;
  icon?: React.ReactNode;
  /** Mono counter after the title. */
  count?: number | string;
  /** When given, Tabs renders the matching role="tabpanel". */
  content?: React.ReactNode;
  isDisabled?: boolean;
  /** @deprecated use key */ id?: string;
  /** @deprecated use title */ label?: React.ReactNode;
}

export interface TabsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange" | "color"> {
  items?: TabItem[];
  selectedKey?: string;
  defaultSelectedKey?: string;
  onSelectionChange?: (key: string) => void;
  /** `underlined` is the AInoia default (gradient indicator). */
  variant?: "underlined" | "solid" | "bordered" | "light";
  color?: Color;
  size?: Size;
  radius?: Radius;
  placement?: "top" | "bottom" | "start" | "end";
  isVertical?: boolean;
  isDisabled?: boolean;
  disabledKeys?: string[];
  fullWidth?: boolean;
  destroyInactiveTabPanel?: boolean;
  disableAnimation?: boolean;
  /** Prefix for tab/panel ids when panels live outside the component. */
  idBase?: string;
  /** @deprecated use items */ tabs?: TabItem[];
  /** @deprecated use selectedKey */ value?: string;
  /** @deprecated use onSelectionChange */ onChange?: (key: string) => void;
}

/** WAI-ARIA tabs with roving tabindex and arrow-key navigation. */
export function Tabs(props: TabsProps): JSX.Element;
