import * as React from "react";

export interface PlatoLogoProps {
  /** Diameter of the outer ring and overall component size in px. Default: 200 */
  size?: number;
  /** Show the two concentric decorative rings. Default: true */
  showRings?: boolean;
  /** Apply the warm coffee filter (sepia + hue-rotate). Default: true */
  filtered?: boolean;
  /** Override the image src. Default: ../../assets/plato-hero.png */
  src?: string;
}

export declare function PlatoLogo(props: PlatoLogoProps): React.ReactElement;
