export const PlatoLogo = function PlatoLogo({ size, showRings, filtered, src }) {
  var s      = Number(size ?? 200);
  var imgSz  = Math.round(s * 0.795);
  var r2Sz   = Math.round(s * 0.877);
  var sh     = Math.round(s * 0.05);
  var bl     = Math.round(s * 0.085);
  var warm   = filtered !== false && filtered !== "false";
  var imgSrc = src || "../../assets/plato-hero.png";
  var filt   = warm
    ? "grayscale(0.6) sepia(0.92) saturate(1.5) hue-rotate(-12deg) brightness(0.97) contrast(1.06) drop-shadow(0 " + sh + "px " + bl + "px rgba(24,18,13,0.5))"
    : "none";

  var rings = showRings !== false && showRings !== "false";

  return React.createElement("div", {
    style: { position: "relative", width: s, height: s, display: "grid", placeItems: "center", flexShrink: 0 }
  },
    rings && React.createElement("div", {
      key: "r1",
      style: { position: "absolute", width: s, height: s, borderRadius: "50%", border: "1px solid rgba(192,160,128,0.28)", pointerEvents: "none" }
    }),
    rings && React.createElement("div", {
      key: "r2",
      style: { position: "absolute", width: r2Sz, height: r2Sz, borderRadius: "50%", border: "1px solid rgba(236,229,216,0.10)", pointerEvents: "none" }
    }),
    React.createElement("img", {
      src: imgSrc,
      alt: "AInoia \u2014 Plato medallion",
      style: {
        width: imgSz, height: imgSz,
        objectFit: "cover", objectPosition: "50% 50%",
        borderRadius: "50%", filter: filt, display: "block",
        WebkitMaskImage: "radial-gradient(circle, #000 60%, transparent 75%)",
        maskImage:       "radial-gradient(circle, #000 60%, transparent 75%)",
      }
    })
  );
};
