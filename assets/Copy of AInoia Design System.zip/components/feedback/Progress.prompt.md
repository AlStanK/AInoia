Linear progress.

```jsx
<Progress label="Rollout" value={64} showValueLabel />
<Progress isIndeterminate size="sm" aria-label="Loading" />
<Progress color="success" value={98.6} maxValue={100} isStriped />
```

Props: `value/minValue/maxValue`, `isIndeterminate`, `label`, `showValueLabel`, `valueLabel`, `color`, `size`, `isStriped`.