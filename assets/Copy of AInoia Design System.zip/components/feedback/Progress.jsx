import React from "react";
import { color as pal, radius as rad } from "../core/theme.jsx";

/**
 * AInoia — Progress (HeroUI-aligned)
 * Linear progress bar. value/minValue/maxValue, isIndeterminate, label, showValueLabel, valueLabel, formatOptions.
 * color: primary (gradient) | secondary | success | warning | danger | default   size: sm | md | lg   isStriped
 */
export function Progress({
  value = 0, minValue = 0, maxValue = 100, isIndeterminate = false, label, showValueLabel = false, valueLabel, formatOptions = { style: "percent" },
  color = "primary", size = "md", radius = "full", isStriped = false, isDisabled = false, disableAnimation = false, style = {}, ...rest
}) {
  const pct = Math.min(100, Math.max(0, ((value - minValue) / (maxValue - minValue)) * 100));
  const k = pal(color);
  const h = { sm: 4, md: 8, lg: 12 }[size] || 8;
  const fill = color === "primary" ? "var(--grad-cta)" : k.solidBg;
  const txt = valueLabel ?? new Intl.NumberFormat(undefined, formatOptions).format(formatOptions.style === "percent" ? pct / 100 : value);
  const uid = React.useId();
  return (
    <div role="progressbar" aria-valuemin={minValue} aria-valuemax={maxValue} aria-valuenow={isIndeterminate ? undefined : value} aria-valuetext={isIndeterminate ? undefined : txt}
      aria-labelledby={label ? `pg-${uid}` : undefined} aria-label={!label ? rest["aria-label"] : undefined} data-indeterminate={isIndeterminate ? "true" : undefined} data-disabled={isDisabled ? "true" : undefined}
      style={{ display: "flex", flexDirection: "column", gap: 6, width: "100%", opacity: isDisabled ? 0.5 : 1, fontFamily: "var(--font-body)", ...style }} {...rest}>
      {(label || showValueLabel) && (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 12 }}>
          {label && <span id={`pg-${uid}`} style={{ fontSize: "var(--text-sm)", color: "var(--fg-2)", fontWeight: 500 }}>{label}</span>}
          {showValueLabel && !isIndeterminate && <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--fg-3)" }}>{txt}</span>}
        </div>
      )}
      <div data-slot="track" style={{ position: "relative", height: h, width: "100%", overflow: "hidden", background: "var(--ink-500)", borderRadius: rad(radius, "full") }}>
        <div data-slot="indicator" style={{
          position: "absolute", top: 0, bottom: 0, left: 0, width: isIndeterminate ? "40%" : pct + "%", borderRadius: "inherit",
          background: fill, boxShadow: color === "primary" ? k.glow : "none",
          ...(isStriped ? { backgroundImage: `linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent), ${fill}`, backgroundSize: `${h * 2}px ${h * 2}px, auto` } : {}),
          transition: disableAnimation || isIndeterminate ? "none" : "width var(--dur-slow) var(--ease-out)",
          animation: isIndeterminate && !disableAnimation ? "ainoia-indeterminate 1.4s var(--ease-in-out) infinite" : "none",
        }} />
      </div>
    </div>
  );
}
