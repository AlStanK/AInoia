import * as React from "react";
import type { Color, Radius, Size } from "../core/Button";
export interface ProgressProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "color"> {
  value?: number;
  minValue?: number;
  maxValue?: number;
  isIndeterminate?: boolean;
  label?: React.ReactNode;
  showValueLabel?: boolean;
  valueLabel?: React.ReactNode;
  formatOptions?: Intl.NumberFormatOptions;
  color?: Color;
  size?: Size;
  radius?: Radius;
  isStriped?: boolean;
  isDisabled?: boolean;
  disableAnimation?: boolean;
}
/** Linear progress bar, role="progressbar". */
export function Progress(props: ProgressProps): JSX.Element;
