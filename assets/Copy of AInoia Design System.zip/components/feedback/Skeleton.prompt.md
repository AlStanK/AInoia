Loading placeholder.

```jsx
<Skeleton isLoaded={ready}><AgentRow … /></Skeleton>
<Skeleton style={{ width: 180, height: 14 }} />
```