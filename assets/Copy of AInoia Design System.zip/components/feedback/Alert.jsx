import React from "react";
import { color as pal, radius as rad } from "../core/theme.jsx";

/**
 * AInoia — Alert (HeroUI-aligned)
 * Inline status message. variant: flat (default) | solid | bordered | faded   color: default | primary | secondary | success | warning | danger
 * title, description, icon, hideIcon, isClosable + onClose, endContent (actions). Renders role="alert".
 */
const ICON = {
  default: <path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM8 7v4M8 5h.01" />,
  primary: <path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM8 7v4M8 5h.01" />,
  secondary: <path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM8 7v4M8 5h.01" />,
  success: <path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM5 8.3l2 2 4-4.3" />,
  warning: <path d="M8 2l6.5 11.5H1.5L8 2zM8 6.5v3M8 11.5h.01" />,
  danger: <path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM5.7 5.7l4.6 4.6M10.3 5.7l-4.6 4.6" />,
};

export function Alert({ title, description, icon, hideIcon = false, color = "default", variant = "flat", radius = "md", isVisible = true, isClosable = false, onClose, endContent, children, style = {}, ...rest }) {
  const [closed, setClosed] = React.useState(false);
  if (!isVisible || closed) return null;
  const k = pal(color);
  const isDef = color === "default";
  const shells = {
    flat: { background: isDef ? "var(--ink-600)" : k.tint, border: "1px solid transparent", color: "var(--fg-1)" },
    faded: { background: isDef ? "var(--ink-600)" : k.tint, border: `1px solid ${isDef ? "var(--border-default)" : k.border}`, color: "var(--fg-1)" },
    bordered: { background: "transparent", border: `1px solid ${isDef ? "var(--border-strong)" : k.border}`, color: "var(--fg-1)" },
    solid: { background: k.solidBg, border: "1px solid transparent", color: k.solidFg },
  };
  const s = shells[variant] || shells.flat;
  const accent = variant === "solid" ? k.solidFg : isDef ? "var(--fg-2)" : k.fg;
  const sub = variant === "solid" ? k.solidFg : "var(--fg-2)";
  const close = (e) => { setClosed(true); onClose && onClose(e); };
  return (
    <div role="alert" data-color={color} data-variant={variant}
      style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "12px 14px", boxSizing: "border-box", width: "100%", borderRadius: rad(radius), fontFamily: "var(--font-body)", ...s, ...style }} {...rest}>
      {!hideIcon && <span aria-hidden="true" style={{ display: "inline-flex", flex: "none", color: accent, marginTop: 1 }}>{icon || <svg viewBox="0 0 16 16" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">{ICON[color] || ICON.default}</svg>}</span>}
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 3 }}>
        {title && <div style={{ fontSize: "var(--text-sm)", fontWeight: 600, color: variant === "solid" ? k.solidFg : "var(--fg-1)", lineHeight: 1.4 }}>{title}</div>}
        {(description || children) && <div style={{ fontSize: "var(--text-sm)", color: sub, opacity: variant === "solid" ? 0.85 : 1, lineHeight: 1.5 }}>{description}{children}</div>}
      </div>
      {endContent && <div style={{ flex: "none", display: "flex", alignItems: "center", gap: 8 }}>{endContent}</div>}
      {isClosable && (
        <button type="button" aria-label="Close" onClick={close}
          style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 28, height: 28, margin: "-5px -6px -5px 0", padding: 0, border: "none", borderRadius: "var(--radius-sm)", background: "transparent", color: accent, cursor: "pointer", opacity: 0.7, flex: "none" }}>
          <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M4 4l8 8M12 4l-8 8" /></svg>
        </button>
      )}
    </div>
  );
}
