import * as React from "react";
export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  /** When true renders children as-is. */
  isLoaded?: boolean;
  disableAnimation?: boolean;
  children?: React.ReactNode;
}
/** Shimmering placeholder that keeps the child's layout box. */
export function Skeleton(props: SkeletonProps): JSX.Element;
