Inline status message.

```jsx
<Alert color="success" title="Deployed" description="Incident Resolver v2.4 is live." />
<Alert color="warning" variant="faded" title="Degraded" isClosable endContent={<Button size="sm" variant="flat" color="warning">Details</Button>} />
```

Props: `color`, `variant flat|solid|bordered|faded`, `title`, `description`, `icon/hideIcon`, `isClosable/onClose`, `endContent`.