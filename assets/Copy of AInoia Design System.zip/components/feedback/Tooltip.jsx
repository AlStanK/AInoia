import React from "react";
import { color as pal, radius as rad } from "../core/theme.jsx";

/**
 * AInoia — Tooltip (HeroUI-aligned)
 * Wraps a single trigger; opens on hover + focus. content, placement: top | bottom | left | right (+ -start/-end),
 * delay / closeDelay, showArrow, color, size, isDisabled, isOpen / defaultOpen / onOpenChange. Escape closes.
 */
export function Tooltip({ content, children, placement = "top", delay = 0, closeDelay = 300, showArrow = false, color = "default", size = "md", radius = "md", isDisabled = false, isOpen: isOpenProp, defaultOpen = false, onOpenChange, offset = 7, style = {}, ...rest }) {
  const [inner, setInner] = React.useState(defaultOpen);
  const open = (isOpenProp ?? inner) && !isDisabled;
  const t = React.useRef();
  const set = (o) => { clearTimeout(t.current); t.current = setTimeout(() => { if (isOpenProp === undefined) setInner(o); onOpenChange && onOpenChange(o); }, o ? delay : closeDelay); };
  React.useEffect(() => () => clearTimeout(t.current), []);
  React.useEffect(() => { if (!open) return; const onKey = (e) => e.key === "Escape" && set(false); document.addEventListener("keydown", onKey); return () => document.removeEventListener("keydown", onKey); }, [open]);
  const uid = React.useId();
  const id = `tt-${uid}`;
  const k = pal(color);
  const isDef = color === "default" || color === "foreground";
  const bg = color === "foreground" ? "var(--fg-1)" : isDef ? "var(--ink-500)" : k.solidBg;
  const fg = color === "foreground" ? "var(--ink-900)" : isDef ? "var(--fg-1)" : k.solidFg;
  const [side, align = "center"] = placement.split("-");
  const pos = {
    top: { bottom: `calc(100% + ${offset}px)` }, bottom: { top: `calc(100% + ${offset}px)` },
    left: { right: `calc(100% + ${offset}px)` }, right: { left: `calc(100% + ${offset}px)` },
  }[side] || {};
  const horiz = side === "top" || side === "bottom";
  const cross = horiz
    ? align === "start" ? { left: 0 } : align === "end" ? { right: 0 } : { left: "50%", transform: "translateX(-50%)" }
    : align === "start" ? { top: 0 } : align === "end" ? { bottom: 0 } : { top: "50%", transform: "translateY(-50%)" };
  const fs = { sm: "var(--text-xs)", md: "var(--text-sm)", lg: "var(--text-base)" }[size] || "var(--text-sm)";
  const arrow = showArrow && (
    <span aria-hidden="true" style={{ position: "absolute", width: 8, height: 8, background: bg, transform: "rotate(45deg)",
      ...(side === "top" ? { bottom: -4, left: "calc(50% - 4px)" } : side === "bottom" ? { top: -4, left: "calc(50% - 4px)" } : side === "left" ? { right: -4, top: "calc(50% - 4px)" } : { left: -4, top: "calc(50% - 4px)" }) }} />
  );
  const child = React.Children.only(children);
  const trigger = React.cloneElement(child, {
    "aria-describedby": open ? id : child.props["aria-describedby"],
    onMouseEnter: (e) => { set(true); child.props.onMouseEnter && child.props.onMouseEnter(e); },
    onMouseLeave: (e) => { set(false); child.props.onMouseLeave && child.props.onMouseLeave(e); },
    onFocus: (e) => { set(true); child.props.onFocus && child.props.onFocus(e); },
    onBlur: (e) => { set(false); child.props.onBlur && child.props.onBlur(e); },
  });
  return (
    <span style={{ position: "relative", display: "inline-flex", ...style }} {...rest}>
      {trigger}
      <span role="tooltip" id={id} data-open={open ? "true" : undefined} data-placement={placement}
        onMouseEnter={() => set(true)} onMouseLeave={() => set(false)}
        style={{ position: "absolute", zIndex: 50, ...pos, ...cross, pointerEvents: open ? "auto" : "none", whiteSpace: "nowrap",
          padding: size === "sm" ? "4px 8px" : "6px 10px", borderRadius: rad(radius), background: bg, color: fg, fontFamily: "var(--font-body)", fontSize: fs, lineHeight: 1.4,
          border: isDef && color !== "foreground" ? "1px solid var(--border-strong)" : "none", boxShadow: "var(--shadow-md)",
          opacity: open ? 1 : 0, transition: "opacity var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)" }}>
        {arrow}{content}
      </span>
    </span>
  );
}
