import * as React from "react";
import type { Color, Radius, Size } from "../core/Button";
export type TooltipPlacement = "top" | "bottom" | "left" | "right" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end";
export interface TooltipProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "color" | "content"> {
  content: React.ReactNode;
  /** Exactly one focusable trigger element. */
  children: React.ReactElement;
  placement?: TooltipPlacement;
  delay?: number;
  closeDelay?: number;
  offset?: number;
  showArrow?: boolean;
  color?: Color | "foreground";
  size?: Size;
  radius?: Radius;
  isDisabled?: boolean;
  isOpen?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (isOpen: boolean) => void;
}
/** Hover + focus tooltip, role="tooltip", linked via aria-describedby. */
export function Tooltip(props: TooltipProps): JSX.Element;
