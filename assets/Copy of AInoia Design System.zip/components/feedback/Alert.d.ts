import * as React from "react";
import type { Color, Radius } from "../core/Button";
export interface AlertProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "color" | "title"> {
  title?: React.ReactNode;
  description?: React.ReactNode;
  icon?: React.ReactNode;
  hideIcon?: boolean;
  color?: Color;
  variant?: "flat" | "solid" | "bordered" | "faded";
  radius?: Radius;
  isVisible?: boolean;
  isClosable?: boolean;
  onClose?: () => void;
  /** Trailing actions. */
  endContent?: React.ReactNode;
  children?: React.ReactNode;
}
/** Inline status message, role="alert". */
export function Alert(props: AlertProps): JSX.Element;
