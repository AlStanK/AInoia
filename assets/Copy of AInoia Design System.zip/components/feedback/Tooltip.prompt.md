Hover/focus hint on one trigger.

```jsx
<Tooltip content="Restart agent"><IconButton label="Restart"><Ico n="rotate-cw" /></IconButton></Tooltip>
<Tooltip content="Runs in the last 24h" placement="bottom" showArrow color="foreground">…</Tooltip>
```

Props: `content`, `placement`, `delay/closeDelay`, `showArrow`, `color`, `size`, `isDisabled`, `isOpen/onOpenChange`.