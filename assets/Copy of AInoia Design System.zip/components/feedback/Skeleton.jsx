import React from "react";

/**
 * AInoia — Skeleton (HeroUI-aligned)
 * Loading placeholder. Wrap the eventual content and toggle isLoaded; the child keeps its layout box.
 * Standalone: give width/height via style. disableAnimation stops the shimmer.
 */
export function Skeleton({ isLoaded = false, disableAnimation = false, children, style = {}, ...rest }) {
  if (isLoaded) return <div data-loaded="true" style={style} {...rest}>{children}</div>;
  return (
    <div data-loaded="false" aria-busy="true" aria-live="polite"
      style={{ position: "relative", display: children ? "block" : "inline-block", overflow: "hidden", borderRadius: "var(--radius-sm)",
        background: "var(--ink-600)", minHeight: children ? undefined : 12, ...style }} {...rest}>
      <span aria-hidden="true" style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, transparent 0%, rgba(236,229,216,0.06) 50%, transparent 100%)", backgroundSize: "200% 100%", animation: disableAnimation ? "none" : "ainoia-skeleton 1.6s linear infinite" }} />
      {children && <div style={{ visibility: "hidden" }}>{children}</div>}
    </div>
  );
}
