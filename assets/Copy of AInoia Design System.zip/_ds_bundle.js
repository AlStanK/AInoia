/* @ds-bundle: {"format":4,"namespace":"CODISAIDesignSystem_b12028","components":[{"name":"PlatoLogo","sourcePath":"components/brand/PlatoLogo.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Kbd","sourcePath":"components/core/Kbd.jsx"},{"name":"Link","sourcePath":"components/core/Link.jsx"},{"name":"Spinner","sourcePath":"components/core/Spinner.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"AgentRow","sourcePath":"components/data/AgentRow.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Progress","sourcePath":"components/feedback/Progress.jsx"},{"name":"Skeleton","sourcePath":"components/feedback/Skeleton.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"CheckboxGroup","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"RadioGroup","sourcePath":"components/forms/Radio.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"SelectItem","sourcePath":"components/forms/Select.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Modal","sourcePath":"components/overlays/Modal.jsx"},{"name":"ModalContent","sourcePath":"components/overlays/Modal.jsx"},{"name":"ModalHeader","sourcePath":"components/overlays/Modal.jsx"},{"name":"ModalBody","sourcePath":"components/overlays/Modal.jsx"},{"name":"ModalFooter","sourcePath":"components/overlays/Modal.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"CardHeader","sourcePath":"components/surfaces/Card.jsx"},{"name":"CardBody","sourcePath":"components/surfaces/Card.jsx"},{"name":"CardFooter","sourcePath":"components/surfaces/Card.jsx"},{"name":"StatCard","sourcePath":"components/surfaces/StatCard.jsx"}],"sourceHashes":{"components/brand/PlatoLogo.jsx":"d9b3663cd828","components/core/Avatar.jsx":"fcf1721655ba","components/core/Badge.jsx":"d532eb19e686","components/core/Button.jsx":"bc390507d2aa","components/core/Chip.jsx":"8336a40e8cac","components/core/Divider.jsx":"14f62d071de5","components/core/IconButton.jsx":"d13a24d08370","components/core/Kbd.jsx":"abac1678e997","components/core/Link.jsx":"c700fd731e03","components/core/Spinner.jsx":"12630f3807d7","components/core/Tag.jsx":"698209d6351c","components/core/theme.jsx":"6de18ccc6739","components/data/AgentRow.jsx":"03857674ef29","components/feedback/Alert.jsx":"cb4d85c98691","components/feedback/Progress.jsx":"3a33146903a0","components/feedback/Skeleton.jsx":"1a0b2f43611e","components/feedback/Tooltip.jsx":"acebd8ddd402","components/forms/Checkbox.jsx":"ed39c856f68c","components/forms/Input.jsx":"53290da958d2","components/forms/Radio.jsx":"0f555305ee56","components/forms/Select.jsx":"5e382aaba9b5","components/forms/Switch.jsx":"52948393632f","components/forms/Textarea.jsx":"8c77495c6c3a","components/navigation/Tabs.jsx":"af97f680e664","components/overlays/Modal.jsx":"5cb4c25dbc7d","components/surfaces/Card.jsx":"bbe9b95c0ec3","components/surfaces/StatCard.jsx":"7a66d95bb37c","ui_kits/ainoia_board/AgentsPanel.jsx":"659d14692f0e","ui_kits/ainoia_board/PerformancePanel.jsx":"9acf99b4d3a2","ui_kits/ainoia_board/Sidebar.jsx":"2403f3fd51dc","ui_kits/ainoia_board/TopBar.jsx":"c0a3e2579844","ui_kits/ainoia_board/WorkflowCanvas.jsx":"a37ef5e819da"},"inlinedExternals":[],"unexposedExports":[{"name":"color","sourcePath":"components/core/theme.jsx"},{"name":"controlFont","sourcePath":"components/core/theme.jsx"},{"name":"controlH","sourcePath":"components/core/theme.jsx"},{"name":"dataAttr","sourcePath":"components/core/theme.jsx"},{"name":"fill","sourcePath":"components/core/theme.jsx"},{"name":"palette","sourcePath":"components/core/theme.jsx"},{"name":"radii","sourcePath":"components/core/theme.jsx"},{"name":"radius","sourcePath":"components/core/theme.jsx"},{"name":"useInteraction","sourcePath":"components/core/theme.jsx"}]} */

(() => {

const __ds_ns = (window.CODISAIDesignSystem_b12028 = window.CODISAIDesignSystem_b12028 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/PlatoLogo.jsx
try { (() => {
const PlatoLogo = function PlatoLogo({
  size,
  showRings,
  filtered,
  src
}) {
  var s = Number(size ?? 200);
  var imgSz = Math.round(s * 0.795);
  var r2Sz = Math.round(s * 0.877);
  var sh = Math.round(s * 0.05);
  var bl = Math.round(s * 0.085);
  var warm = filtered !== false && filtered !== "false";
  var imgSrc = src || "../../assets/plato-hero.png";
  var filt = warm ? "grayscale(0.6) sepia(0.92) saturate(1.5) hue-rotate(-12deg) brightness(0.97) contrast(1.06) drop-shadow(0 " + sh + "px " + bl + "px rgba(24,18,13,0.5))" : "none";
  var rings = showRings !== false && showRings !== "false";
  return React.createElement("div", {
    style: {
      position: "relative",
      width: s,
      height: s,
      display: "grid",
      placeItems: "center",
      flexShrink: 0
    }
  }, rings && React.createElement("div", {
    key: "r1",
    style: {
      position: "absolute",
      width: s,
      height: s,
      borderRadius: "50%",
      border: "1px solid rgba(192,160,128,0.28)",
      pointerEvents: "none"
    }
  }), rings && React.createElement("div", {
    key: "r2",
    style: {
      position: "absolute",
      width: r2Sz,
      height: r2Sz,
      borderRadius: "50%",
      border: "1px solid rgba(236,229,216,0.10)",
      pointerEvents: "none"
    }
  }), React.createElement("img", {
    src: imgSrc,
    alt: "AInoia \u2014 Plato medallion",
    style: {
      width: imgSz,
      height: imgSz,
      objectFit: "cover",
      objectPosition: "50% 50%",
      borderRadius: "50%",
      filter: filt,
      display: "block",
      WebkitMaskImage: "radial-gradient(circle, #000 60%, transparent 75%)",
      maskImage: "radial-gradient(circle, #000 60%, transparent 75%)"
    }
  }));
};
Object.assign(__ds_scope, { PlatoLogo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/PlatoLogo.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Divider
 * Hairline separator. orientation: horizontal (default) | vertical. Renders role="separator".
 */
function Divider({
  orientation = "horizontal",
  style = {},
  ...rest
}) {
  const v = orientation === "vertical";
  return /*#__PURE__*/React.createElement("hr", _extends({
    role: "separator",
    "aria-orientation": orientation,
    "data-orientation": orientation,
    style: {
      flex: "none",
      border: "none",
      margin: 0,
      background: "var(--border-default)",
      width: v ? 1 : "100%",
      height: v ? "auto" : 1,
      alignSelf: v ? "stretch" : undefined,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/Kbd.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Kbd
 * Keyboard shortcut chip. keys: array of modifier names (command|shift|ctrl|option|enter|delete|escape|tab|capslock|up|right|down|left|pageup|pagedown|home|end|help|space).
 */
const SYM = {
  command: "⌘",
  shift: "⇧",
  ctrl: "⌃",
  option: "⌥",
  enter: "↵",
  delete: "⌫",
  escape: "⎋",
  tab: "⇥",
  capslock: "⇪",
  up: "↑",
  right: "→",
  down: "↓",
  left: "←",
  pageup: "⇞",
  pagedown: "⇟",
  home: "↖",
  end: "↘",
  help: "?",
  space: "␣"
};
function Kbd({
  keys = [],
  children,
  style = {},
  ...rest
}) {
  const list = Array.isArray(keys) ? keys : [keys];
  return /*#__PURE__*/React.createElement("kbd", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      height: 22,
      padding: "0 6px",
      boxSizing: "border-box",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--fg-2)",
      background: "var(--ink-600)",
      border: "1px solid var(--border-default)",
      borderBottomWidth: 2,
      borderRadius: "var(--radius-xs)",
      lineHeight: 1,
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), list.map(k => /*#__PURE__*/React.createElement("abbr", {
    key: k,
    title: k,
    style: {
      textDecoration: "none"
    }
  }, SYM[k] || k)), children && /*#__PURE__*/React.createElement("span", null, children));
}
Object.assign(__ds_scope, { Kbd });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Kbd.jsx", error: String((e && e.message) || e) }); }

// components/core/theme.jsx
try { (() => {
/**
 * AInoia — shared variant vocabulary (HeroUI-aligned).
 * color: default | primary | secondary | success | warning | danger
 * radius: none | sm | md | lg | full
 * size: sm | md | lg
 */
const palette = {
  default: {
    fg: "var(--fg-1)",
    solidBg: "var(--ink-500)",
    solidFg: "var(--fg-1)",
    tint: "var(--ink-600)",
    tintStrong: "var(--ink-500)",
    border: "var(--border-strong)",
    glow: "none",
    glowHover: "none",
    dot: "var(--fg-3)"
  },
  primary: {
    fg: "var(--cyan)",
    solidBg: "var(--grad-cta)",
    solidFg: "var(--fg-on-accent)",
    tint: "var(--accent-tint)",
    tintStrong: "var(--accent-tint-strong)",
    border: "var(--border-glow)",
    glow: "var(--glow-cyan-sm)",
    glowHover: "var(--glow-cyan)",
    dot: "var(--cyan)"
  },
  secondary: {
    fg: "var(--violet-bright)",
    solidBg: "var(--violet)",
    solidFg: "var(--fg-on-accent)",
    tint: "var(--clay-tint)",
    tintStrong: "var(--clay-tint)",
    border: "var(--clay-border)",
    glow: "none",
    glowHover: "none",
    dot: "var(--violet)"
  },
  success: {
    fg: "var(--success)",
    solidBg: "var(--success)",
    solidFg: "var(--fg-on-accent)",
    tint: "var(--success-tint)",
    tintStrong: "var(--success-tint)",
    border: "var(--success-border)",
    glow: "none",
    glowHover: "none",
    dot: "var(--success)"
  },
  warning: {
    fg: "var(--warning)",
    solidBg: "var(--warning)",
    solidFg: "var(--fg-on-accent)",
    tint: "var(--warning-tint)",
    tintStrong: "var(--warning-tint)",
    border: "var(--warning-border)",
    glow: "none",
    glowHover: "none",
    dot: "var(--warning)"
  },
  danger: {
    fg: "var(--danger)",
    solidBg: "var(--danger)",
    solidFg: "var(--fg-on-accent)",
    tint: "var(--danger-tint)",
    tintStrong: "var(--danger-tint)",
    border: "var(--danger-border)",
    glow: "none",
    glowHover: "none",
    dot: "var(--danger)"
  }
};
const color = c => palette[c] || palette.default;
const radii = {
  none: "0",
  sm: "var(--radius-sm)",
  md: "var(--radius-md)",
  lg: "var(--radius-lg)",
  full: "var(--radius-pill)"
};
const radius = (r, fallback = "md") => radii[r] || radii[fallback];
const controlH = {
  sm: "var(--control-h-sm)",
  md: "var(--control-h-md)",
  lg: "var(--control-h-lg)"
};
const controlFont = {
  sm: "var(--text-sm)",
  md: "var(--text-base)",
  lg: "var(--text-md)"
};

/** true → "true", false → undefined (HeroUI data-attr convention). */
const dataAttr = v => v ? "true" : undefined;

/** Fill-style for a (variant, color) pair. Shared by Button, Chip, Badge, Tabs. */
function fill(variant, c, {
  hover = false
} = {}) {
  const k = color(c);
  const isDefault = !c || c === "default";
  switch (variant) {
    case "solid":
      return {
        background: k.solidBg,
        color: k.solidFg,
        borderColor: "transparent",
        boxShadow: k.glow,
        opacity: hover ? 0.92 : 1
      };
    case "shadow":
      return {
        background: k.solidBg,
        color: k.solidFg,
        borderColor: "transparent",
        boxShadow: c === "primary" ? hover ? k.glowHover : k.glow : "var(--shadow-md)",
        opacity: hover ? 0.92 : 1
      };
    case "bordered":
      return {
        background: hover ? k.tint : "transparent",
        color: k.fg,
        borderColor: k.border,
        boxShadow: "none"
      };
    case "ghost":
      return hover ? {
        background: k.solidBg,
        color: k.solidFg,
        borderColor: "transparent",
        boxShadow: "none"
      } : {
        background: "transparent",
        color: k.fg,
        borderColor: k.border,
        boxShadow: "none"
      };
    case "flat":
      return {
        background: hover ? k.tintStrong : k.tint,
        color: k.fg,
        borderColor: "transparent",
        boxShadow: "none"
      };
    case "faded":
      return {
        background: hover ? "var(--ink-500)" : "var(--ink-600)",
        color: k.fg,
        borderColor: "var(--border-default)",
        boxShadow: "none"
      };
    case "light":
      return {
        background: hover ? isDefault ? "var(--ink-600)" : k.tint : "transparent",
        color: isDefault ? hover ? "var(--fg-1)" : "var(--fg-2)" : k.fg,
        borderColor: "transparent",
        boxShadow: "none"
      };
    default:
      return fill("solid", c, {
        hover
      });
  }
}

/** Hover / press / focus-visible tracking with HeroUI-style data attributes. */
function useInteraction({
  isDisabled = false,
  onPress,
  onClick
} = {}) {
  const [hover, setHover] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const props = {
    onMouseEnter: () => !isDisabled && setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPressed(false);
    },
    onMouseDown: () => !isDisabled && setPressed(true),
    onMouseUp: () => setPressed(false),
    onFocus: e => {
      try {
        setFocusVisible(e.target.matches(":focus-visible"));
      } catch (_) {
        setFocusVisible(true);
      }
    },
    onBlur: () => setFocusVisible(false),
    onClick: e => {
      if (isDisabled) {
        e.preventDefault();
        return;
      }
      onClick && onClick(e);
      onPress && onPress(e);
    },
    "data-hover": dataAttr(hover),
    "data-pressed": dataAttr(pressed),
    "data-focus-visible": dataAttr(focusVisible),
    "data-disabled": dataAttr(isDisabled)
  };
  return {
    hover,
    pressed,
    focusVisible,
    props
  };
}
Object.assign(__ds_scope, { palette, color, radii, radius, controlH, controlFont, dataAttr, fill, useInteraction });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/theme.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Avatar
 * Identity token for users and agents. `isBordered` (legacy `agent`) adds the gradient ring.
 * size: xs | sm | md | lg   radius: none | sm | md | lg | full   color: default | primary | …
 */
const defaultInitials = (name = "") => name.split(" ").map(w => w[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
function Avatar({
  name = "",
  src,
  alt,
  icon,
  fallback,
  size = "md",
  radius = "full",
  color = "default",
  isBordered = false,
  isDisabled = false,
  isFocusable = false,
  showFallback = true,
  getInitials = defaultInitials,
  imgProps = {},
  onError,
  status,
  agent = false,
  style = {},
  ...rest
}) {
  const [failed, setFailed] = React.useState(false);
  React.useEffect(() => setFailed(false), [src]);
  const d = {
    xs: 24,
    sm: 32,
    md: 40,
    lg: 56
  }[size] || 40;
  const bordered = isBordered || agent;
  const k = __ds_scope.color(color);
  const r = __ds_scope.radius(radius, "md");
  const statusColors = {
    active: "var(--success)",
    idle: "var(--warning)",
    offline: "var(--fg-4)"
  };
  const showImg = src && !failed;
  const inner = showImg ? /*#__PURE__*/React.createElement("img", _extends({
    src: src,
    alt: alt ?? (name || "avatar"),
    onError: e => {
      setFailed(true);
      onError && onError(e);
    }
  }, imgProps, {
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      ...(imgProps.style || {})
    }
  })) : showFallback ? fallback || icon || getInitials(name) || "·" : null;
  return /*#__PURE__*/React.createElement("span", _extends({
    tabIndex: isFocusable ? 0 : undefined,
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    "aria-label": !showImg && name ? name : undefined,
    role: !showImg && name ? "img" : undefined,
    style: {
      position: "relative",
      display: "inline-flex",
      flex: "none",
      borderRadius: r,
      padding: bordered ? 2 : 0,
      background: bordered ? color === "default" || color === "primary" ? "var(--grad-cta)" : k.solidBg : "transparent",
      opacity: isDisabled ? 0.5 : 1,
      filter: isDisabled ? "grayscale(1)" : "none",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: d,
      height: d,
      borderRadius: r,
      overflow: "hidden",
      boxSizing: "border-box",
      background: showImg ? "var(--ink-600)" : color === "default" ? "var(--ink-500)" : k.tint,
      border: bordered ? "2px solid var(--ink-800)" : `1px solid ${color === "default" ? "var(--border-default)" : k.border}`,
      color: color === "default" ? "var(--fg-1)" : k.fg,
      fontFamily: "var(--font-body)",
      fontSize: d * 0.36,
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "0.02em"
    }
  }, inner), status && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      right: -1,
      bottom: -1,
      width: Math.max(8, d * 0.26),
      height: Math.max(8, d * 0.26),
      borderRadius: "50%",
      background: statusColors[status] || "var(--fg-4)",
      border: "2px solid var(--ink-800)"
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Badge
 * Standalone: small status pill (`<Badge color="success">98%</Badge>`).
 * Overlay (HeroUI): wrap children and pass `content` — the badge anchors to a corner.
 * variant: flat | solid | faded | shadow | dot   color: default | primary | secondary | success | warning | danger
 * Legacy: tone="neutral|active|violet|…" → color, `dot` → variant="dot".
 */
const TONE = {
  neutral: "default",
  active: "primary",
  violet: "secondary",
  success: "success",
  warning: "warning",
  danger: "danger"
};
function Badge({
  variant = "flat",
  color = "default",
  size = "md",
  shape = "rectangle",
  content,
  placement = "top-right",
  isInvisible = false,
  isOneChar,
  showOutline = true,
  disableOutline,
  tone,
  dot = false,
  children,
  style = {},
  ...rest
}) {
  if (tone) color = TONE[tone] || "default";
  if (dot) variant = "dot";
  const k = __ds_scope.color(color);
  const isDot = variant === "dot";
  const look = isDot ? {
    background: k.tint,
    color: k.fg,
    borderColor: k.border,
    boxShadow: "none"
  } : __ds_scope.fill(variant === "flat" ? "flat" : variant, color);
  if (variant === "flat" || isDot) look.borderColor = k.border;
  const overlay = content !== undefined;
  const oneChar = isOneChar ?? (overlay && String(content).length === 1);
  const empty = overlay && String(content).length === 0;
  const h = overlay ? {
    sm: 16,
    md: 20,
    lg: 24
  }[size] : 22;
  const pill = /*#__PURE__*/React.createElement("span", _extends({
    "data-invisible": __ds_scope.dataAttr(isInvisible),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "6px",
      boxSizing: "border-box",
      height: empty ? h * 0.6 : h,
      minWidth: empty ? h * 0.6 : oneChar ? h : undefined,
      padding: empty || oneChar ? 0 : "0 10px",
      fontFamily: "var(--font-body)",
      fontSize: overlay && size === "sm" ? "10px" : "var(--text-xs)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "0.02em",
      border: `1px solid ${overlay && showOutline && !disableOutline ? "var(--ink-800)" : "transparent"}`,
      borderRadius: "var(--radius-pill)",
      whiteSpace: "nowrap",
      ...look,
      ...(overlay ? {
        position: "absolute",
        zIndex: 1,
        top: placement.startsWith("top") ? 0 : "auto",
        bottom: placement.startsWith("bottom") ? 0 : "auto",
        right: placement.endsWith("right") ? 0 : "auto",
        left: placement.endsWith("left") ? 0 : "auto",
        transform: `translate(${placement.endsWith("right") ? "40%" : "-40%"}, ${placement.startsWith("top") ? "-40%" : "40%"})`,
        transition: "opacity var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out)",
        opacity: isInvisible ? 0 : 1,
        pointerEvents: isInvisible ? "none" : "auto",
        ...(shape === "circle" ? {} : {})
      } : {}),
      ...style
    }
  }, overlay ? {} : rest), isDot && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: k.dot,
      flex: "none",
      boxShadow: color === "primary" || color === "success" ? `0 0 6px ${k.dot}` : "none"
    }
  }), overlay ? content : children);
  if (!overlay) return pill;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      flex: "none"
    }
  }, rest), children, pill);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Chip
 * Compact label for filters, metadata and status.
 * variant: solid | bordered | light | flat | faded | shadow | dot
 * color:   default | primary | secondary | success | warning | danger
 */
function Chip({
  variant = "flat",
  color = "default",
  size = "md",
  radius: r = "sm",
  isSelected = false,
  isDisabled = false,
  startContent = null,
  endContent = null,
  avatar = null,
  onClose,
  children,
  style = {},
  ...rest
}) {
  const sel = isSelected ? {
    variant: "flat",
    color: color === "default" ? "primary" : color
  } : {
    variant,
    color
  };
  const k = __ds_scope.color(sel.color);
  const dims = {
    sm: {
      h: 22,
      px: 8,
      fs: "var(--text-xs)"
    },
    md: {
      h: 26,
      px: 12,
      fs: "var(--text-sm)"
    },
    lg: {
      h: 32,
      px: 14,
      fs: "var(--text-base)"
    }
  }[size] || {
    h: 26,
    px: 12,
    fs: "var(--text-sm)"
  };
  const isDot = variant === "dot";
  const look = isDot ? {
    background: "transparent",
    color: "var(--fg-2)",
    borderColor: "var(--border-default)",
    boxShadow: "none"
  } : __ds_scope.fill(sel.variant, sel.color);
  const lead = avatar || startContent;
  return /*#__PURE__*/React.createElement("span", _extends({
    "data-selected": __ds_scope.dataAttr(isSelected),
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    "aria-disabled": isDisabled || undefined,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "7px",
      boxSizing: "border-box",
      height: dims.h,
      padding: `0 ${onClose ? dims.px - 3 : dims.px}px 0 ${lead ? dims.px - 4 : dims.px}px`,
      fontFamily: "var(--font-body)",
      fontSize: dims.fs,
      fontWeight: "var(--weight-medium)",
      whiteSpace: "nowrap",
      border: "1px solid transparent",
      borderRadius: __ds_scope.radius(r, "sm"),
      opacity: isDisabled ? 0.5 : 1,
      cursor: "default",
      transition: "all var(--dur-base) var(--ease-out)",
      ...look,
      ...style
    }
  }, rest), isDot && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: k.dot,
      flex: "none"
    }
  }), lead, children, endContent, onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "close chip",
    disabled: isDisabled,
    onClick: onClose,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 16,
      height: 16,
      padding: 0,
      border: "none",
      cursor: isDisabled ? "not-allowed" : "pointer",
      borderRadius: "50%",
      background: "transparent",
      color: "inherit",
      opacity: 0.7,
      fontFamily: "var(--font-body)",
      fontSize: 14,
      lineHeight: 1
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/Link.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Link (HeroUI-aligned)
 * Inline anchor. color: primary (default) | foreground | secondary | success | warning | danger
 * underline: none | hover (default) | always | active   size: sm | md | lg   isExternal adds target=_blank + rel + icon (showAnchorIcon).
 */
function Link({
  color = "primary",
  underline = "hover",
  size = "md",
  isExternal = false,
  showAnchorIcon = false,
  anchorIcon,
  isBlock = false,
  isDisabled = false,
  href,
  children,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const fg = color === "foreground" ? "var(--fg-1)" : __ds_scope.color(color).fg;
  const fs = {
    sm: "var(--text-sm)",
    md: "var(--text-base)",
    lg: "var(--text-md)"
  }[size] || "var(--text-base)";
  const deco = underline === "always" || underline === "hover" && hover || underline === "active" && hover;
  const icon = anchorIcon || /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 16 16",
    width: "0.9em",
    height: "0.9em",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 3h7v7M13 3L4 12"
  }));
  return /*#__PURE__*/React.createElement("a", _extends({
    href: isDisabled ? undefined : href,
    "aria-disabled": isDisabled || undefined,
    tabIndex: isDisabled ? -1 : undefined,
    target: isExternal ? "_blank" : undefined,
    rel: isExternal ? "noopener noreferrer" : undefined,
    "data-hover": __ds_scope.dataAttr(hover),
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      color: fg,
      fontFamily: "var(--font-body)",
      fontSize: fs,
      fontWeight: 500,
      lineHeight: 1.4,
      textDecoration: deco ? "underline" : "none",
      textUnderlineOffset: 3,
      textDecorationThickness: 1,
      padding: isBlock ? "4px 8px" : 0,
      borderRadius: isBlock ? "var(--radius-sm)" : 0,
      background: isBlock && hover ? __ds_scope.color(color === "foreground" ? "default" : color).tint : "transparent",
      opacity: isDisabled ? 0.5 : hover && !isBlock ? 0.85 : 1,
      pointerEvents: isDisabled ? "none" : "auto",
      cursor: isDisabled ? "default" : "pointer",
      transition: "opacity var(--dur-fast), background var(--dur-fast)",
      ...style
    }
  }, rest), children, (showAnchorIcon || isExternal && showAnchorIcon !== false && anchorIcon) && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: "inline-flex"
    }
  }, icon));
}
Object.assign(__ds_scope, { Link });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Link.jsx", error: String((e && e.message) || e) }); }

// components/core/Spinner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Spinner
 * Circular loading indicator. Sizes sm | md | lg; colors follow the shared palette.
 */
function Spinner({
  size = "md",
  color: c = "current",
  label,
  style = {},
  ...rest
}) {
  const d = {
    sm: 16,
    md: 24,
    lg: 32
  }[size] || 24;
  const stroke = size === "sm" ? 2 : 3;
  const col = c === "current" ? "currentColor" : __ds_scope.color(c).fg;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "status",
    "aria-label": label || "Loading",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: d,
      height: d,
      flex: "none",
      borderRadius: "50%",
      boxSizing: "border-box",
      border: `${stroke}px solid`,
      borderColor: `${col} transparent ${col} transparent`,
      opacity: 0.9,
      animation: "ainoia-spin 0.8s linear infinite"
    }
  }), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--fg-2)"
    }
  }, label));
}
Object.assign(__ds_scope, { Spinner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Spinner.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Button (HeroUI-aligned API)
 * variant: solid | bordered | light | flat | faded | ghost | shadow
 * color:   default | primary | secondary | success | warning | danger
 * Legacy aliases still accepted: variant="primary|secondary|outline|ghost|danger",
 * disabled, iconLeft/iconRight, onClick.
 */
const LEGACY = {
  primary: ["solid", "primary"],
  secondary: ["solid", "default"],
  outline: ["bordered", "primary"],
  ghost: ["light", "default"],
  danger: ["solid", "danger"]
};
function Button({
  variant = "solid",
  color = "primary",
  size = "md",
  radius: r = "md",
  fullWidth = false,
  isDisabled = false,
  isLoading = false,
  isIconOnly = false,
  disableAnimation = false,
  startContent = null,
  endContent = null,
  spinner,
  spinnerPlacement = "start",
  onPress,
  // legacy
  disabled = false,
  iconLeft = null,
  iconRight = null,
  children,
  style = {},
  ...rest
}) {
  if (LEGACY[variant]) {
    const [v, c] = LEGACY[variant];
    variant = v;
    if (color === "primary") color = c;
  }
  startContent = startContent || iconLeft;
  endContent = endContent || iconRight;
  const off = isDisabled || disabled || isLoading;
  const {
    hover,
    pressed,
    props
  } = __ds_scope.useInteraction({
    isDisabled: off,
    onPress,
    onClick: rest.onClick
  });
  const h = __ds_scope.controlH[size] || __ds_scope.controlH.md;
  const pads = isIconOnly ? "0" : {
    sm: "0 14px",
    md: "0 20px",
    lg: "0 28px"
  }[size];
  const spin = spinner || /*#__PURE__*/React.createElement(__ds_scope.Spinner, {
    size: size === "lg" ? "md" : "sm"
  });
  const iconClone = n => React.isValidElement(n) ? React.cloneElement(n, {
    "aria-hidden": true,
    focusable: false
  }) : n;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: off,
    "aria-busy": isLoading || undefined,
    "data-loading": __ds_scope.dataAttr(isLoading)
  }, rest, props, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: size === "lg" ? "12px" : "8px",
      height: h,
      minWidth: isIconOnly ? h : undefined,
      width: fullWidth ? "100%" : isIconOnly ? h : "auto",
      padding: pads,
      boxSizing: "border-box",
      fontFamily: "var(--font-body)",
      fontSize: __ds_scope.controlFont[size],
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "0.01em",
      borderRadius: __ds_scope.radius(r),
      border: "1px solid transparent",
      cursor: off ? "not-allowed" : "pointer",
      opacity: off ? 0.45 : 1,
      whiteSpace: "nowrap",
      userSelect: "none",
      transform: pressed && !disableAnimation ? "scale(0.97)" : "none",
      transition: disableAnimation ? "none" : "transform var(--dur-fast) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)",
      ...__ds_scope.fill(variant, color, {
        hover
      }),
      ...style
    }
  }), isLoading && spinnerPlacement === "start" ? spin : iconClone(startContent), children, isLoading && spinnerPlacement === "end" ? spin : iconClone(endContent));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — IconButton
 * `Button isIconOnly` with a required accessible label. Quiet (`light`) by default.
 * Legacy variants: ghost → light/default, solid → faded/default, glow → flat/primary; `round` → radius="full".
 */
const LEGACY = {
  ghost: ["light", "default"],
  solid: ["faded", "default"],
  glow: ["flat", "primary"]
};
function IconButton({
  variant = "light",
  color = "default",
  round = false,
  radius,
  label,
  children,
  ...rest
}) {
  if (LEGACY[variant]) {
    const [v, c] = LEGACY[variant];
    variant = v;
    if (color === "default") color = c;
  }
  return /*#__PURE__*/React.createElement(__ds_scope.Button, _extends({
    isIconOnly: true,
    variant: variant,
    color: color,
    radius: radius || (round ? "full" : "md"),
    "aria-label": rest["aria-label"] || label,
    title: rest.title || label
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Tag (legacy alias of Chip)
 * `selected` → isSelected, `onRemove` → onClose. Prefer Chip in new code.
 */
function Tag({
  selected,
  onRemove,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Chip, _extends({
    variant: "faded",
    isSelected: !!selected,
    onClose: onRemove
  }, rest));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/AgentRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — AgentRow
 * A single agent line: identity, role, status, runs and a trailing slot.
 * Pressable when onPress/onClick is given (role="button", Enter/Space). Legacy: selected → isSelected.
 */
function AgentRow({
  name,
  role,
  status = "active",
  runs,
  isSelected,
  isDisabled = false,
  onPress,
  onClick,
  trailing,
  endContent,
  selected = false,
  style = {},
  ...rest
}) {
  const sel = isSelected ?? selected;
  const pressable = !!(onPress || onClick);
  const {
    hover,
    props
  } = __ds_scope.useInteraction({
    isDisabled,
    onPress,
    onClick
  });
  const statusColor = {
    active: "primary",
    idle: "warning",
    error: "danger",
    paused: "default"
  }[status] || "default";
  const statusLabel = {
    active: "Active",
    idle: "Idle",
    error: "Error",
    paused: "Paused"
  }[status] || status;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: pressable ? "button" : undefined,
    tabIndex: pressable && !isDisabled ? 0 : undefined,
    "aria-pressed": pressable ? sel : undefined,
    "aria-disabled": isDisabled || undefined,
    "data-selected": __ds_scope.dataAttr(sel),
    onKeyDown: pressable ? e => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        props.onClick(e);
      }
    } : undefined
  }, rest, pressable ? props : {
    "data-disabled": __ds_scope.dataAttr(isDisabled)
  }, {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "12px",
      padding: "12px 14px",
      borderRadius: "var(--radius-md)",
      background: sel ? "var(--accent-tint)" : hover && pressable ? "var(--ink-600)" : "transparent",
      border: `1px solid ${sel ? "var(--border-glow)" : "transparent"}`,
      cursor: isDisabled ? "not-allowed" : pressable ? "pointer" : "default",
      opacity: isDisabled ? 0.5 : 1,
      transition: "background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out)",
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: name,
    isBordered: true,
    status: status === "active" ? "active" : status === "idle" ? "idle" : "offline"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--fg-1)",
      fontWeight: 600,
      fontSize: "var(--text-base)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--fg-3)",
      fontSize: "var(--text-sm)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, role, runs != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      color: "var(--fg-4)"
    }
  }, " \xB7 ", runs, " runs"))), /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    color: statusColor,
    variant: "dot"
  }, statusLabel), endContent || trailing);
}
Object.assign(__ds_scope, { AgentRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/AgentRow.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Alert (HeroUI-aligned)
 * Inline status message. variant: flat (default) | solid | bordered | faded   color: default | primary | secondary | success | warning | danger
 * title, description, icon, hideIcon, isClosable + onClose, endContent (actions). Renders role="alert".
 */
const ICON = {
  default: /*#__PURE__*/React.createElement("path", {
    d: "M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM8 7v4M8 5h.01"
  }),
  primary: /*#__PURE__*/React.createElement("path", {
    d: "M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM8 7v4M8 5h.01"
  }),
  secondary: /*#__PURE__*/React.createElement("path", {
    d: "M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM8 7v4M8 5h.01"
  }),
  success: /*#__PURE__*/React.createElement("path", {
    d: "M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM5 8.3l2 2 4-4.3"
  }),
  warning: /*#__PURE__*/React.createElement("path", {
    d: "M8 2l6.5 11.5H1.5L8 2zM8 6.5v3M8 11.5h.01"
  }),
  danger: /*#__PURE__*/React.createElement("path", {
    d: "M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM5.7 5.7l4.6 4.6M10.3 5.7l-4.6 4.6"
  })
};
function Alert({
  title,
  description,
  icon,
  hideIcon = false,
  color = "default",
  variant = "flat",
  radius = "md",
  isVisible = true,
  isClosable = false,
  onClose,
  endContent,
  children,
  style = {},
  ...rest
}) {
  const [closed, setClosed] = React.useState(false);
  if (!isVisible || closed) return null;
  const k = __ds_scope.color(color);
  const isDef = color === "default";
  const shells = {
    flat: {
      background: isDef ? "var(--ink-600)" : k.tint,
      border: "1px solid transparent",
      color: "var(--fg-1)"
    },
    faded: {
      background: isDef ? "var(--ink-600)" : k.tint,
      border: `1px solid ${isDef ? "var(--border-default)" : k.border}`,
      color: "var(--fg-1)"
    },
    bordered: {
      background: "transparent",
      border: `1px solid ${isDef ? "var(--border-strong)" : k.border}`,
      color: "var(--fg-1)"
    },
    solid: {
      background: k.solidBg,
      border: "1px solid transparent",
      color: k.solidFg
    }
  };
  const s = shells[variant] || shells.flat;
  const accent = variant === "solid" ? k.solidFg : isDef ? "var(--fg-2)" : k.fg;
  const sub = variant === "solid" ? k.solidFg : "var(--fg-2)";
  const close = e => {
    setClosed(true);
    onClose && onClose(e);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    "data-color": color,
    "data-variant": variant,
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 12,
      padding: "12px 14px",
      boxSizing: "border-box",
      width: "100%",
      borderRadius: __ds_scope.radius(radius),
      fontFamily: "var(--font-body)",
      ...s,
      ...style
    }
  }, rest), !hideIcon && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: "inline-flex",
      flex: "none",
      color: accent,
      marginTop: 1
    }
  }, icon || /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 16 16",
    width: "18",
    height: "18",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, ICON[color] || ICON.default)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      gap: 3
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: 600,
      color: variant === "solid" ? k.solidFg : "var(--fg-1)",
      lineHeight: 1.4
    }
  }, title), (description || children) && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-sm)",
      color: sub,
      opacity: variant === "solid" ? 0.85 : 1,
      lineHeight: 1.5
    }
  }, description, children)), endContent && /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "none",
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, endContent), isClosable && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Close",
    onClick: close,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 28,
      height: 28,
      margin: "-5px -6px -5px 0",
      padding: 0,
      border: "none",
      borderRadius: "var(--radius-sm)",
      background: "transparent",
      color: accent,
      cursor: "pointer",
      opacity: 0.7,
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 16 16",
    width: "14",
    height: "14",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M4 4l8 8M12 4l-8 8"
  }))));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Progress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Progress (HeroUI-aligned)
 * Linear progress bar. value/minValue/maxValue, isIndeterminate, label, showValueLabel, valueLabel, formatOptions.
 * color: primary (gradient) | secondary | success | warning | danger | default   size: sm | md | lg   isStriped
 */
function Progress({
  value = 0,
  minValue = 0,
  maxValue = 100,
  isIndeterminate = false,
  label,
  showValueLabel = false,
  valueLabel,
  formatOptions = {
    style: "percent"
  },
  color = "primary",
  size = "md",
  radius = "full",
  isStriped = false,
  isDisabled = false,
  disableAnimation = false,
  style = {},
  ...rest
}) {
  const pct = Math.min(100, Math.max(0, (value - minValue) / (maxValue - minValue) * 100));
  const k = __ds_scope.color(color);
  const h = {
    sm: 4,
    md: 8,
    lg: 12
  }[size] || 8;
  const fill = color === "primary" ? "var(--grad-cta)" : k.solidBg;
  const txt = valueLabel ?? new Intl.NumberFormat(undefined, formatOptions).format(formatOptions.style === "percent" ? pct / 100 : value);
  const uid = React.useId();
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "progressbar",
    "aria-valuemin": minValue,
    "aria-valuemax": maxValue,
    "aria-valuenow": isIndeterminate ? undefined : value,
    "aria-valuetext": isIndeterminate ? undefined : txt,
    "aria-labelledby": label ? `pg-${uid}` : undefined,
    "aria-label": !label ? rest["aria-label"] : undefined,
    "data-indeterminate": isIndeterminate ? "true" : undefined,
    "data-disabled": isDisabled ? "true" : undefined,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      width: "100%",
      opacity: isDisabled ? 0.5 : 1,
      fontFamily: "var(--font-body)",
      ...style
    }
  }, rest), (label || showValueLabel) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      gap: 12
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    id: `pg-${uid}`,
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--fg-2)",
      fontWeight: 500
    }
  }, label), showValueLabel && !isIndeterminate && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--fg-3)"
    }
  }, txt)), /*#__PURE__*/React.createElement("div", {
    "data-slot": "track",
    style: {
      position: "relative",
      height: h,
      width: "100%",
      overflow: "hidden",
      background: "var(--ink-500)",
      borderRadius: __ds_scope.radius(radius, "full")
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-slot": "indicator",
    style: {
      position: "absolute",
      top: 0,
      bottom: 0,
      left: 0,
      width: isIndeterminate ? "40%" : pct + "%",
      borderRadius: "inherit",
      background: fill,
      boxShadow: color === "primary" ? k.glow : "none",
      ...(isStriped ? {
        backgroundImage: `linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent), ${fill}`,
        backgroundSize: `${h * 2}px ${h * 2}px, auto`
      } : {}),
      transition: disableAnimation || isIndeterminate ? "none" : "width var(--dur-slow) var(--ease-out)",
      animation: isIndeterminate && !disableAnimation ? "ainoia-indeterminate 1.4s var(--ease-in-out) infinite" : "none"
    }
  })));
}
Object.assign(__ds_scope, { Progress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Progress.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Skeleton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Skeleton (HeroUI-aligned)
 * Loading placeholder. Wrap the eventual content and toggle isLoaded; the child keeps its layout box.
 * Standalone: give width/height via style. disableAnimation stops the shimmer.
 */
function Skeleton({
  isLoaded = false,
  disableAnimation = false,
  children,
  style = {},
  ...rest
}) {
  if (isLoaded) return /*#__PURE__*/React.createElement("div", _extends({
    "data-loaded": "true",
    style: style
  }, rest), children);
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-loaded": "false",
    "aria-busy": "true",
    "aria-live": "polite",
    style: {
      position: "relative",
      display: children ? "block" : "inline-block",
      overflow: "hidden",
      borderRadius: "var(--radius-sm)",
      background: "var(--ink-600)",
      minHeight: children ? undefined : 12,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(90deg, transparent 0%, rgba(236,229,216,0.06) 50%, transparent 100%)",
      backgroundSize: "200% 100%",
      animation: disableAnimation ? "none" : "ainoia-skeleton 1.6s linear infinite"
    }
  }), children && /*#__PURE__*/React.createElement("div", {
    style: {
      visibility: "hidden"
    }
  }, children));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Tooltip (HeroUI-aligned)
 * Wraps a single trigger; opens on hover + focus. content, placement: top | bottom | left | right (+ -start/-end),
 * delay / closeDelay, showArrow, color, size, isDisabled, isOpen / defaultOpen / onOpenChange. Escape closes.
 */
function Tooltip({
  content,
  children,
  placement = "top",
  delay = 0,
  closeDelay = 300,
  showArrow = false,
  color = "default",
  size = "md",
  radius = "md",
  isDisabled = false,
  isOpen: isOpenProp,
  defaultOpen = false,
  onOpenChange,
  offset = 7,
  style = {},
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultOpen);
  const open = (isOpenProp ?? inner) && !isDisabled;
  const t = React.useRef();
  const set = o => {
    clearTimeout(t.current);
    t.current = setTimeout(() => {
      if (isOpenProp === undefined) setInner(o);
      onOpenChange && onOpenChange(o);
    }, o ? delay : closeDelay);
  };
  React.useEffect(() => () => clearTimeout(t.current), []);
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => e.key === "Escape" && set(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);
  const uid = React.useId();
  const id = `tt-${uid}`;
  const k = __ds_scope.color(color);
  const isDef = color === "default" || color === "foreground";
  const bg = color === "foreground" ? "var(--fg-1)" : isDef ? "var(--ink-500)" : k.solidBg;
  const fg = color === "foreground" ? "var(--ink-900)" : isDef ? "var(--fg-1)" : k.solidFg;
  const [side, align = "center"] = placement.split("-");
  const pos = {
    top: {
      bottom: `calc(100% + ${offset}px)`
    },
    bottom: {
      top: `calc(100% + ${offset}px)`
    },
    left: {
      right: `calc(100% + ${offset}px)`
    },
    right: {
      left: `calc(100% + ${offset}px)`
    }
  }[side] || {};
  const horiz = side === "top" || side === "bottom";
  const cross = horiz ? align === "start" ? {
    left: 0
  } : align === "end" ? {
    right: 0
  } : {
    left: "50%",
    transform: "translateX(-50%)"
  } : align === "start" ? {
    top: 0
  } : align === "end" ? {
    bottom: 0
  } : {
    top: "50%",
    transform: "translateY(-50%)"
  };
  const fs = {
    sm: "var(--text-xs)",
    md: "var(--text-sm)",
    lg: "var(--text-base)"
  }[size] || "var(--text-sm)";
  const arrow = showArrow && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      width: 8,
      height: 8,
      background: bg,
      transform: "rotate(45deg)",
      ...(side === "top" ? {
        bottom: -4,
        left: "calc(50% - 4px)"
      } : side === "bottom" ? {
        top: -4,
        left: "calc(50% - 4px)"
      } : side === "left" ? {
        right: -4,
        top: "calc(50% - 4px)"
      } : {
        left: -4,
        top: "calc(50% - 4px)"
      })
    }
  });
  const child = React.Children.only(children);
  const trigger = React.cloneElement(child, {
    "aria-describedby": open ? id : child.props["aria-describedby"],
    onMouseEnter: e => {
      set(true);
      child.props.onMouseEnter && child.props.onMouseEnter(e);
    },
    onMouseLeave: e => {
      set(false);
      child.props.onMouseLeave && child.props.onMouseLeave(e);
    },
    onFocus: e => {
      set(true);
      child.props.onFocus && child.props.onFocus(e);
    },
    onBlur: e => {
      set(false);
      child.props.onBlur && child.props.onBlur(e);
    }
  });
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, rest), trigger, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    id: id,
    "data-open": open ? "true" : undefined,
    "data-placement": placement,
    onMouseEnter: () => set(true),
    onMouseLeave: () => set(false),
    style: {
      position: "absolute",
      zIndex: 50,
      ...pos,
      ...cross,
      pointerEvents: open ? "auto" : "none",
      whiteSpace: "nowrap",
      padding: size === "sm" ? "4px 8px" : "6px 10px",
      borderRadius: __ds_scope.radius(radius),
      background: bg,
      color: fg,
      fontFamily: "var(--font-body)",
      fontSize: fs,
      lineHeight: 1.4,
      border: isDef && color !== "foreground" ? "1px solid var(--border-strong)" : "none",
      boxShadow: "var(--shadow-md)",
      opacity: open ? 1 : 0,
      transition: "opacity var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)"
    }
  }, arrow, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Checkbox / CheckboxGroup (HeroUI-aligned)
 * Native <input type="checkbox"> inside a <label>; the visible box is aria-hidden.
 * Controlled: isSelected + onValueChange. Uncontrolled: defaultSelected.
 * Group: value / defaultValue (string[]) + onValueChange(string[]).
 */
const GroupCtx = React.createContext(null);
const DIM = {
  sm: 16,
  md: 20,
  lg: 24
};
const FS = {
  sm: "var(--text-sm)",
  md: "var(--text-base)",
  lg: "var(--text-md)"
};
function Checkbox({
  isSelected,
  defaultSelected = false,
  onValueChange,
  value = "",
  isDisabled,
  isReadOnly = false,
  isRequired = false,
  isInvalid,
  isIndeterminate = false,
  size,
  color,
  radius = "sm",
  lineThrough = false,
  icon,
  name,
  children,
  style = {},
  ...rest
}) {
  const g = React.useContext(GroupCtx);
  size = size || g?.size || "md";
  color = color || g?.color || "primary";
  isDisabled = isDisabled ?? g?.isDisabled ?? false;
  isInvalid = isInvalid ?? g?.isInvalid ?? false;
  const inGroup = !!g;
  const [inner, setInner] = React.useState(defaultSelected);
  const on = inGroup ? g.value.includes(value) : isSelected !== undefined ? isSelected : inner;
  const [hover, setHover] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current) ref.current.indeterminate = isIndeterminate;
  }, [isIndeterminate]);
  const uid = React.useId();
  const k = __ds_scope.color(isInvalid ? "danger" : color);
  const d = DIM[size] || DIM.md;
  const fill = on || isIndeterminate;
  const handle = e => {
    if (isDisabled || isReadOnly) {
      e.preventDefault();
      return;
    }
    const next = e.target.checked;
    if (inGroup) g.toggle(value, next);else {
      if (isSelected === undefined) setInner(next);
      onValueChange && onValueChange(next);
    }
  };
  const bg = fill ? color === "primary" && !isInvalid ? "var(--grad-cta)" : k.solidBg : hover && !isDisabled ? "var(--ink-500)" : "transparent";
  const mark = isIndeterminate ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: d * 0.5,
      height: 2,
      background: k.solidFg,
      borderRadius: 1
    }
  }) : /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 16 16",
    width: d * 0.65,
    height: d * 0.65,
    fill: "none",
    stroke: k.solidFg,
    strokeWidth: "2.2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      transform: on ? "scale(1)" : "scale(0.6)",
      opacity: on ? 1 : 0,
      transition: "transform var(--dur-fast) var(--ease-spark), opacity var(--dur-fast)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 8.5l3.2 3L13 4.5"
  }));
  return /*#__PURE__*/React.createElement("label", _extends({
    "data-selected": __ds_scope.dataAttr(fill),
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    "data-invalid": __ds_scope.dataAttr(isInvalid),
    "data-hover": __ds_scope.dataAttr(hover),
    "data-focus-visible": __ds_scope.dataAttr(focusVisible),
    "data-indeterminate": __ds_scope.dataAttr(isIndeterminate),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      minHeight: 44,
      cursor: isDisabled ? "not-allowed" : "pointer",
      opacity: isDisabled ? 0.5 : 1,
      fontFamily: "var(--font-body)",
      WebkitTapHighlightColor: "transparent",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    ref: ref,
    type: "checkbox",
    name: name || g?.name,
    value: value,
    checked: on,
    disabled: isDisabled,
    required: isRequired,
    "aria-invalid": isInvalid || undefined,
    "aria-readonly": isReadOnly || undefined,
    "aria-labelledby": children ? `cb-${uid}` : undefined,
    "aria-label": !children ? rest["aria-label"] : undefined,
    onChange: handle,
    onFocus: e => {
      try {
        setFocusVisible(e.target.matches(":focus-visible"));
      } catch (_) {
        setFocusVisible(true);
      }
    },
    onBlur: () => setFocusVisible(false),
    style: {
      position: "absolute",
      width: 44,
      height: 44,
      opacity: 0,
      margin: 0,
      cursor: "inherit",
      left: d / 2 - 22,
      top: "50%",
      transform: "translateY(-50%)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: d,
      height: d,
      flex: "none",
      boxSizing: "border-box",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: __ds_scope.radius(radius, "sm"),
      background: bg,
      border: `1.5px solid ${fill ? "transparent" : isInvalid ? "var(--danger)" : hover ? "var(--border-strong)" : "var(--border-default)"}`,
      boxShadow: fill && color === "primary" && !isInvalid ? k.glow : "none",
      outline: focusVisible ? "2px solid var(--focus-ring)" : "none",
      outlineOffset: 2,
      transition: "background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)"
    }
  }, icon ? typeof icon === "function" ? icon({
    isSelected: on,
    isIndeterminate
  }) : on ? icon : null : mark), children && /*#__PURE__*/React.createElement("span", {
    id: `cb-${uid}`,
    style: {
      fontSize: FS[size] || FS.md,
      color: isInvalid ? "var(--danger)" : "var(--fg-2)",
      textDecoration: lineThrough && on ? "line-through" : "none",
      opacity: lineThrough && on ? 0.6 : 1,
      transition: "opacity var(--dur-base)"
    }
  }, children));
}
function CheckboxGroup({
  label,
  description,
  errorMessage,
  value,
  defaultValue = [],
  onValueChange,
  orientation = "vertical",
  size = "md",
  color = "primary",
  isDisabled = false,
  isInvalid = false,
  isRequired = false,
  name,
  children,
  style = {},
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultValue);
  const val = value !== undefined ? value : inner;
  const toggle = (v, next) => {
    const set = next ? [...new Set([...val, v])] : val.filter(x => x !== v);
    if (value === undefined) setInner(set);
    onValueChange && onValueChange(set);
  };
  const uid = React.useId();
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "group",
    "aria-labelledby": label ? `cbg-${uid}` : undefined,
    "aria-describedby": description ? `cbg-${uid}-d` : undefined,
    "aria-invalid": isInvalid || undefined,
    "aria-required": isRequired || undefined,
    "data-orientation": orientation,
    "data-invalid": __ds_scope.dataAttr(isInvalid),
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      fontFamily: "var(--font-body)",
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("span", {
    id: `cbg-${uid}`,
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: 500,
      color: isInvalid ? "var(--danger)" : "var(--fg-2)"
    }
  }, label, isRequired && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--danger)",
      marginLeft: 3
    }
  }, "*")), /*#__PURE__*/React.createElement(GroupCtx.Provider, {
    value: {
      value: val,
      toggle,
      size,
      color,
      isDisabled,
      isInvalid,
      name
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: orientation === "horizontal" ? "row" : "column",
      flexWrap: "wrap",
      gap: orientation === "horizontal" ? "4px 20px" : 0
    }
  }, children)), description && !isInvalid && /*#__PURE__*/React.createElement("span", {
    id: `cbg-${uid}-d`,
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--fg-3)"
    }
  }, description), isInvalid && errorMessage && /*#__PURE__*/React.createElement("span", {
    role: "alert",
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--danger)"
    }
  }, errorMessage));
}
Object.assign(__ds_scope, { Checkbox, CheckboxGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Input (HeroUI-aligned)
 * variant: faded (default) | flat | bordered | underlined    labelPlacement: outside | outside-left
 * Controlled via value/onValueChange or native onChange; uncontrolled via defaultValue.
 * Legacy: hint → description, error → errorMessage (+ isInvalid), iconLeft → startContent.
 */
function Input({
  label,
  description,
  errorMessage,
  placeholder,
  variant = "faded",
  color = "default",
  size = "md",
  radius = "md",
  labelPlacement = "outside",
  fullWidth = true,
  isInvalid = false,
  isDisabled = false,
  isRequired = false,
  isReadOnly = false,
  isClearable = false,
  startContent = null,
  endContent = null,
  value,
  defaultValue,
  onValueChange,
  onClear,
  onChange,
  hint,
  error,
  iconLeft,
  disabled,
  readOnly,
  required,
  style = {},
  id,
  className,
  ...rest
}) {
  description = description ?? hint;
  errorMessage = errorMessage ?? error;
  startContent = startContent || iconLeft;
  const invalid = isInvalid || !!errorMessage;
  const off = isDisabled || disabled;
  const ro = isReadOnly || readOnly;
  const req = isRequired || required;
  const [focus, setFocus] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const [inner, setInner] = React.useState(defaultValue ?? "");
  const controlled = value !== undefined;
  const val = controlled ? value : inner;
  const ref = React.useRef(null);
  const uid = React.useId();
  const inputId = id || `in-${uid}`;
  const descId = description ? `${inputId}-desc` : undefined;
  const errId = invalid && errorMessage ? `${inputId}-err` : undefined;
  const describedBy = [descId, errId].filter(Boolean).join(" ") || undefined;
  const set = v => {
    if (!controlled) setInner(v);
    onValueChange && onValueChange(v);
  };
  const clear = () => {
    set("");
    onClear && onClear();
    ref.current && ref.current.focus();
  };
  const accent = invalid ? "var(--danger)" : "var(--cyan)";
  const border = invalid ? "var(--danger)" : focus ? "var(--cyan)" : hover ? "var(--border-strong)" : "var(--border-default)";
  const shells = {
    faded: {
      background: "var(--ink-800)",
      border: `1px solid ${border}`,
      borderRadius: __ds_scope.radius(radius)
    },
    flat: {
      background: hover || focus ? "var(--ink-500)" : "var(--ink-600)",
      border: `1px solid ${invalid ? "var(--danger)" : "transparent"}`,
      borderRadius: __ds_scope.radius(radius)
    },
    bordered: {
      background: "transparent",
      border: `1px solid ${border}`,
      borderRadius: __ds_scope.radius(radius)
    },
    underlined: {
      background: "transparent",
      border: "none",
      borderBottom: `1px solid ${border}`,
      borderRadius: 0
    }
  };
  const shell = shells[variant] || shells.faded;
  const side = labelPlacement === "outside-left";
  const labelEl = label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: "var(--text-sm)",
      color: invalid ? "var(--danger)" : "var(--fg-2)",
      fontWeight: 500,
      whiteSpace: side ? "nowrap" : undefined
    }
  }, label, req && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--danger)",
      marginLeft: 3
    }
  }, "*"));
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    "data-slot": "base",
    "data-focus": __ds_scope.dataAttr(focus),
    "data-hover": __ds_scope.dataAttr(hover),
    "data-invalid": __ds_scope.dataAttr(invalid),
    "data-disabled": __ds_scope.dataAttr(off),
    "data-readonly": __ds_scope.dataAttr(ro),
    "data-required": __ds_scope.dataAttr(req),
    "data-filled": __ds_scope.dataAttr(!!val),
    style: {
      display: "flex",
      flexDirection: side ? "row" : "column",
      alignItems: side ? "center" : "stretch",
      gap: side ? "12px" : "7px",
      width: fullWidth ? "100%" : "auto",
      opacity: off ? 0.5 : 1,
      ...style
    }
  }, labelEl, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-slot": "input-wrapper",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: e => {
      if (e.target === e.currentTarget && ref.current) ref.current.focus();
    },
    style: {
      display: "flex",
      alignItems: "center",
      gap: "9px",
      boxSizing: "border-box",
      height: __ds_scope.controlH[size] || __ds_scope.controlH.md,
      padding: variant === "underlined" ? "0 2px" : "0 13px",
      boxShadow: focus && !invalid && variant !== "underlined" ? "var(--glow-cyan-sm)" : "none",
      cursor: off ? "not-allowed" : "text",
      transition: "border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)",
      ...shell
    }
  }, startContent && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: focus ? accent : "var(--fg-3)",
      display: "inline-flex",
      flex: "none"
    }
  }, startContent), /*#__PURE__*/React.createElement("input", _extends({}, rest, {
    ref: ref,
    id: inputId,
    value: val,
    placeholder: placeholder,
    disabled: off,
    readOnly: ro,
    required: req,
    "aria-invalid": invalid || undefined,
    "aria-required": req || undefined,
    "aria-describedby": describedBy,
    onChange: e => {
      set(e.target.value);
      onChange && onChange(e);
    },
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    },
    onKeyDown: e => {
      if (e.key === "Escape" && isClearable && val && !ro) clear();
      rest.onKeyDown && rest.onKeyDown(e);
    },
    style: {
      flex: 1,
      minWidth: 0,
      background: "transparent",
      border: "none",
      outline: "none",
      padding: 0,
      color: "var(--fg-1)",
      fontFamily: "var(--font-body)",
      fontSize: size === "sm" ? "var(--text-sm)" : "var(--text-base)",
      cursor: off ? "not-allowed" : "text"
    }
  })), isClearable && val && !off && !ro && /*#__PURE__*/React.createElement("button", {
    type: "button",
    tabIndex: -1,
    "aria-label": "clear input",
    onClick: clear,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 18,
      height: 18,
      padding: 0,
      border: "none",
      borderRadius: "50%",
      background: "var(--ink-500)",
      color: "var(--fg-2)",
      cursor: "pointer",
      fontSize: 13,
      lineHeight: 1,
      flex: "none"
    }
  }, "\xD7"), endContent && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-3)",
      display: "inline-flex",
      flex: "none"
    }
  }, endContent)), (description || invalid && errorMessage) && /*#__PURE__*/React.createElement("div", {
    "data-slot": "helper-wrapper",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, description && /*#__PURE__*/React.createElement("span", {
    id: descId,
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--fg-3)"
    }
  }, description), invalid && errorMessage && /*#__PURE__*/React.createElement("span", {
    id: errId,
    role: "alert",
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--danger)"
    }
  }, errorMessage))));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — RadioGroup / Radio (HeroUI-aligned)
 * Radios must live inside a RadioGroup. Controlled: value + onValueChange; uncontrolled: defaultValue.
 * Native <input type="radio"> handles roving focus and arrow keys.
 */
const Ctx = React.createContext(null);
const DIM = {
  sm: 16,
  md: 20,
  lg: 24
};
const FS = {
  sm: "var(--text-sm)",
  md: "var(--text-base)",
  lg: "var(--text-md)"
};
function RadioGroup({
  label,
  description,
  errorMessage,
  value,
  defaultValue,
  onValueChange,
  name,
  orientation = "vertical",
  size = "md",
  color = "primary",
  isDisabled = false,
  isInvalid = false,
  isRequired = false,
  isReadOnly = false,
  children,
  style = {},
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultValue ?? null);
  const val = value !== undefined ? value : inner;
  const uid = React.useId();
  const select = v => {
    if (isReadOnly) return;
    if (value === undefined) setInner(v);
    onValueChange && onValueChange(v);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "radiogroup",
    "aria-labelledby": label ? `rg-${uid}` : undefined,
    "aria-describedby": description ? `rg-${uid}-d` : undefined,
    "aria-invalid": isInvalid || undefined,
    "aria-required": isRequired || undefined,
    "aria-orientation": orientation,
    "data-orientation": orientation,
    "data-invalid": __ds_scope.dataAttr(isInvalid),
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      fontFamily: "var(--font-body)",
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("span", {
    id: `rg-${uid}`,
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: 500,
      color: isInvalid ? "var(--danger)" : "var(--fg-2)"
    }
  }, label, isRequired && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--danger)",
      marginLeft: 3
    }
  }, "*")), /*#__PURE__*/React.createElement(Ctx.Provider, {
    value: {
      val,
      select,
      name: name || `rg-${uid}`,
      size,
      color,
      isDisabled,
      isInvalid,
      isReadOnly
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: orientation === "horizontal" ? "row" : "column",
      flexWrap: "wrap",
      gap: orientation === "horizontal" ? "4px 20px" : 0
    }
  }, children)), description && !isInvalid && /*#__PURE__*/React.createElement("span", {
    id: `rg-${uid}-d`,
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--fg-3)"
    }
  }, description), isInvalid && errorMessage && /*#__PURE__*/React.createElement("span", {
    role: "alert",
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--danger)"
    }
  }, errorMessage));
}
function Radio({
  value,
  description,
  isDisabled,
  size,
  color,
  children,
  style = {},
  ...rest
}) {
  const g = React.useContext(Ctx) || {
    val: null,
    select: () => {},
    name: undefined
  };
  size = size || g.size || "md";
  color = color || g.color || "primary";
  const off = isDisabled ?? g.isDisabled ?? false;
  const invalid = g.isInvalid;
  const on = g.val === value;
  const [hover, setHover] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const uid = React.useId();
  const k = __ds_scope.color(invalid ? "danger" : color);
  const d = DIM[size] || DIM.md;
  const ring = on ? invalid ? "var(--danger)" : k.dot : invalid ? "var(--danger)" : hover ? "var(--border-strong)" : "var(--border-default)";
  return /*#__PURE__*/React.createElement("label", _extends({
    "data-selected": __ds_scope.dataAttr(on),
    "data-disabled": __ds_scope.dataAttr(off),
    "data-invalid": __ds_scope.dataAttr(invalid),
    "data-hover": __ds_scope.dataAttr(hover),
    "data-focus-visible": __ds_scope.dataAttr(focusVisible),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: description ? "flex-start" : "center",
      gap: "10px",
      minHeight: 44,
      padding: description ? "8px 0" : 0,
      cursor: off ? "not-allowed" : "pointer",
      opacity: off ? 0.5 : 1,
      fontFamily: "var(--font-body)",
      WebkitTapHighlightColor: "transparent",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: g.name,
    value: value,
    checked: on,
    disabled: off,
    "aria-invalid": invalid || undefined,
    "aria-labelledby": children ? `r-${uid}` : undefined,
    "aria-describedby": description ? `r-${uid}-d` : undefined,
    onChange: () => !off && g.select(value),
    onFocus: e => {
      try {
        setFocusVisible(e.target.matches(":focus-visible"));
      } catch (_) {
        setFocusVisible(true);
      }
    },
    onBlur: () => setFocusVisible(false),
    style: {
      position: "absolute",
      width: 44,
      height: 44,
      opacity: 0,
      margin: 0,
      cursor: "inherit",
      left: d / 2 - 22,
      top: description ? 0 : "50%",
      transform: description ? "none" : "translateY(-50%)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: d,
      height: d,
      flex: "none",
      boxSizing: "border-box",
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginTop: description ? 2 : 0,
      border: `1.5px solid ${ring}`,
      background: hover && !on && !off ? "var(--ink-500)" : "transparent",
      boxShadow: on && color === "primary" && !invalid ? k.glow : "none",
      outline: focusVisible ? "2px solid var(--focus-ring)" : "none",
      outlineOffset: 2,
      transition: "border-color var(--dur-fast) var(--ease-out), background var(--dur-fast)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: d * 0.45,
      height: d * 0.45,
      borderRadius: "50%",
      background: invalid ? "var(--danger)" : color === "primary" ? "var(--grad-cta)" : k.dot,
      transform: on ? "scale(1)" : "scale(0)",
      transition: "transform var(--dur-fast) var(--ease-spark)"
    }
  })), (children || description) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, children && /*#__PURE__*/React.createElement("span", {
    id: `r-${uid}`,
    style: {
      fontSize: FS[size] || FS.md,
      color: invalid ? "var(--danger)" : "var(--fg-2)"
    }
  }, children), description && /*#__PURE__*/React.createElement("span", {
    id: `r-${uid}-d`,
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--fg-3)"
    }
  }, description)));
}
Object.assign(__ds_scope, { RadioGroup, Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Select / SelectItem (HeroUI-aligned)
 * Custom trigger + listbox popover. Single or multiple selection.
 * items: [{ key, label, description?, startContent?, isDisabled? }] or <SelectItem key=… > children.
 * selectedKeys / defaultSelectedKeys (Set|array) + onSelectionChange(Set). Keyboard: ↑↓ Home End Enter Space Esc, type-ahead.
 */
function SelectItem() {
  return null;
}
SelectItem.__ainoiaSelectItem = true;
function Select({
  label,
  description,
  errorMessage,
  placeholder = "Select an option",
  items,
  children,
  selectedKeys,
  defaultSelectedKeys = [],
  onSelectionChange,
  selectionMode = "single",
  disallowEmptySelection = false,
  variant = "faded",
  size = "md",
  radius = "md",
  labelPlacement = "outside",
  fullWidth = true,
  isInvalid = false,
  isDisabled = false,
  isRequired = false,
  isLoading = false,
  isClearable = false,
  disabledKeys = [],
  startContent,
  endContent,
  selectorIcon,
  renderValue,
  onClear,
  name,
  isOpen: isOpenProp,
  defaultOpen = false,
  onOpenChange,
  style = {},
  className,
  ...rest
}) {
  const list = items || React.Children.toArray(children).filter(c => c && c.type && c.type.__ainoiaSelectItem).map(c => {
    const {
      children: lbl,
      value,
      ...p
    } = c.props;
    return {
      ...p,
      key: c.key != null ? String(c.key).replace(/^\.\$/, "") : value,
      label: lbl
    };
  });
  const toSet = v => new Set(v instanceof Set ? v : Array.isArray(v) ? v : v == null ? [] : [v]);
  const [inner, setInner] = React.useState(() => toSet(defaultSelectedKeys));
  const sel = selectedKeys !== undefined ? toSet(selectedKeys) : inner;
  const [openInner, setOpenInner] = React.useState(defaultOpen);
  const open = isOpenProp ?? openInner;
  const setOpen = o => {
    if (isDisabled) return;
    if (isOpenProp === undefined) setOpenInner(o);
    onOpenChange && onOpenChange(o);
  };
  const [hover, setHover] = React.useState(false);
  const [focusVisible, setFocusVisible] = React.useState(false);
  const [active, setActive] = React.useState(-1);
  const uid = React.useId();
  const base = `sel-${uid}`;
  const rootRef = React.useRef(null),
    listRef = React.useRef(null),
    trigRef = React.useRef(null);
  const disabled = new Set(disabledKeys);
  const enabled = list.filter(it => !it.isDisabled && !disabled.has(it.key));
  const invalid = isInvalid;
  const commit = s => {
    if (selectedKeys === undefined) setInner(s);
    onSelectionChange && onSelectionChange(s);
  };
  const pick = key => {
    const s = new Set(sel);
    if (selectionMode === "multiple") {
      if (s.has(key)) {
        if (!(disallowEmptySelection && s.size === 1)) s.delete(key);
      } else s.add(key);
      commit(s);
    } else {
      if (s.has(key) && !disallowEmptySelection) commit(new Set());else commit(new Set([key]));
      setOpen(false);
      trigRef.current && trigRef.current.focus();
    }
  };
  const clear = () => {
    commit(new Set());
    onClear && onClear();
    trigRef.current && trigRef.current.focus();
  };
  React.useEffect(() => {
    if (!open) return;
    const onDoc = e => {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);
  React.useEffect(() => {
    if (!open) return;
    const first = enabled.findIndex(it => sel.has(it.key));
    setActive(first >= 0 ? first : 0);
    requestAnimationFrame(() => listRef.current && listRef.current.focus());
  }, [open]);
  const typeRef = React.useRef({
    s: "",
    t: 0
  });
  const onListKey = e => {
    const n = enabled.length;
    if (!n) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive(a => (a + 1) % n);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive(a => (a - 1 + n) % n);
    } else if (e.key === "Home") {
      e.preventDefault();
      setActive(0);
    } else if (e.key === "End") {
      e.preventDefault();
      setActive(n - 1);
    } else if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      enabled[active] && pick(enabled[active].key);
    } else if (e.key === "Escape" || e.key === "Tab") {
      setOpen(false);
      trigRef.current && trigRef.current.focus();
      if (e.key === "Escape") e.preventDefault();
    } else if (e.key.length === 1) {
      const now = Date.now();
      const t = typeRef.current;
      t.s = now - t.t < 600 ? t.s + e.key : e.key;
      t.t = now;
      const i = enabled.findIndex(it => String(it.label).toLowerCase().startsWith(t.s.toLowerCase()));
      if (i >= 0) setActive(i);
    }
  };
  const onTrigKey = e => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp" || e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      setOpen(true);
    }
  };
  const chosen = list.filter(it => sel.has(it.key));
  const valueNode = renderValue ? renderValue(chosen) : chosen.length ? chosen.map((it, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: it.key
  }, i > 0 && ", ", it.label)) : null;
  const border = invalid ? "var(--danger)" : open || focusVisible ? "var(--cyan)" : hover ? "var(--border-strong)" : "var(--border-default)";
  const shells = {
    faded: {
      background: "var(--ink-800)",
      border: `1px solid ${border}`,
      borderRadius: __ds_scope.radius(radius)
    },
    flat: {
      background: hover || open ? "var(--ink-500)" : "var(--ink-600)",
      border: `1px solid ${invalid ? "var(--danger)" : "transparent"}`,
      borderRadius: __ds_scope.radius(radius)
    },
    bordered: {
      background: "transparent",
      border: `1px solid ${border}`,
      borderRadius: __ds_scope.radius(radius)
    },
    underlined: {
      background: "transparent",
      border: "none",
      borderBottom: `1px solid ${border}`,
      borderRadius: 0
    }
  };
  const side = labelPlacement === "outside-left";
  const descId = description ? `${base}-desc` : undefined,
    errId = invalid && errorMessage ? `${base}-err` : undefined;
  const chevron = selectorIcon || /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 16 16",
    width: "14",
    height: "14",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M4 6l4 4 4-4"
  }));
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: rootRef,
    className: className,
    "data-slot": "base",
    "data-open": __ds_scope.dataAttr(open),
    "data-invalid": __ds_scope.dataAttr(invalid),
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    "data-has-value": __ds_scope.dataAttr(chosen.length > 0),
    style: {
      position: "relative",
      display: "flex",
      flexDirection: side ? "row" : "column",
      alignItems: side ? "center" : "stretch",
      gap: side ? 12 : 7,
      width: fullWidth ? "100%" : "auto",
      opacity: isDisabled ? 0.5 : 1,
      fontFamily: "var(--font-body)",
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("span", {
    id: `${base}-label`,
    style: {
      fontSize: "var(--text-sm)",
      color: invalid ? "var(--danger)" : "var(--fg-2)",
      fontWeight: 500,
      whiteSpace: side ? "nowrap" : undefined
    }
  }, label, isRequired && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--danger)",
      marginLeft: 3
    }
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: 6,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("button", {
    ref: trigRef,
    type: "button",
    "data-slot": "trigger",
    role: "combobox",
    "aria-haspopup": "listbox",
    "aria-expanded": open,
    "aria-controls": open ? `${base}-list` : undefined,
    "aria-labelledby": label ? `${base}-label ${base}-value` : undefined,
    "aria-label": !label ? placeholder : undefined,
    "aria-invalid": invalid || undefined,
    "aria-required": isRequired || undefined,
    "aria-describedby": [descId, errId].filter(Boolean).join(" ") || undefined,
    disabled: isDisabled,
    "data-hover": __ds_scope.dataAttr(hover),
    "data-focus-visible": __ds_scope.dataAttr(focusVisible),
    "data-open": __ds_scope.dataAttr(open),
    onClick: () => setOpen(!open),
    onKeyDown: onTrigKey,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onFocus: e => {
      try {
        setFocusVisible(e.target.matches(":focus-visible"));
      } catch (_) {
        setFocusVisible(true);
      }
    },
    onBlur: () => setFocusVisible(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      boxSizing: "border-box",
      width: "100%",
      height: __ds_scope.controlH[size] || __ds_scope.controlH.md,
      padding: variant === "underlined" ? "0 2px" : "0 13px",
      textAlign: "left",
      cursor: isDisabled ? "not-allowed" : "pointer",
      color: "var(--fg-1)",
      fontFamily: "inherit",
      fontSize: size === "sm" ? "var(--text-sm)" : "var(--text-base)",
      boxShadow: (open || focusVisible) && !invalid && variant !== "underlined" ? "var(--glow-cyan-sm)" : "none",
      transition: "border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)",
      ...(shells[variant] || shells.faded)
    }
  }, startContent && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--fg-3)",
      display: "inline-flex",
      flex: "none"
    }
  }, startContent), /*#__PURE__*/React.createElement("span", {
    id: `${base}-value`,
    "data-slot": "value",
    style: {
      flex: 1,
      minWidth: 0,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      color: chosen.length ? "var(--fg-1)" : "var(--fg-4)"
    }
  }, valueNode ?? placeholder), isClearable && chosen.length > 0 && !isDisabled && /*#__PURE__*/React.createElement("span", {
    role: "button",
    tabIndex: -1,
    "aria-label": "clear selection",
    onClick: e => {
      e.stopPropagation();
      clear();
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 18,
      height: 18,
      borderRadius: "50%",
      background: "var(--ink-500)",
      color: "var(--fg-2)",
      fontSize: 13,
      lineHeight: 1,
      flex: "none"
    }
  }, "\xD7"), endContent, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    "data-slot": "selectorIcon",
    style: {
      display: "inline-flex",
      flex: "none",
      color: "var(--fg-3)",
      transform: open ? "rotate(180deg)" : "none",
      transition: "transform var(--dur-base) var(--ease-out)"
    }
  }, isLoading ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      borderRadius: "50%",
      border: "2px solid",
      borderColor: "currentColor transparent currentColor transparent",
      animation: "ainoia-spin 0.8s linear infinite"
    }
  }) : chevron)), open && /*#__PURE__*/React.createElement("ul", {
    ref: listRef,
    id: `${base}-list`,
    role: "listbox",
    tabIndex: -1,
    "aria-multiselectable": selectionMode === "multiple" || undefined,
    "aria-labelledby": label ? `${base}-label` : undefined,
    "aria-activedescendant": enabled[active] ? `${base}-opt-${enabled[active].key}` : undefined,
    onKeyDown: onListKey,
    "data-slot": "listbox",
    style: {
      position: "absolute",
      top: "calc(100% + 5px)",
      left: 0,
      right: 0,
      zIndex: 40,
      margin: 0,
      padding: 6,
      listStyle: "none",
      maxHeight: 256,
      overflowY: "auto",
      boxSizing: "border-box",
      outline: "none",
      background: "var(--ink-700)",
      border: "1px solid var(--border-strong)",
      borderRadius: __ds_scope.radius(radius === "none" ? "none" : "lg"),
      boxShadow: "var(--shadow-lg)",
      backdropFilter: "var(--blur-subtle)"
    }
  }, list.length === 0 && /*#__PURE__*/React.createElement("li", {
    style: {
      padding: "10px 12px",
      fontSize: "var(--text-sm)",
      color: "var(--fg-4)"
    }
  }, "No items."), list.map(it => {
    const off = it.isDisabled || disabled.has(it.key);
    const isSel = sel.has(it.key);
    const idx = enabled.indexOf(it);
    const isAct = idx === active;
    return /*#__PURE__*/React.createElement("li", {
      key: it.key,
      id: `${base}-opt-${it.key}`,
      role: "option",
      "aria-selected": isSel,
      "aria-disabled": off || undefined,
      "data-selected": __ds_scope.dataAttr(isSel),
      "data-hover": __ds_scope.dataAttr(isAct),
      "data-disabled": __ds_scope.dataAttr(off),
      onMouseMove: () => !off && idx !== active && setActive(idx),
      onClick: () => !off && pick(it.key),
      style: {
        display: "flex",
        alignItems: "center",
        gap: 9,
        padding: "8px 10px",
        minHeight: 36,
        boxSizing: "border-box",
        borderRadius: "var(--radius-sm)",
        cursor: off ? "not-allowed" : "pointer",
        opacity: off ? 0.4 : 1,
        background: isAct && !off ? "var(--ink-500)" : "transparent",
        color: isSel ? "var(--fg-1)" : "var(--fg-2)",
        fontSize: "var(--text-sm)",
        transition: "background var(--dur-fast)"
      }
    }, it.startContent && /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        display: "inline-flex",
        flex: "none",
        color: "var(--fg-3)"
      }
    }, it.startContent), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        gap: 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      "data-label": "true",
      style: {
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        fontWeight: isSel ? 600 : 400
      }
    }, it.label), it.description && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "var(--text-xs)",
        color: "var(--fg-3)"
      }
    }, it.description)), /*#__PURE__*/React.createElement("svg", {
      "aria-hidden": "true",
      viewBox: "0 0 16 16",
      width: "14",
      height: "14",
      fill: "none",
      stroke: "var(--cyan)",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: {
        flex: "none",
        opacity: isSel ? 1 : 0
      }
    }, /*#__PURE__*/React.createElement("path", {
      d: "M3 8.5l3.2 3L13 4.5"
    })));
  })), name && /*#__PURE__*/React.createElement("select", {
    name: name,
    multiple: selectionMode === "multiple",
    value: selectionMode === "multiple" ? [...sel] : [...sel][0] ?? "",
    onChange: () => {},
    tabIndex: -1,
    "aria-hidden": "true",
    style: {
      position: "absolute",
      width: 1,
      height: 1,
      opacity: 0,
      pointerEvents: "none"
    }
  }, [...sel].map(k => /*#__PURE__*/React.createElement("option", {
    key: k,
    value: k
  }, k)), /*#__PURE__*/React.createElement("option", {
    value: ""
  })), (description || invalid && errorMessage) && /*#__PURE__*/React.createElement("div", {
    "data-slot": "helper-wrapper",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, description && /*#__PURE__*/React.createElement("span", {
    id: descId,
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--fg-3)"
    }
  }, description), invalid && errorMessage && /*#__PURE__*/React.createElement("span", {
    id: errId,
    role: "alert",
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--danger)"
    }
  }, errorMessage))));
}
Object.assign(__ds_scope, { SelectItem, Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Switch (HeroUI-aligned)
 * Hidden native checkbox (role="switch") inside a label; the visible track is aria-hidden.
 * Controlled: isSelected + onValueChange. Uncontrolled: defaultSelected. Legacy: checked/onChange/label.
 * size: sm | md | lg   color: primary (gradient) | secondary | success | warning | danger | default
 */
function Switch({
  isSelected,
  defaultSelected = false,
  onValueChange,
  onChange,
  isDisabled = false,
  isReadOnly = false,
  size = "md",
  color = "primary",
  thumbIcon,
  startContent,
  endContent,
  name,
  value = "on",
  checked,
  disabled,
  label,
  children,
  style = {},
  ...rest
}) {
  const controlled = (isSelected ?? checked) !== undefined;
  const [inner, setInner] = React.useState(defaultSelected);
  const on = controlled ? !!(isSelected ?? checked) : inner;
  const off = isDisabled || disabled;
  const [focusVisible, setFocusVisible] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const k = __ds_scope.color(color);
  const dims = {
    sm: {
      w: 32,
      h: 18,
      t: 12
    },
    md: {
      w: 40,
      h: 22,
      t: 16
    },
    lg: {
      w: 48,
      h: 26,
      t: 20
    }
  }[size] || {
    w: 40,
    h: 22,
    t: 16
  };
  const uid = React.useId();
  const labelId = `sw-${uid}-label`;
  const lbl = children ?? label;
  const handle = e => {
    if (off || isReadOnly) {
      e.preventDefault();
      return;
    }
    const next = e.target.checked;
    if (!controlled) setInner(next);
    onValueChange && onValueChange(next);
    onChange && onChange(next);
  };
  const onBg = color === "primary" ? "var(--grad-cta)" : k.solidBg;
  return /*#__PURE__*/React.createElement("label", _extends({
    "data-selected": __ds_scope.dataAttr(on),
    "data-disabled": __ds_scope.dataAttr(off),
    "data-readonly": __ds_scope.dataAttr(isReadOnly),
    "data-hover": __ds_scope.dataAttr(hover),
    "data-focus-visible": __ds_scope.dataAttr(focusVisible),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      minHeight: "44px",
      cursor: off ? "not-allowed" : "pointer",
      opacity: off ? 0.5 : 1,
      WebkitTapHighlightColor: "transparent",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    role: "switch",
    name: name,
    value: value,
    checked: on,
    disabled: off,
    "aria-readonly": isReadOnly || undefined,
    "aria-checked": on,
    "aria-labelledby": lbl ? labelId : undefined,
    "aria-label": !lbl ? rest["aria-label"] : undefined,
    onChange: handle,
    onFocus: e => {
      try {
        setFocusVisible(e.target.matches(":focus-visible"));
      } catch (_) {
        setFocusVisible(true);
      }
    },
    onBlur: () => setFocusVisible(false),
    style: {
      position: "absolute",
      width: 44,
      height: 44,
      opacity: 0,
      margin: 0,
      cursor: "inherit",
      left: dims.w / 2 - 22,
      top: "50%",
      transform: "translateY(-50%)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "relative",
      width: dims.w,
      height: dims.h,
      flex: "none",
      boxSizing: "border-box",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 5px",
      borderRadius: "var(--radius-pill)",
      background: on ? onBg : hover && !off ? "var(--ink-400)" : "var(--ink-500)",
      border: `1px solid ${on ? k.border : "var(--border-default)"}`,
      boxShadow: on ? k.glow : "none",
      outline: focusVisible ? "2px solid var(--focus-ring)" : "none",
      outlineOffset: 2,
      transition: "background var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      fontSize: dims.t * 0.7,
      color: k.solidFg,
      opacity: on ? 1 : 0,
      transition: "opacity var(--dur-base)"
    }
  }, startContent), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      fontSize: dims.t * 0.7,
      color: "var(--fg-2)",
      opacity: on ? 0 : 1,
      transition: "opacity var(--dur-base)"
    }
  }, endContent), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: on ? dims.w - dims.t - 4 : 2,
      width: dims.t,
      height: dims.t,
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: dims.t * 0.65,
      background: on ? k.solidFg : "var(--fg-2)",
      color: on ? onBg : "var(--ink-800)",
      transition: "left var(--dur-base) var(--ease-spark)"
    }
  }, typeof thumbIcon === "function" ? thumbIcon({
    isSelected: on,
    width: "1em",
    height: "1em"
  }) : thumbIcon)), lbl && /*#__PURE__*/React.createElement("span", {
    id: labelId,
    style: {
      fontSize: "var(--text-base)",
      color: "var(--fg-2)"
    }
  }, lbl));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Textarea (HeroUI-aligned)
 * Multi-line Input. Same shell variants (faded | flat | bordered | underlined), auto-grows between minRows and maxRows.
 */
function Textarea({
  label,
  description,
  errorMessage,
  placeholder,
  variant = "faded",
  size = "md",
  radius = "md",
  labelPlacement = "outside",
  fullWidth = true,
  isInvalid = false,
  isDisabled = false,
  isRequired = false,
  isReadOnly = false,
  isClearable = false,
  minRows = 3,
  maxRows = 8,
  disableAutosize = false,
  startContent,
  endContent,
  value,
  defaultValue,
  onValueChange,
  onClear,
  onChange,
  style = {},
  id,
  className,
  ...rest
}) {
  const invalid = isInvalid || !!errorMessage && isInvalid;
  const [focus, setFocus] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const [inner, setInner] = React.useState(defaultValue ?? "");
  const controlled = value !== undefined;
  const val = controlled ? value : inner;
  const ref = React.useRef(null);
  const uid = React.useId();
  const taId = id || `ta-${uid}`;
  const descId = description ? `${taId}-desc` : undefined;
  const errId = invalid && errorMessage ? `${taId}-err` : undefined;
  const lh = 22;
  React.useEffect(() => {
    const el = ref.current;
    if (!el || disableAutosize) return;
    el.style.height = "auto";
    const h = Math.min(Math.max(el.scrollHeight, minRows * lh), maxRows * lh);
    el.style.height = h + "px";
    el.style.overflowY = el.scrollHeight > h ? "auto" : "hidden";
  }, [val, minRows, maxRows, disableAutosize]);
  const set = v => {
    if (!controlled) setInner(v);
    onValueChange && onValueChange(v);
  };
  const clear = () => {
    set("");
    onClear && onClear();
    ref.current && ref.current.focus();
  };
  const border = invalid ? "var(--danger)" : focus ? "var(--cyan)" : hover ? "var(--border-strong)" : "var(--border-default)";
  const shells = {
    faded: {
      background: "var(--ink-800)",
      border: `1px solid ${border}`,
      borderRadius: __ds_scope.radius(radius)
    },
    flat: {
      background: hover || focus ? "var(--ink-500)" : "var(--ink-600)",
      border: `1px solid ${invalid ? "var(--danger)" : "transparent"}`,
      borderRadius: __ds_scope.radius(radius)
    },
    bordered: {
      background: "transparent",
      border: `1px solid ${border}`,
      borderRadius: __ds_scope.radius(radius)
    },
    underlined: {
      background: "transparent",
      border: "none",
      borderBottom: `1px solid ${border}`,
      borderRadius: 0
    }
  };
  const side = labelPlacement === "outside-left";
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    "data-slot": "base",
    "data-focus": __ds_scope.dataAttr(focus),
    "data-hover": __ds_scope.dataAttr(hover),
    "data-invalid": __ds_scope.dataAttr(invalid),
    "data-disabled": __ds_scope.dataAttr(isDisabled),
    "data-filled": __ds_scope.dataAttr(!!val),
    style: {
      display: "flex",
      flexDirection: side ? "row" : "column",
      alignItems: side ? "flex-start" : "stretch",
      gap: side ? 12 : 7,
      width: fullWidth ? "100%" : "auto",
      opacity: isDisabled ? 0.5 : 1,
      fontFamily: "var(--font-body)",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: taId,
    style: {
      fontSize: "var(--text-sm)",
      color: invalid ? "var(--danger)" : "var(--fg-2)",
      fontWeight: 500,
      whiteSpace: side ? "nowrap" : undefined,
      paddingTop: side ? 10 : 0
    }
  }, label, isRequired && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--danger)",
      marginLeft: 3
    }
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-slot": "input-wrapper",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 9,
      boxSizing: "border-box",
      padding: variant === "underlined" ? "8px 2px" : "9px 13px",
      boxShadow: focus && !invalid && variant !== "underlined" ? "var(--glow-cyan-sm)" : "none",
      cursor: isDisabled ? "not-allowed" : "text",
      transition: "border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)",
      ...(shells[variant] || shells.faded)
    }
  }, startContent && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--fg-3)",
      display: "inline-flex",
      flex: "none",
      paddingTop: 2
    }
  }, startContent), /*#__PURE__*/React.createElement("textarea", _extends({}, rest, {
    ref: ref,
    id: taId,
    value: val,
    placeholder: placeholder,
    disabled: isDisabled,
    readOnly: isReadOnly,
    required: isRequired,
    rows: minRows,
    "aria-invalid": invalid || undefined,
    "aria-required": isRequired || undefined,
    "aria-describedby": [descId, errId].filter(Boolean).join(" ") || undefined,
    onChange: e => {
      set(e.target.value);
      onChange && onChange(e);
    },
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      flex: 1,
      minWidth: 0,
      resize: disableAutosize ? "vertical" : "none",
      background: "transparent",
      border: "none",
      outline: "none",
      padding: 0,
      margin: 0,
      lineHeight: lh + "px",
      color: "var(--fg-1)",
      fontFamily: "var(--font-body)",
      fontSize: size === "sm" ? "var(--text-sm)" : "var(--text-base)",
      cursor: isDisabled ? "not-allowed" : "text"
    }
  })), isClearable && val && !isDisabled && !isReadOnly && /*#__PURE__*/React.createElement("button", {
    type: "button",
    tabIndex: -1,
    "aria-label": "clear input",
    onClick: clear,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 18,
      height: 18,
      padding: 0,
      border: "none",
      borderRadius: "50%",
      background: "var(--ink-500)",
      color: "var(--fg-2)",
      cursor: "pointer",
      fontSize: 13,
      lineHeight: 1,
      flex: "none"
    }
  }, "\xD7"), endContent && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-3)",
      display: "inline-flex",
      flex: "none"
    }
  }, endContent)), (description || invalid && errorMessage) && /*#__PURE__*/React.createElement("div", {
    "data-slot": "helper-wrapper",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, description && /*#__PURE__*/React.createElement("span", {
    id: descId,
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--fg-3)"
    }
  }, description), invalid && errorMessage && /*#__PURE__*/React.createElement("span", {
    id: errId,
    role: "alert",
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--danger)"
    }
  }, errorMessage))));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Tabs (HeroUI-aligned)
 * items: [{ key, title, icon?, count?, content?, isDisabled? }]   (legacy: tabs=[{ id, label }])
 * selectedKey / defaultSelectedKey / onSelectionChange              (legacy: value / onChange)
 * variant: underlined (default) | solid | bordered | light    placement: top | bottom | start | end
 * WAI-ARIA Tabs: roving tabindex, Arrow/Home/End keys, aria-controls ↔ tabpanel.
 */
function Tabs({
  items,
  selectedKey,
  defaultSelectedKey,
  onSelectionChange,
  variant = "underlined",
  color = "primary",
  size = "md",
  radius = "md",
  placement = "top",
  isVertical = false,
  isDisabled = false,
  disabledKeys = [],
  fullWidth = false,
  destroyInactiveTabPanel = true,
  disableAnimation = false,
  tabs,
  value,
  onChange,
  idBase,
  style = {},
  ...rest
}) {
  const list = (items || tabs || []).map(t => ({
    key: t.key ?? t.id,
    title: t.title ?? t.label,
    ...t
  }));
  const keys = list.map(t => t.key);
  const [inner, setInner] = React.useState(defaultSelectedKey ?? value ?? keys[0]);
  const ctrl = selectedKey ?? value;
  const active = ctrl !== undefined ? ctrl : inner;
  const uid = React.useId();
  const base = idBase || `tabs-${uid}`;
  const refs = React.useRef({});
  const k = __ds_scope.color(color);
  const vertical = isVertical || placement === "start" || placement === "end";
  const disabledSet = new Set(disabledKeys);
  const isOff = t => isDisabled || t.isDisabled || disabledSet.has(t.key);
  const select = key => {
    if (ctrl === undefined) setInner(key);
    onSelectionChange && onSelectionChange(key);
    onChange && onChange(key);
  };
  const onKeyDown = e => {
    const enabled = list.filter(t => !isOff(t)).map(t => t.key);
    const i = enabled.indexOf(active);
    if (i < 0) return;
    const fwd = vertical ? "ArrowDown" : "ArrowRight",
      back = vertical ? "ArrowUp" : "ArrowLeft";
    let next = null;
    if (e.key === fwd) next = enabled[(i + 1) % enabled.length];else if (e.key === back) next = enabled[(i - 1 + enabled.length) % enabled.length];else if (e.key === "Home") next = enabled[0];else if (e.key === "End") next = enabled[enabled.length - 1];
    if (next == null) return;
    e.preventDefault();
    select(next);
    const el = refs.current[next];
    el && el.focus && el.focus();
  };
  const fs = {
    sm: "var(--text-sm)",
    md: "var(--text-base)",
    lg: "var(--text-md)"
  }[size];
  const padY = {
    sm: "7px",
    md: "10px",
    lg: "12px"
  }[size];
  const boxed = variant === "solid" || variant === "bordered" || variant === "light";
  const listStyle = {
    underlined: {
      borderBottom: vertical ? "none" : "1px solid var(--border-default)",
      borderLeft: vertical ? "1px solid var(--border-default)" : "none",
      gap: "4px"
    },
    solid: {
      background: "var(--ink-600)",
      padding: 4,
      borderRadius: __ds_scope.radius(radius),
      gap: 2
    },
    bordered: {
      border: "1px solid var(--border-strong)",
      padding: 4,
      borderRadius: __ds_scope.radius(radius),
      gap: 2
    },
    light: {
      gap: 2
    }
  }[variant] || {};
  const tabLook = (isActive, hover, off) => {
    if (variant === "underlined") return {
      background: "transparent",
      color: isActive ? "var(--fg-1)" : hover ? "var(--fg-2)" : "var(--fg-3)"
    };
    if (isActive) return {
      background: color === "default" ? "var(--ink-400)" : k.solidBg,
      color: color === "default" ? "var(--fg-1)" : k.solidFg,
      boxShadow: color === "primary" ? k.glow : "var(--shadow-sm)"
    };
    return {
      background: hover && !off ? "var(--ink-500)" : "transparent",
      color: hover ? "var(--fg-1)" : "var(--fg-2)"
    };
  };
  const hasPanels = list.some(t => t.content !== undefined);
  const tablist = /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    "aria-orientation": vertical ? "vertical" : "horizontal",
    onKeyDown: onKeyDown,
    "data-slot": "tabList",
    style: {
      display: vertical ? "inline-flex" : "flex",
      flexDirection: vertical ? "column" : "row",
      width: fullWidth ? "100%" : undefined,
      alignItems: "stretch",
      ...listStyle
    }
  }, list.map(t => /*#__PURE__*/React.createElement(Tab, {
    key: t.key,
    t: t,
    ctx: {
      active,
      isOff,
      select,
      refs,
      base,
      variant,
      color,
      k,
      size,
      radius,
      fullWidth,
      boxed,
      padY,
      fs,
      vertical,
      disableAnimation,
      tabLook
    }
  })));
  if (!hasPanels) return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "base",
    style: style
  }, rest), tablist);
  const before = placement === "top" || placement === "start";
  const panels = list.map(t => {
    const isActive = t.key === active;
    if (!isActive && destroyInactiveTabPanel) return null;
    return /*#__PURE__*/React.createElement("div", {
      key: t.key,
      role: "tabpanel",
      id: `${base}-panel-${t.key}`,
      "aria-labelledby": `${base}-tab-${t.key}`,
      hidden: !isActive,
      tabIndex: 0,
      "data-slot": "panel",
      style: {
        padding: "16px 4px",
        color: "var(--fg-2)",
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-base)",
        flex: 1,
        minWidth: 0
      }
    }, t.content);
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "base",
    style: {
      display: "flex",
      flexDirection: vertical ? "row" : "column",
      gap: vertical ? 16 : 0,
      ...style
    }
  }, rest), before && tablist, panels, !before && tablist);
}
function Tab({
  t,
  ctx
}) {
  const {
    active,
    isOff,
    select,
    refs,
    base,
    variant,
    color,
    k,
    size,
    radius,
    fullWidth,
    boxed,
    padY,
    fs,
    vertical,
    disableAnimation,
    tabLook
  } = ctx;
  const [hover, setHover] = React.useState(false);
  const isActive = t.key === active,
    off = isOff(t);
  return /*#__PURE__*/React.createElement("button", {
    ref: el => {
      refs.current[t.key] = el;
    },
    type: "button",
    role: "tab",
    id: `${base}-tab-${t.key}`,
    "aria-selected": isActive,
    "aria-controls": `${base}-panel-${t.key}`,
    "aria-disabled": off || undefined,
    tabIndex: isActive && !off ? 0 : -1,
    disabled: off,
    "data-selected": __ds_scope.dataAttr(isActive),
    "data-disabled": __ds_scope.dataAttr(off),
    "data-hover": __ds_scope.dataAttr(hover),
    onClick: () => !off && select(t.key),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      flex: fullWidth ? 1 : "none",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: boxed ? "center" : "flex-start",
      gap: "7px",
      minHeight: boxed ? undefined : "44px",
      height: boxed ? {
        sm: 28,
        md: 32,
        lg: 40
      }[size] : undefined,
      padding: boxed ? `0 ${size === "sm" ? 10 : 14}px` : `${padY} 14px 13px`,
      border: "none",
      borderRadius: boxed ? __ds_scope.radius(radius === "full" ? "full" : "sm") : 0,
      cursor: off ? "not-allowed" : "pointer",
      opacity: off ? 0.4 : 1,
      fontFamily: "var(--font-body)",
      fontSize: fs,
      fontWeight: isActive ? 600 : 500,
      whiteSpace: "nowrap",
      transition: disableAnimation ? "none" : "color var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)",
      ...tabLook(isActive, hover, off)
    }
  }, t.icon, t.title, t.count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      color: isActive ? variant === "underlined" ? k.fg : "inherit" : "var(--fg-4)",
      opacity: isActive ? 0.9 : 1
    }
  }, t.count), isActive && variant === "underlined" && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      ...(vertical ? {
        top: 8,
        bottom: 8,
        left: -1,
        width: 2
      } : {
        left: 8,
        right: 8,
        bottom: -1,
        height: 2
      }),
      background: color === "default" ? "var(--fg-1)" : color === "primary" ? "var(--grad-cta)" : k.solidBg,
      borderRadius: 2,
      boxShadow: k.glow
    }
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlays/Modal.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Modal (HeroUI-aligned)
 * <Modal isOpen onOpenChange><ModalContent>{(onClose) => <>…</>}</ModalContent></Modal>
 * size: xs | sm | md | lg | xl | 2xl | full   placement: auto | center | top | bottom
 * backdrop: opaque | blur | transparent   isDismissable, isKeyboardDismissDisabled, hideCloseButton, scrollBehavior: inside | outside
 * Focus is trapped and restored; body scroll is blocked while open. Portal to document.body.
 */
const Ctx = React.createContext({
  onClose: () => {},
  ids: {}
});
const W = {
  xs: 320,
  sm: 400,
  md: 480,
  lg: 560,
  xl: 640,
  "2xl": 720,
  "3xl": 800,
  full: "100%"
};
function Modal({
  isOpen: isOpenProp,
  defaultOpen = false,
  onOpenChange,
  onClose,
  size = "md",
  placement = "auto",
  radius = "lg",
  backdrop = "opaque",
  isDismissable = true,
  isKeyboardDismissDisabled = false,
  hideCloseButton = false,
  closeButton,
  scrollBehavior = "inside",
  shouldBlockScroll = true,
  portalContainer,
  disableAnimation = false,
  children,
  style = {},
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultOpen);
  const open = isOpenProp ?? inner;
  const [shown, setShown] = React.useState(open);
  const close = React.useCallback(() => {
    if (isOpenProp === undefined) setInner(false);
    onOpenChange && onOpenChange(false);
    onClose && onClose();
  }, [isOpenProp, onOpenChange, onClose]);
  const ref = React.useRef(null),
    prev = React.useRef(null);
  const uid = React.useId();
  const ids = {
    header: `md-${uid}-h`,
    body: `md-${uid}-b`
  };
  React.useEffect(() => {
    if (open) {
      setShown(true);
      return;
    }
    if (disableAnimation) {
      setShown(false);
      return;
    }
    const t = setTimeout(() => setShown(false), 200);
    return () => clearTimeout(t);
  }, [open, disableAnimation]);
  React.useEffect(() => {
    if (!open) return;
    prev.current = document.activeElement;
    const el = ref.current;
    const focusables = () => el ? [...el.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter(n => !n.disabled) : [];
    requestAnimationFrame(() => {
      const f = focusables();
      (f[0] || el) && (f[0] || el).focus();
    });
    const onKey = e => {
      if (e.key === "Escape" && !isKeyboardDismissDisabled) {
        e.stopPropagation();
        close();
      }
      if (e.key === "Tab") {
        const f = focusables();
        if (!f.length) {
          e.preventDefault();
          return;
        }
        const i = f.indexOf(document.activeElement);
        if (e.shiftKey && i <= 0) {
          e.preventDefault();
          f[f.length - 1].focus();
        } else if (!e.shiftKey && i === f.length - 1) {
          e.preventDefault();
          f[0].focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    if (shouldBlockScroll) document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
      prev.current && prev.current.focus && prev.current.focus();
    };
  }, [open]);
  if (!shown) return null;
  const isFull = size === "full";
  const place = placement === "auto" ? "center" : placement;
  const anim = !disableAnimation;
  const node = /*#__PURE__*/React.createElement("div", {
    "data-slot": "wrapper",
    "data-placement": place,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 100,
      display: "flex",
      alignItems: isFull ? "stretch" : place === "top" ? "flex-start" : place === "bottom" ? "flex-end" : "center",
      justifyContent: "center",
      padding: isFull ? 0 : 16,
      boxSizing: "border-box",
      overflowY: scrollBehavior === "outside" ? "auto" : "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-slot": "backdrop",
    onClick: isDismissable ? close : undefined,
    "aria-hidden": "true",
    style: {
      position: "fixed",
      inset: 0,
      background: backdrop === "transparent" ? "transparent" : "var(--surface-overlay)",
      backdropFilter: backdrop === "blur" ? "var(--blur-overlay)" : undefined,
      opacity: open ? 1 : 0,
      transition: anim ? "opacity var(--dur-base) var(--ease-out)" : "none"
    }
  }), /*#__PURE__*/React.createElement("section", _extends({
    ref: ref,
    role: "dialog",
    "aria-modal": "true",
    "aria-labelledby": ids.header,
    "aria-describedby": ids.body,
    tabIndex: -1,
    "data-open": open ? "true" : undefined,
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      width: isFull ? "100%" : "100%",
      maxWidth: isFull ? "none" : W[size] || W.md,
      maxHeight: isFull ? "none" : scrollBehavior === "inside" ? "calc(100vh - 32px)" : undefined,
      height: isFull ? "100%" : undefined,
      boxSizing: "border-box",
      outline: "none",
      background: "var(--ink-700)",
      border: isFull ? "none" : "1px solid var(--border-strong)",
      borderRadius: isFull ? 0 : __ds_scope.radius(radius, "lg"),
      boxShadow: "var(--shadow-xl)",
      color: "var(--fg-1)",
      fontFamily: "var(--font-body)",
      opacity: open ? 1 : 0,
      transform: open ? "none" : place === "bottom" ? "translateY(16px)" : "translateY(-8px) scale(0.98)",
      transition: anim ? "opacity var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out)" : "none",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(Ctx.Provider, {
    value: {
      onClose: close,
      ids,
      scrollBehavior
    }
  }, children, !hideCloseButton && (closeButton || /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Close",
    onClick: close,
    style: {
      position: "absolute",
      top: 10,
      right: 10,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 32,
      height: 32,
      padding: 0,
      border: "none",
      borderRadius: "var(--radius-sm)",
      background: "transparent",
      color: "var(--fg-3)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 16 16",
    width: "16",
    height: "16",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M4 4l8 8M12 4l-8 8"
  })))))));
  const ReactDOM = window.ReactDOM;
  const target = portalContainer || (typeof document !== "undefined" ? document.body : null);
  return ReactDOM && ReactDOM.createPortal && target ? ReactDOM.createPortal(node, target) : node;
}
function ModalContent({
  children
}) {
  const {
    onClose
  } = React.useContext(Ctx);
  return /*#__PURE__*/React.createElement(React.Fragment, null, typeof children === "function" ? children(onClose) : children);
}
function ModalHeader({
  children,
  style = {},
  ...rest
}) {
  const {
    ids
  } = React.useContext(Ctx);
  return /*#__PURE__*/React.createElement("header", _extends({
    id: ids.header,
    "data-slot": "header",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2,
      padding: "18px 52px 12px 22px",
      fontSize: "var(--text-md)",
      fontWeight: 600,
      color: "var(--fg-1)",
      flex: "none",
      ...style
    }
  }, rest), children);
}
function ModalBody({
  children,
  style = {},
  ...rest
}) {
  const {
    ids,
    scrollBehavior
  } = React.useContext(Ctx);
  return /*#__PURE__*/React.createElement("div", _extends({
    id: ids.body,
    "data-slot": "body",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      padding: "4px 22px 16px",
      fontSize: "var(--text-base)",
      color: "var(--fg-2)",
      lineHeight: 1.55,
      flex: 1,
      minHeight: 0,
      overflowY: scrollBehavior === "inside" ? "auto" : "visible",
      ...style
    }
  }, rest), children);
}
function ModalFooter({
  children,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("footer", _extends({
    "data-slot": "footer",
    style: {
      display: "flex",
      justifyContent: "flex-end",
      alignItems: "center",
      gap: 8,
      padding: "12px 22px 18px",
      flex: "none",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/Modal.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AInoia — Card (HeroUI-aligned)
 * Matte dark panel with hairline border. Compose with CardHeader / CardBody / CardFooter,
 * or pass `padding` for a single padded area (legacy).
 * isPressable → renders <button role>, isHoverable → lift on hover. Legacy: interactive → isPressable + isHoverable.
 */
const SHADOWS = {
  none: "none",
  sm: "var(--shadow-sm)",
  md: "var(--shadow-md)",
  lg: "var(--shadow-lg)"
};
function Card({
  isPressable = false,
  isHoverable = false,
  isDisabled = false,
  isBlurred = false,
  fullWidth = false,
  shadow = "md",
  radius = "lg",
  glow = false,
  padding,
  onPress,
  interactive = false,
  disableAnimation = false,
  children,
  style = {},
  ...rest
}) {
  const pressable = isPressable || interactive;
  const hoverable = isHoverable || interactive || pressable;
  const {
    hover,
    pressed,
    props
  } = __ds_scope.useInteraction({
    isDisabled,
    onPress,
    onClick: rest.onClick
  });
  const Comp = pressable ? "button" : "div";
  const lift = hoverable && hover && !isDisabled;
  const hasParts = React.Children.toArray(children).some(c => c && c.type && c.type.__ainoiaCardPart);
  const pad = padding ?? (hasParts ? 0 : "var(--space-6)");
  return /*#__PURE__*/React.createElement(Comp, _extends({
    type: pressable ? "button" : undefined,
    disabled: pressable && isDisabled ? true : undefined,
    "aria-disabled": !pressable && isDisabled ? true : undefined,
    "data-pressable": __ds_scope.dataAttr(pressable),
    "data-hoverable": __ds_scope.dataAttr(hoverable)
  }, rest, hoverable || pressable ? props : {
    "data-disabled": __ds_scope.dataAttr(isDisabled)
  }, {
    style: {
      display: "flex",
      flexDirection: "column",
      boxSizing: "border-box",
      textAlign: "left",
      width: fullWidth ? "100%" : undefined,
      position: "relative",
      overflow: "hidden",
      background: lift ? "var(--surface-card-hover)" : isBlurred ? "rgba(58, 50, 44, 0.72)" : "var(--surface-card)",
      backdropFilter: isBlurred ? "blur(14px) saturate(1.2)" : undefined,
      border: `1px solid ${glow ? "var(--border-glow)" : lift ? "var(--border-strong)" : "var(--border-default)"}`,
      borderRadius: __ds_scope.radius(radius, "lg"),
      padding: pad,
      margin: 0,
      boxShadow: glow ? "var(--glow-cyan-sm)" : SHADOWS[shadow] || SHADOWS.md,
      color: "var(--fg-1)",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-base)",
      transform: pressed && pressable && !disableAnimation ? "scale(0.985)" : lift && !disableAnimation ? "translateY(-2px)" : "none",
      transition: disableAnimation ? "none" : "background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)",
      cursor: isDisabled ? "not-allowed" : pressable ? "pointer" : "default",
      opacity: isDisabled ? 0.5 : 1,
      ...style
    }
  }), children);
}
const part = (name, base) => {
  const P = ({
    children,
    style = {},
    ...rest
  }) => /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": name,
    style: {
      ...base,
      ...style
    }
  }, rest), children);
  P.__ainoiaCardPart = true;
  P.displayName = "Card" + name[0].toUpperCase() + name.slice(1);
  return P;
};
const CardHeader = part("header", {
  display: "flex",
  alignItems: "center",
  gap: "10px",
  padding: "16px 18px",
  borderBottom: "1px solid var(--border-subtle)",
  flex: "none"
});
const CardBody = part("body", {
  display: "flex",
  flexDirection: "column",
  gap: "10px",
  padding: "18px",
  flex: 1,
  minHeight: 0,
  overflow: "auto"
});
const CardFooter = part("footer", {
  display: "flex",
  alignItems: "center",
  gap: "10px",
  padding: "13px 18px",
  borderTop: "1px solid var(--border-subtle)",
  flex: "none"
});
Object.assign(__ds_scope, { Card, CardHeader, CardBody, CardFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/StatCard.jsx
try { (() => {
/**
 * AInoia — StatCard
 * Metric panel: label, big mono value, optional delta + sparkline area.
 */
function StatCard({
  label,
  value,
  unit,
  delta,
  deltaTone = "success",
  icon,
  children,
  style = {}
}) {
  const deltaColors = {
    success: "var(--success)",
    danger: "var(--danger)",
    neutral: "var(--fg-3)"
  };
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    padding: "var(--space-5)",
    style: {
      minWidth: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: "10px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      letterSpacing: "0.04em",
      color: "var(--fg-3)",
      textTransform: "uppercase",
      fontFamily: "var(--font-display)",
      fontWeight: 500
    }
  }, label), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-3)",
      display: "inline-flex"
    }
  }, icon)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontWeight: 500,
      fontSize: "var(--text-3xl)",
      color: "var(--fg-1)",
      lineHeight: 1
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-md)",
      color: "var(--cyan)"
    }
  }, unit), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto",
      fontSize: "var(--text-sm)",
      fontWeight: 600,
      color: deltaColors[deltaTone],
      fontFamily: "var(--font-mono)"
    }
  }, delta)), children && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "14px"
    }
  }, children));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/StatCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ainoia_board/AgentsPanel.jsx
try { (() => {
/* global React */
// AInoia Board — agent orchestration list panel
function AgentsPanel({
  agents,
  selectedId,
  onSelect,
  autonomous,
  onToggleAutonomous
}) {
  const {
    Card,
    AgentRow,
    Switch,
    IconButton,
    Badge
  } = window.CODISAIDesignSystem_b12028;
  const Ico = ({
    n,
    s = 15
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s
    }
  });
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  return /*#__PURE__*/React.createElement(Card, {
    padding: "0",
    style: {
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "16px 18px",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bot",
    style: {
      width: 17,
      height: 17,
      color: "var(--cyan)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-1)",
      fontWeight: 600,
      fontSize: 15
    }
  }, "Agents"), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, agents.length), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "Add agent",
    variant: "ghost",
    size: "sm"
  }, /*#__PURE__*/React.createElement(Ico, {
    n: "plus"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 8,
      display: "flex",
      flexDirection: "column",
      gap: 2,
      overflowY: "auto"
    }
  }, agents.map(a => /*#__PURE__*/React.createElement(AgentRow, {
    key: a.id,
    name: a.name,
    role: a.role,
    status: a.status,
    runs: a.runs,
    selected: a.id === selectedId,
    onClick: () => onSelect(a.id)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      padding: "13px 18px",
      borderTop: "1px solid var(--border-subtle)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: autonomous,
    onChange: onToggleAutonomous,
    label: "Autonomous mode"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      color: "var(--fg-4)",
      fontFamily: "var(--font-mono)"
    }
  }, autonomous ? "human-in-loop off" : "approval required")));
}
window.AgentsPanel = AgentsPanel;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ainoia_board/AgentsPanel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ainoia_board/PerformancePanel.jsx
try { (() => {
/* global React */
// AInoia Board — performance KPIs + charts
function PerformancePanel({
  agent
}) {
  const {
    StatCard,
    Card
  } = window.CODISAIDesignSystem_b12028;
  const Ico = ({
    n,
    s = 15
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s
    }
  });
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  const bars = [44, 58, 41, 66, 52, 73, 60, 84, 70, 92, 78, 96];
  const line = [62, 60, 67, 64, 72, 70, 78, 82, 80, 88, 92, 98.6];
  const pts = line.map((v, i) => `${i / (line.length - 1) * 100},${100 - (v - 55) / 50 * 100}`).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Success rate",
    value: "98.6",
    unit: "%",
    delta: "+1.2%",
    icon: /*#__PURE__*/React.createElement(Ico, {
      n: "target"
    })
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Executions",
    value: "1,243",
    delta: "+312",
    icon: /*#__PURE__*/React.createElement(Ico, {
      n: "activity"
    })
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Avg latency",
    value: "412",
    unit: "ms",
    delta: "-38ms",
    deltaTone: "success",
    icon: /*#__PURE__*/React.createElement(Ico, {
      n: "gauge"
    })
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Agents online",
    value: "4",
    unit: "/ 4",
    delta: "100%",
    icon: /*#__PURE__*/React.createElement(Ico, {
      n: "bot"
    })
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.4fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement(Header, {
    icon: "line-chart",
    title: "Success rate",
    right: "last 12h"
  }), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 100",
    preserveAspectRatio: "none",
    style: {
      width: "100%",
      height: 120,
      marginTop: 12,
      overflow: "visible"
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "perf-line",
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "0"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "#c0a080"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "#735a3a"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "perf-fill",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "rgba(192,160,128,0.28)"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "rgba(192,160,128,0)"
  }))), /*#__PURE__*/React.createElement("polygon", {
    points: `0,100 ${pts} 100,100`,
    fill: "url(#perf-fill)"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: pts,
    fill: "none",
    stroke: "url(#perf-line)",
    strokeWidth: "1.4",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    vectorEffect: "non-scaling-stroke"
  }))), /*#__PURE__*/React.createElement(Card, {
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement(Header, {
    icon: "bar-chart-3",
    title: "Executions",
    right: "per hour"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 5,
      height: 120,
      marginTop: 12
    }
  }, bars.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: `${b}%`,
      background: "var(--grad-cta)",
      borderRadius: 3,
      opacity: 0.4 + i / bars.length * 0.6
    }
  }))))));
}
function Header({
  icon,
  title,
  right
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    style: {
      width: 16,
      height: 16,
      color: "var(--cyan)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-1)",
      fontWeight: 600,
      fontSize: 14
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto",
      fontSize: 11.5,
      color: "var(--fg-4)",
      fontFamily: "var(--font-mono)"
    }
  }, right));
}
window.PerformancePanel = PerformancePanel;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ainoia_board/PerformancePanel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ainoia_board/Sidebar.jsx
try { (() => {
/* global React */
// AInoia Board — left navigation rail
function Sidebar({
  active,
  onNavigate
}) {
  const items = [{
    id: "overview",
    icon: "layout-dashboard",
    label: "Overview"
  }, {
    id: "agents",
    icon: "bot",
    label: "Agents"
  }, {
    id: "workflows",
    icon: "workflow",
    label: "Workflows"
  }, {
    id: "performance",
    icon: "line-chart",
    label: "Performance"
  }, {
    id: "integrations",
    icon: "blocks",
    label: "Integrations"
  }];
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 232,
      flex: "none",
      height: "100%",
      background: "var(--ink-800)",
      borderRight: "1px solid var(--border-subtle)",
      display: "flex",
      flexDirection: "column",
      padding: "20px 14px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 11,
      padding: "4px 10px 22px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 9,
      background: "var(--grad-cta)",
      display: "grid",
      placeItems: "center",
      boxShadow: "var(--glow-cyan-sm)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "orbit",
    style: {
      width: 17,
      height: 17,
      color: "var(--fg-on-accent)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "ainoia-wordmark",
    style: {
      fontSize: 17,
      letterSpacing: "0.22em"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ai"
  }, "AI"), "noia")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      letterSpacing: "0.16em",
      color: "var(--fg-4)",
      textTransform: "uppercase",
      padding: "0 10px 10px",
      fontFamily: "var(--font-display)"
    }
  }, "Control plane"), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 3
    }
  }, items.map(it => {
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      onClick: () => onNavigate(it.id),
      style: {
        display: "flex",
        alignItems: "center",
        gap: 11,
        padding: "10px 11px",
        borderRadius: "var(--radius-md)",
        border: `1px solid ${on ? "var(--border-glow)" : "transparent"}`,
        background: on ? "rgba(192,160,128,0.09)" : "transparent",
        color: on ? "var(--fg-1)" : "var(--fg-3)",
        fontFamily: "var(--font-body)",
        fontSize: 14,
        fontWeight: on ? 600 : 500,
        cursor: "pointer",
        textAlign: "left",
        transition: "all var(--dur-base) var(--ease-out)"
      },
      onMouseEnter: e => {
        if (!on) {
          e.currentTarget.style.background = "var(--ink-600)";
          e.currentTarget.style.color = "var(--fg-2)";
        }
      },
      onMouseLeave: e => {
        if (!on) {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "var(--fg-3)";
        }
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": it.icon,
      style: {
        width: 17,
        height: 17,
        color: on ? "var(--cyan)" : "currentColor"
      }
    }), it.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink-700)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-lg)",
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--fg-2)",
      fontWeight: 600,
      marginBottom: 4
    }
  }, "Deployed in your infra"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: "var(--fg-4)",
      lineHeight: 1.5
    }
  }, "eu-central \xB7 4 nodes \xB7 healthy"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 7,
      marginTop: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: "var(--success)",
      boxShadow: "0 0 6px var(--success)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      color: "var(--success)",
      fontFamily: "var(--font-mono)"
    }
  }, "all systems nominal")))));
}
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ainoia_board/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ainoia_board/TopBar.jsx
try { (() => {
/* global React */
// AInoia Board — top bar with title, search, deploy action, identity
function TopBar({
  title,
  subtitle,
  onDeploy,
  deploying
}) {
  const {
    Button,
    IconButton,
    Avatar,
    Input
  } = window.CODISAIDesignSystem_b12028;
  const Ico = ({
    n,
    s = 16
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s
    }
  });
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      padding: "16px 24px",
      borderBottom: "1px solid var(--border-subtle)",
      background: "color-mix(in srgb, var(--ink-900) 86%, transparent)",
      backdropFilter: "var(--blur-subtle)",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--fg-1)",
      fontWeight: 600,
      fontSize: 19,
      lineHeight: 1.2
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--fg-3)",
      fontSize: 13,
      marginTop: 2
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      width: 230
    }
  }, /*#__PURE__*/React.createElement(Input, {
    iconLeft: /*#__PURE__*/React.createElement(Ico, {
      n: "search",
      s: 15
    }),
    placeholder: "Search agents, runs\u2026",
    size: "sm"
  })), /*#__PURE__*/React.createElement(IconButton, {
    label: "Notifications",
    variant: "ghost"
  }, /*#__PURE__*/React.createElement(Ico, {
    n: "bell"
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onDeploy,
    iconLeft: /*#__PURE__*/React.createElement(Ico, {
      n: deploying ? "loader" : "rocket",
      s: 15
    })
  }, deploying ? "Deploying…" : "Deploy agent"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 28,
      background: "var(--border-default)"
    }
  }), /*#__PURE__*/React.createElement(Avatar, {
    name: "Maya Okonkwo",
    status: "active"
  }));
}
window.TopBar = TopBar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ainoia_board/TopBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ainoia_board/WorkflowCanvas.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* global React */
// AInoia Board — live workflow graph for the selected agent
function WorkflowCanvas({
  agent,
  running
}) {
  const {
    Card,
    Badge
  } = window.CODISAIDesignSystem_b12028;
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });

  // hub-and-spoke layout (percent coords within the canvas)
  const center = {
    x: 50,
    y: 52
  };
  const nodes = [{
    id: "trigger",
    label: "Trigger",
    icon: "zap",
    x: 50,
    y: 14,
    tone: "var(--cyan)"
  }, {
    id: "process",
    label: "Process",
    icon: "cpu",
    x: 15,
    y: 52,
    tone: "var(--blue)"
  }, {
    id: "integration",
    label: "Integration",
    icon: "blocks",
    x: 85,
    y: 52,
    tone: "var(--violet)"
  }, {
    id: "response",
    label: "Response",
    icon: "send",
    x: 50,
    y: 90,
    tone: "var(--cyan)"
  }];
  return /*#__PURE__*/React.createElement(Card, {
    padding: "0",
    style: {
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "16px 18px",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "workflow",
    style: {
      width: 17,
      height: 17,
      color: "var(--cyan)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-1)",
      fontWeight: 600,
      fontSize: 15
    }
  }, "Workflow"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--fg-3)",
      fontSize: 13
    }
  }, "\xB7 ", agent.name), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: running ? "active" : "neutral",
    dot: true
  }, running ? "Running" : "Idle"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      flex: 1,
      minHeight: 320,
      padding: 8
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 100",
    preserveAspectRatio: "none",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "wf-grad",
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "#d6bd9c"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "50%",
    stopColor: "#a67c52"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "#735a3a"
  }))), nodes.map(n => /*#__PURE__*/React.createElement("line", {
    key: n.id,
    x1: center.x,
    y1: center.y,
    x2: n.x,
    y2: n.y,
    stroke: "url(#wf-grad)",
    strokeWidth: "0.5",
    strokeLinecap: "round",
    opacity: running ? 0.85 : 0.4,
    strokeDasharray: running ? "2 2" : "0",
    style: running ? {
      animation: "wf-dash 0.9s linear infinite"
    } : undefined
  }))), /*#__PURE__*/React.createElement(Node, {
    x: center.x,
    y: center.y,
    hub: true,
    label: "",
    icon: "bot",
    tone: "url(#grad)",
    running: running,
    hubName: agent.name
  }), nodes.map(n => /*#__PURE__*/React.createElement(Node, _extends({
    key: n.id
  }, n, {
    running: running
  })))), /*#__PURE__*/React.createElement("style", null, `@keyframes wf-dash { to { stroke-dashoffset: -8; } }
        @keyframes wf-pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(192,160,128,0.35); } 50% { box-shadow: 0 0 0 7px rgba(192,160,128,0); } }`));
}
function Node({
  x,
  y,
  label,
  icon,
  tone,
  hub,
  running,
  hubName
}) {
  const size = hub ? 64 : 48;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: `${x}%`,
      top: `${y}%`,
      transform: "translate(-50%, -50%)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      display: "grid",
      placeItems: "center",
      background: hub ? "var(--grad-balance)" : "var(--ink-600)",
      border: hub ? "2px solid var(--ink-800)" : `1.5px solid ${tone}`,
      boxShadow: hub ? "var(--glow-balance)" : "var(--shadow-sm)",
      animation: hub && running ? "wf-pulse 1.6s var(--ease-in-out) infinite" : "none"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    style: {
      width: hub ? 26 : 19,
      height: hub ? 26 : 19,
      color: hub ? "var(--fg-on-accent)" : tone
    }
  })), hub ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      fontWeight: 600,
      color: "var(--fg-1)",
      whiteSpace: "nowrap"
    }
  }, hubName) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      color: "var(--fg-3)",
      fontFamily: "var(--font-display)",
      letterSpacing: "0.08em",
      textTransform: "uppercase"
    }
  }, label));
}
window.WorkflowCanvas = WorkflowCanvas;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ainoia_board/WorkflowCanvas.jsx", error: String((e && e.message) || e) }); }

__ds_ns.PlatoLogo = __ds_scope.PlatoLogo;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Kbd = __ds_scope.Kbd;

__ds_ns.Link = __ds_scope.Link;

__ds_ns.Spinner = __ds_scope.Spinner;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.AgentRow = __ds_scope.AgentRow;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Progress = __ds_scope.Progress;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.CheckboxGroup = __ds_scope.CheckboxGroup;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.RadioGroup = __ds_scope.RadioGroup;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.SelectItem = __ds_scope.SelectItem;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.ModalContent = __ds_scope.ModalContent;

__ds_ns.ModalHeader = __ds_scope.ModalHeader;

__ds_ns.ModalBody = __ds_scope.ModalBody;

__ds_ns.ModalFooter = __ds_scope.ModalFooter;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardBody = __ds_scope.CardBody;

__ds_ns.CardFooter = __ds_scope.CardFooter;

__ds_ns.StatCard = __ds_scope.StatCard;

})();
