repo: heroui-inc/heroui
branch: main
path: packages/core/theme/src, packages/components

## Last sync
date: 2026-08-31T12:00:00Z

### Updated in this project
- Aligned component set with HeroUI: added Checkbox/CheckboxGroup, RadioGroup/Radio, Textarea, Select/SelectItem, Divider, Link, Kbd, Progress, Skeleton, Alert, Tooltip, Modal (+Content/Header/Body/Footer)
- Kept existing HeroUI prop vocabulary (variant · color · size · radius · is* booleans · startContent/endContent · onPress/onValueChange/onSelectionChange)

## Screen map
| Component | Reference files |
| --- | --- |
| components/core/Button.jsx | packages/core/theme/src/components/button.ts, packages/components/button/src/use-button.ts |
| components/forms/Checkbox.jsx | packages/components/checkbox/src/use-checkbox.ts |
| components/forms/Select.jsx | packages/components/select/src/use-select.ts |
| components/overlays/Modal.jsx | packages/components/modal/src/use-modal.ts |
| components/feedback/Tooltip.jsx | packages/components/tooltip/src/use-tooltip.ts |
| components/core/Chip.jsx, Badge.jsx | packages/core/theme/src/components/chip.ts, badge.ts |
| components/core/theme.jsx | packages/core/theme/src/utils/variants.ts |
