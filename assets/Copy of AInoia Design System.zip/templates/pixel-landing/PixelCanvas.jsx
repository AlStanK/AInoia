// AInoia Design System — PixelCanvas
// Ambient grid of squares that ripples outward from center, then idles in a soft
// shimmer. Ported for the pixel-landing template. React is provided by the DC runtime.
// Props: colors (string[]), gap (number, px), speed (number, 0–100).

const { useRef, useEffect, useCallback } = React;

function createPixel(ctx, canvas, x, y, color, baseSpeed, delay) {
  const rand = (min, max) => Math.random() * (max - min) + min;
  const p = {
    x, y, color,
    speed: rand(0.08, 0.4) * baseSpeed,
    size: 0,
    sizeStep: rand(0.12, 0.28),
    minSize: 0.5,
    maxSizeInt: 2,
    maxSize: rand(0.5, 2),
    delay,
    counter: 0,
    counterStep: rand(1.8, 3.2) + (canvas.width + canvas.height) * 0.008,
    isIdle: false,
    isReverse: false,
    isShimmer: false,
    draw() {
      const offset = p.maxSizeInt * 0.5 - p.size * 0.5;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x + offset, p.y + offset, p.size, p.size);
    },
    appear() {
      p.isIdle = false;
      if (p.counter <= p.delay) { p.counter += p.counterStep; return; }
      if (p.size >= p.maxSize) p.isShimmer = true;
      if (p.isShimmer) p.shimmer(); else p.size += p.sizeStep;
      p.draw();
    },
    shimmer() {
      if (p.size >= p.maxSize) p.isReverse = true;
      else if (p.size <= p.minSize) p.isReverse = false;
      p.size += p.isReverse ? -p.speed : p.speed;
    },
  };
  return p;
}

function PixelCanvas({ colors = [], gap = 6, speed = 32 }) {
  const canvasRef = useRef(null);
  const wrapRef = useRef(null);
  const pixelsRef = useRef([]);
  const rafRef = useRef(0);
  const lastRef = useRef(performance.now());
  const reduceRef = useRef(false);

  const init = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap || !colors.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const { width, height } = wrap.getBoundingClientRect();
    const w = Math.max(1, Math.floor(width));
    const h = Math.max(1, Math.floor(height));
    canvas.width = w;
    canvas.height = h;
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";

    const eff = reduceRef.current ? 0 : Math.min(speed, 100) * 0.001;
    const pixels = [];
    for (let x = 0; x < w; x += gap) {
      for (let y = 0; y < h; y += gap) {
        const color = colors[(Math.random() * colors.length) | 0];
        const dx = x - w / 2;
        const dy = y - h / 2;
        const delay = reduceRef.current ? 0 : Math.sqrt(dx * dx + dy * dy) * 0.65;
        pixels.push(createPixel(ctx, canvas, x, y, color, eff, delay));
      }
    }
    pixelsRef.current = pixels;
  }, [colors, gap, speed]);

  const animate = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    const frameInterval = 1000 / 60;
    const loop = () => {
      rafRef.current = requestAnimationFrame(loop);
      const now = performance.now();
      const elapsed = now - lastRef.current;
      if (elapsed < frameInterval) return;
      lastRef.current = now - (elapsed % frameInterval);
      const canvas = canvasRef.current;
      const ctx = canvas && canvas.getContext("2d");
      if (!canvas || !ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const px of pixelsRef.current) px.appear();
    };
    rafRef.current = requestAnimationFrame(loop);
  }, []);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    reduceRef.current = mq.matches;
    init();
    const ro = new ResizeObserver(() => init());
    if (wrapRef.current) ro.observe(wrapRef.current);
    // react to a mid-session change of the OS setting, not just the mount value
    const onPref = (e) => { reduceRef.current = e.matches; init(); };
    mq.addEventListener("change", onPref);
    animate();
    return () => {
      ro.disconnect();
      mq.removeEventListener("change", onPref);
      cancelAnimationFrame(rafRef.current);
    };
  }, [init, animate]);

  return React.createElement(
    "div",
    { ref: wrapRef, style: { position: "absolute", inset: 0, overflow: "hidden" } },
    React.createElement("canvas", { ref: canvasRef, style: { display: "block", width: "100%", height: "100%" } })
  );
}

if (typeof module !== "undefined") module.exports = { PixelCanvas };
window.PixelCanvas = PixelCanvas;
