---
name: ainoia-design
description: Use this skill to generate well-branded interfaces and assets for AInoia (ainoia.ai), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping the "philosophy meets technology" AI-orchestration brand.
user-invocable: true
---

# AInoia Design System

Read `readme.md` in this skill first — it is the full design guide (brand context, content
fundamentals, visual foundations, iconography, and a file index). Then explore the other
files as needed.

## What's here
- `styles.css` — the single global entry point. Link it (or `@import` it) to inherit every
  token and webfont. It pulls in `tokens/*.css`.
- `tokens/` — colors, typography, spacing, effects, base element styles (CSS custom props).
- `guidelines/` — foundation specimen cards (Type, Colors, Spacing, Brand).
- `components/` — React UI primitives (Button, IconButton, Spinner, Badge, Chip (+Tag alias), Avatar,
  Card + CardHeader/Body/Footer, StatCard, Input, Textarea, Switch, Checkbox/CheckboxGroup, RadioGroup/Radio,
  Select/SelectItem, Divider, Link, Kbd, Alert, Progress, Skeleton, Tooltip, Modal, Tabs, AgentRow). Each has a `.d.ts` +
  `.prompt.md`. Props follow the HeroUI vocabulary — `variant · color · size · radius`, `is*`
  booleans, `startContent/endContent`, `onPress` / `onValueChange` / `onSelectionChange`,
  `data-*` state attributes. See `guidelines/api-conventions.card.html`.
- `ui_kits/ainoia_board/` — the interactive AInoia Board orchestration dashboard.
- `slides/` — branded 16:9 sample slides (title, duality, process, closing).
- `assets/` — `plato-hero.png` (split-face hero), `ainoia-infographic.png` (brand reference).

## How to work
- **Visual artifacts** (slides, mocks, throwaway prototypes): copy the assets you need out,
  link `styles.css`, and produce static HTML the user can view. Lean on the tokens and the
  brand voice; reach for the Plato motif and the tan→bronze balance gradient.
- **Production code**: copy assets and read the rules here to design fluently in-brand.
- **Components in HTML**: load `_ds_bundle.js` and read primitives from
  `window.CODISAIDesignSystem_b12028` (do not `<script src>` the `.jsx` directly).

## Brand in one breath
Warm coffee dark canvas, paper-cream neutrals, a tan→bronze→deep-coffee "balance" gradient,
thin wide-tracked geometric display type (Montserrat) over a neutral grotesque body (Manrope), thin line icons (Lucide) in circular badges. Calm, antithesis-driven copy:
*"We don't chase AI. We apply it with purpose."* No emoji. Light is the material — accents
glow, surfaces stay matte.

If invoked with no further guidance, ask what the user wants to build or design, ask a few
focused questions, then act as an expert AInoia designer who outputs HTML artifacts **or**
production code as needed.

## Substitution flags (confirm with the brand owner)
- Fonts are Google Fonts stand-ins, chosen for full Cyrillic support: Montserrat (display),
  Lora (serif), Manrope (body), JetBrains Mono (data).
- Icons standardize on Lucide (CDN) as the closest match to the brand's thin line set.
