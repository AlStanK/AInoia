# AInoia — Design System

> **We don't chase AI. We apply it with purpose.**
> Balance · Purpose · Performance

This is the design system for **AInoia**, the AI-agent orchestration product from
**ainoia.ai**. It encodes the brand's "philosophy meets technology" world — classical
clarity fused with engineered intelligence — into tokens, components, UI kits and slides
that design agents can build with.

---

## 1. Company & product context

**ainoia.ai** builds enterprise AI solutions with a deliberate, philosophy-first posture.
Its flagship product is **AInoia** — and within it, the **AInoia Board**, a control
plane to *orchestrate, monitor and optimize* fleets of AI agents and the business
processes they run. The pitch is restraint and rigour over hype:

- **Philosophy** — *We start with the right questions.* Clarity before complexity,
  purpose before automation, human values at the core.
- **Technology** — *We use the right tools.* AI with control (not chaos), integration
  over hype, security and scalability by design.
- **Impact** — *We focus on what truly matters.*

The signature engagement arc: **Discover → Design → Deliver → Optimize → Transform.**

The visual identity is built on one central image: a **Greek philosopher (Plato)** whose
face is split down the middle — one half weathered marble under warm bronze light, the other
half a glowing tan digital wireframe on deep coffee. It is the literal "balancing two worlds" motif:
ancient wisdom and modern computation.

### Sources provided
- `assets/plato-hero.png` — the split-face Plato hero artwork (warm bronze on deep coffee).
- `assets/ainoia-infographic.png` — the full brand infographic (wordmark, tagline,
  philosophy/technology/impact pillars, the Discover→Transform process, and a screenshot
  of the **AInoia Board** dashboard).
- Company: **ainoia.ai** (website was not reachable during authoring — treat copy here as
  derived from the supplied artwork, confirm against the live site when available).

> No codebase or Figma file was attached. Tokens, components and the UI-kit recreation of
> the AInoia Board are reconstructed faithfully from the supplied artwork. Where exact
> values (fonts, precise hexes) could not be measured, the closest defensible choice was
> made and flagged below.

---

## 2. Content fundamentals — how AInoia writes

**Voice:** calm, assured, philosophical-but-plain. It speaks like a thoughtful operator,
never a hype-merchant. Confidence comes from restraint.

- **Antithesis is the house style.** Copy is built on balanced opposites and negations —
  *"We don't chase AI. We apply it with purpose."* · *"AI with control, not chaos."* ·
  *"We implement with precision, not just speed."* · *"We create lasting change, not
  temporary fixes."* Lead with what you reject, land on what you stand for.
- **Short declaratives.** Sentences are clipped and certain. Triads of single words appear
  as taglines and section headers: *Balance. Purpose. Performance.* / *Orchestrate.
  Monitor. Optimize.*
- **Person:** "We" for the company, "your" for the customer — *"Deployed in your
  infrastructure. Built for your reality."* Warm, direct, never "I".
- **Casing:** Section labels and eyebrows are **UPPERCASE with wide tracking**
  (PHILOSOPHY, TECHNOLOGY, FROM HYPE TO VALUE). Headlines are sentence case. The wordmark
  is uppercase. Body is sentence case.
- **No emoji. No exclamation hype. No buzzword stacking.** A metric (98.6%, 1,243
  executions) is allowed to speak plainly; it is never dressed up.
- **Vocabulary:** philosophy, clarity, purpose, balance, control, orchestrate, value,
  precision, scale, security. Avoids: "revolutionary", "game-changing", "magic".

**Examples to emulate**
- Pillar: `PHILOSOPHY — We start with the right questions.`
- Process step: `DELIVER — We implement with precision, not just speed.`
- Product line: `Orchestrate. Monitor. Optimize. Our platform brings control and
  visibility to your AI agents and business processes.`

---

## 3. Visual foundations

**Overall vibe:** premium, cinematic, dark-mode-first **warm coffee**. The hero is an
**animated pixel canvas** — a fine grid of squares that ripples outward from center in muted
grey-taupe with tan/clay sparks — under a deep radial vignette. Headlines are set in a
**frosted glass shimmer** (a warm-cream sweep) that moves slowly across the type. High
contrast between the warm coffee canvas and luminous tan/clay accents, with glassy raised
controls.

### Color  (Warm Coffee theme)
- **Canvas:** warm coffee `--ink-900 #2d2621` down to `--void #1f1a16`, usually as a
  soft radial vignette (`--grad-hero`) that lifts toward the center-top.
- **Paper light:** `--marble-50 #f5f1e6` light sections with `--fg-on-light #4a3f35` text —
  used sparingly, as a deliberate counterpoint.
- **Signature gradient (`--grad-balance`):** tan `#c0a080` → bronze `#a67c52` → deep coffee
  `#735a3a`, ~100°. This is *the* brand asset. Tan = philosophy/human; clay = technology/
  machine; bronze is the bridge. Used on the wordmark "AI", key strokes, glowing edges and
  data highlights — never as a full-bleed background wash.
- **Status:** success `#94a878` (sage), warning `#c79a4a` (amber), danger `#d97355`
  (terracotta), info = tan.
- Accents **glow** softly (`--glow-cyan`, `--glow-violet`); they are warm light sources,
  not flat fills. *(Token names keep their original keys — `--cyan` etc. — now carrying
  warm values, so every component re-skins without renaming.)*
- **Never inline an `rgba()` accent literal.** Use the tint tokens — `--accent-tint`,
  `--accent-tint-strong`, `--accent-border`, `--clay-tint`/`--clay-border`, and
  `--success|warning|danger-tint`/`-border`. Hardcoded literals are what stranded the old
  cyan/violet values through the retheme; the tints are derived from the live token values.
- **Text or marks on an accent fill** use `--fg-on-accent` (`#241a10`), never a hand-picked
  dark. Accent fills that carry content use **`--grad-cta`** (tan → bronze), which holds
  `--fg-on-accent` at 4.57–9.44:1 across every stop. `--grad-balance` keeps its darker tail
  and is **decorative only** — wordmark, rules, indicators; its dark end is 2.6:1.

### Typography
- **Glass display — the hero voice.** Headlines pair **`Lora` italic** with
  **`Manrope` 800 (extrabold)**, set large and filled with the animated
  **glass shimmer** (`--glass-shimmer`, `-webkit-text-stroke` + drop-shadows, an 8s sweep).
  Use `.display-glass` with `.serif` / `.sans` spans to get the editorial serif-italic /
  heavy-sans rhythm — e.g. *Balance.* (serif italic) · *Purpose.* (sans) · *Performance.*
- **Wordmark / eyebrow — `Montserrat`** (geometric, thin). Set **light/thin weight** with very
  **wide tracking** (`--tracking-widest 0.34em`), uppercase. This is the AInoia wordmark
  voice and stays on the logo + section eyebrows. *Substitution flag: the exact wordmark
  face is unknown — Montserrat is the closest geometric match; confirm with the brand owner.*
- **Body / UI — `Manrope`** (neutral humanist grotesque), regular/medium.
- **Data / metrics / agent IDs — `JetBrains Mono`**.
- Eyebrows/labels: uppercase, wide-tracked, muted color, small size.

### Spacing & layout
- 8px rhythm with a 4px sub-step. Generous vertical air around hero and pillars.
- Pillars and process steps use a **circular thin-stroke icon** + UPPERCASE label +
  one-line sentence, connected by thin lines/arrows.
- Layout is calm and centered; lots of negative space on dark.

### Surfaces, borders, radii
- **Cards:** matte warm panels (`--surface-card #3a322c`) with a hairline border
  (`--border-default`, white @ ~11%) and a soft deep shadow. No heavy bevels.
- **Glass controls & panels:** primary CTAs and floating panels use the **glass** treatment
  — inset top-light + layered deep drop (`--shadow-glass-raised` / `--shadow-glass-flat`)
  and a saturated backdrop blur (`--blur-glass`). See `.btn-glass` / `.btn-glass-ghost`.
- **Radii:** controls `--radius-md 10px`; cards `--radius-lg/xl 14–20px`; pills for
  status chips. Circles for icon badges and avatars.
- **Glow border** (`--border-glow`) marks the active/selected state.

### Backgrounds
- The signature backdrop is the **animated pixel canvas** (muted grid + cyan/violet sparks)
  under a deep radial vignette — see the `Pixel canvas` brand card and the
  `pixel-landing` template. Where the canvas isn't used, fall back to the deep radial
  vignette (`--grad-hero`). No noisy gradients behind text.

### Motion
- Restrained and decisive. `--ease-out` (calm settle) for entrances; `--ease-spark` (a
  gentle overshoot) only for sparks/accents. Fades and short rises over slides/bounces.
  Ambient glow may drift slowly (`--dur-ambient 6s`). Two signature ambient loops: the
  pixel-canvas ripple and the headline **glass shimmer** (`--dur-shimmer 8s`). Both respect
  `prefers-reduced-motion` (the global reset neutralizes them).

### Interaction states
- **Hover:** surface lifts one step (`--surface-card-hover`), border brightens, accent
  glow appears. Links underline with offset.
- **Press:** slight scale-down (~0.98) and dimming — never a color flip.
- **Focus:** 2px cyan focus ring (`--focus-ring`) with offset; visible and on-brand.
- **Selected/active:** glow border + cyan text accent.

### Transparency & blur
- Overlays use `--surface-overlay` + `--blur-overlay` (glassy, saturated). Used for
  modals, toasts and floating panels over the dark canvas — not gratuitously.

### Imagery
- Warm, cinematic, high-contrast. Paper + lamplight. Tan/clay rim light on deep coffee.
  Photographic 3D renders (the Plato motif) rather than flat illustration. When in doubt,
  reach for the split-face balance metaphor.

### Responsive contract
- **Components** are intrinsically fluid — no fixed widths, no internal breakpoints. They
  fit whatever column you place them in.
- **Templates** (`templates/*`) are responsive starting scaffolds: fluid medallion
  (percentage-based rings), `clamp()` type, `auto-fit` card grids, and collapse
  breakpoints at 900px and 640px.
- **AInoia Board** (`ui_kits/ainoia_board`) is a **fixed 1320×840 desktop specimen**, not a
  responsive app shell. It exists to show the composed language at one size; copy the parts
  out rather than shrinking the frame.
- Interactive controls hold a ≥44px touch target even where the visual track is smaller
  (see Switch’s transparent hit-area span).

---

## 4. Iconography

- **Style:** thin, single-weight **line icons** inside **thin circular outlines** — the
  pillar/process badges in the infographic. Stroke width is light and even
  (`--icon-stroke 1.5`). Strokes may carry the cyan or violet accent.
- **No emoji. No unicode glyph icons.** Icons are line SVGs.
- **System:** the brand artwork uses a generic thin-line set (search, brain, cubes, chart,
  target, share-node, head/profile). No proprietary icon font was provided, so this system
  standardizes on **[Lucide](https://lucide.dev)** (1.5–2px stroke, rounded joins) loaded
  from CDN — it is the closest match to the artwork's thin, rounded line style.
  **Substitution flag:** confirm whether ainoia.ai ships its own icon set; if so, drop the
  SVGs into `assets/icons/` and repoint components.
- Usage: icons live in circular badges for pillars/steps; inline at 16–20px in UI; always
  monochrome (inherit `currentColor`) except when intentionally accented.

---

## 5. Index / manifest

**Root**
- `styles.css` — global entry point (import this one file).
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill manifest for use in Claude Code.

**Tokens** (`tokens/`)
- `fonts.css` · `colors.css` · `typography.css` · `spacing.css` · `effects.css` · `base.css`

**Foundation cards** (`guidelines/`) — specimen cards for the Design System tab
(Type, Colors, Spacing, Brand).

**Components** (`components/`) — see each directory's card + `.prompt.md`:
- `core/` — Button, IconButton, Spinner, Badge, Chip (Tag = legacy alias), Avatar, Divider, Link, Kbd
- `surfaces/` — Card (+ CardHeader / CardBody / CardFooter), StatCard
- `forms/` — Input, Textarea, Switch, Checkbox (+ CheckboxGroup), RadioGroup + Radio, Select (+ SelectItem)
- `feedback/` — Alert, Progress, Skeleton, Tooltip
- `overlays/` — Modal (+ ModalContent / ModalHeader / ModalBody / ModalFooter)
- `data/` — AgentRow
- `navigation/` — Tabs

Component APIs follow the **HeroUI** vocabulary so props are predictable across the set
(`guidelines/api-conventions.card.html`):
- `variant` (`solid | bordered | light | flat | faded | ghost | shadow`) × `color`
  (`default | primary | secondary | success | warning | danger`) × `size` (`sm | md | lg`) × `radius`.
- Booleans use the `is*` prefix: `isDisabled`, `isLoading`, `isSelected`, `isInvalid`, `isPressable`…
- Slots: `startContent` / `endContent`. Events: `onPress`, `onValueChange`, `onSelectionChange`, `onClose`.
- State is mirrored as `data-hover` / `data-pressed` / `data-focus-visible` / `data-selected` / `data-disabled`.
- Legacy props (`tone`, `iconLeft`, `hint/error`, `checked/onChange`, `tabs/value`, `interactive`,
  `selected`, `agent`) still work and are marked `@deprecated` in the `.d.ts` files.
- `brand/` — **PlatoLogo** (circular portrait medallion; props: `size`, `showRings`, `filtered`, `src`)

**UI kits** (`ui_kits/`)
- `ainoia_board/` — the AInoia Board agent-orchestration dashboard (interactive).

**Templates** (`templates/`) — copyable starting scaffolds for consuming projects
- `pixel-landing/` — **pixel-hero** marketing landing: animated pixel canvas, glass-shimmer
  triad headline, glassy CTAs. Two layouts via the `variant` tweak (Centered / Editorial
  split). The current flagship direction.
- `ainoia-landing/` — the earlier branded landing (hero + pillars + CTA, Plato artwork).

**Slides** (`slides/`) — branded 16:9 sample slides (title, duality, process, dashboard).

**Assets** (`assets/`)
- `plato-hero.png` — split-face hero artwork.
- `ainoia-infographic.png` — full brand infographic reference.

---

### Namespace
Components are exposed at runtime under `window.CODISAIDesignSystem_b12028`.
